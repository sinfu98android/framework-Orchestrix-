#include "ADS1256.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/io.h>
#include <sys/types.h>
#include <fcntl.h>
#include "IOProcess.h"
#include "Control.h"
#include <time.h>
#include "MiscDataConv.h"
#include "PLCProtocol.h"
#include <sys/types.h>
#include "System.h"

#ifdef ORANGEPI
#include <armbianio.h>
#endif

#define kCLKAB		10	//14	//6
#define kMOSIA		12
#define kMOSIB		16
#define kMISOA		24
#define kMISOB		26
#define kLATCHA		18
#define kLATCHB		22

#define SCK_HI		AIOWriteGPIO(kCLKAB, 1)
#define SCK_LO		AIOWriteGPIO(kCLKAB, 0)
#define MOSI_HI		AIOWriteGPIO(kMOSIA, 1)
#define MOSI_LO		AIOWriteGPIO(kMOSIA, 0)
#define GET_MISO	AIOReadGPIO(kMISOA)
#define CS_HI		AIOWriteGPIO(kLATCHA, 1)
#define CS_LO		AIOWriteGPIO(kLATCHA, 0)

#define SCK2_HI		AIOWriteGPIO(kCLKAB, 1)
#define SCK2_LO		AIOWriteGPIO(kCLKAB, 0)
#define MOSI2_HI	AIOWriteGPIO(kMOSIB, 1)
#define MOSI2_LO	AIOWriteGPIO(kMOSIB, 0)
#define GET_MISO2	AIOReadGPIO(kMISOB)
#define CS2_HI		AIOWriteGPIO(kLATCHB, 1)
#define CS2_LO		AIOWriteGPIO(kLATCHB, 0)


const struct stTblCal kTblCalTC_typeK[]=
	{
	 {-270, -173104},
	 {-200, -158074},
	 {-100,  -95121},
	 {   0,    -500},
	 { 100,  109714},
	 { 200,  217363},
	 { 300,  327187},
	 { 400,  439218},
	 { 500,  552458},
	 { 600,  667210},
	 { 700,  780012},
	 { 800,  892066},
	 { 900,  999330},
	 {1000,  1105318},
	 {1100,  1207959},
	 {1200,  1308209},
	 {1300,  1404284},
	 {1370,  1467369},
	};
#define kSizeof_kTblCalTC_typeK	sizeof(kTblCalTC_typeK)/sizeof(struct stTblCal)

//const unsigned char kTblMUX[]={0x01, 0x23, 0x45, 0x67, 0x01, 0x23, 0x45, 0x67};

//const unsigned char kTblMUX[]={0x08, 0x18, 0x28, 0x38, 0x48, 0x58, 0x68, 0x78};
const unsigned char kTblMUX[kMaxCH_ADS1256]={0x07, 0x17, 0x27, 0x37, 0x47, 0x57, 0x67};

enum eStateADS1256	StateADS1256[kTotalADS1256];
unsigned char CH_ADS1256;
unsigned char RDY_ADS1256;
int	ADC_ADS1256[kTotalADS1256][kMaxCH_ADS1256];
int TC[kMaxCH_ADS1256];
int datADS1256;
unsigned char statADS1256;
unsigned char idxADS1256=0;

unsigned char CheckDRDY(void);

void InitSPI2(void)
{
#ifdef ORANGEPI
 int rc;
 const char *szBoardName;

 rc = AIOInit();
 if (rc == 0)
	{
	 printf("Problem initializing ArmbianIO library\r\n");
	 return;
	}
 szBoardName = AIOGetBoardName();
 printf("Running on a %s\r\n", szBoardName);	
 AIOAddGPIO(kCLKAB, GPIO_OUT);
 AIOAddGPIO(kMOSIA, GPIO_OUT);
 AIOAddGPIO(kMOSIB, GPIO_OUT);
 AIOAddGPIO(kMISOA, GPIO_IN);
 AIOAddGPIO(kMISOB, GPIO_IN);
 AIOAddGPIO(kLATCHA, GPIO_OUT);
 AIOAddGPIO(kLATCHB, GPIO_OUT);
#endif 
}


void InitADS1256(void)
{
#ifdef ORANGEPI
// InitSPI();
 InitSPI2();
 CS_HI;
 SCK_LO;
 MOSI_LO;
#endif 
 StateADS1256[0]=kWAKEUP_ADS1256;
 StateADS1256[1]=kWAKEUP_ADS1256; 
 StateADS1256[0]=kSTATE_WAKEUP_ADS1256;
 StateADS1256[1]=kSTATE_WAKEUP_ADS1256; 
 CH_ADS1256=0;
 RDY_ADS1256=kFALSE;
}


unsigned char SendSPI(unsigned char val)
{
 unsigned char n, temp;

 temp=val;
 for (n=0; n<8; n++)
 	{
#ifdef ORANGEPI 	
	 if (temp & 0x80) MOSI_HI;
	 else MOSI_LO;
#endif	 
	 temp=temp<<1;	 
#ifdef ORANGEPI
	 SCK_HI;
	 SCK_LO;
	 if (GET_MISO) temp=temp|0x01;
#endif	 
 	}
 return(temp);
}

void CommandADS1256(unsigned char cmd)
{
#ifdef ORANGEPI
 CS_LO;
#endif
 SendSPI(cmd);
#ifdef ORANGEPI
 CS_HI;
#endif
}


void SetMUX(unsigned char val)
{
#ifdef ORANGEPI
 CS_LO;
#endif
 SendSPI(kWRITE_REG|kREG_MUX_ADS1256);
 SendSPI(1);
 SendSPI(val);
#ifdef ORANGEPI
 CS_HI;
#endif
}

void WriteREG(unsigned char Addr, unsigned char val)
{
#ifdef ORANGEPI
 CS_LO;
#endif
 SendSPI(kWRITE_REG|Addr);
 SendSPI(1);
 SendSPI(val);
#ifdef ORANGEPI 
 CS_HI;
#endif
}

int GetData(void)
{
 union uGlobal32bitDataFormat	dat;
 unsigned int i;

 dat.Int32=0;
#ifdef ORANGEPI 
 CS_LO;
#endif
 SendSPI(kRDATA_ADS1256);
 for (i=0; i<5; i++);
 dat.UInt8[2]=SendSPI(0);
 dat.UInt8[1]=SendSPI(0);
 dat.UInt8[0]=SendSPI(0);
#ifdef ORANGEPI 
 CS_HI;
#endif
 if (dat.UInt8[2] & 0x80)
 	 {
	  dat.UInt8[3]=0xFF;
 	 }
 return(dat.Int32);
}


unsigned char ReadREG(unsigned char val)
{
 unsigned char stat;

#ifdef ORANGEPI
 CS_LO;
#endif
 stat=SendSPI(kREAD_REG|val);
 stat=SendSPI(1);
 stat=SendSPI(0);
#ifdef ORANGEPI 
 CS_HI;
#endif
 return(stat);
}

unsigned char SendSPI2(unsigned char idx, unsigned char cmd)
{
 static unsigned char stateSendSPI=0;
 static unsigned char vcmd, n;

 if (stateSendSPI==0)
 	{
 	 vcmd=cmd;
 	 n=0;
 	 stateSendSPI=1;
 	}
 else if (stateSendSPI==1)
 	{
	 if (vcmd & 0x80)
	 	{
	 	 if (idx==0)
	 	 	{
			 #ifdef ORANGEPI
		 	 	MOSI_HI;
			 #endif
	 	 	}
		 else if (idx==1)
		 	{
		 	 #ifdef ORANGEPI
		 	 	MOSI2_HI;
			 #endif
		 	}
	 	}
	 else
	 	{
	 	 if (idx==0)
	 	 	{
	 	 	 #ifdef ORANGEPI
		 	 	MOSI_LO;
			 #endif
	 	 	}
		 else if (idx==1)
		 	{
		 	 #ifdef ORANGEPI
			 	 MOSI2_LO;
			 #endif
		 	}
	 	}
	 vcmd=vcmd<<1;
	 stateSendSPI=2;
 	}
 else if (stateSendSPI==2)
 	{
 	 #ifdef ORANGEPI
 	 	SCK_HI;
	 #endif
	 stateSendSPI=3;
 	}
 else if (stateSendSPI==3)
 	{
 	 #ifdef ORANGEPI
		 SCK_LO;
	 	 if (((idx==0)&&(GET_MISO))||((idx==1)&&(GET_MISO2))) vcmd=vcmd|0x01;
	 #endif	 
	 n++;
	 if (n<8) stateSendSPI=1;
	 else
	 	{
	 	 statADS1256=vcmd;
	 	 stateSendSPI=0;
		 return(kTRUE);
	 	}
 	}
 return(kFALSE);
}
 

unsigned char CommandADS1256_2(unsigned char idx, unsigned char cmd)
{
 static unsigned char state=0;

 if (state==0)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
	 	 	CS_LO;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
	 	 	CS2_LO;
		 #endif
	 	}
	 state=1;
 	}
 else if (state==1)
 	{
 	 if (SendSPI2(idx, cmd)) state=2;
 	}
 else if (state==2)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
	 	 	CS_HI;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
	 	 	CS2_HI;
		 #endif
	 	}
	 state=0;
	 return(kTRUE);
 	}
 return(kFALSE);
}




unsigned char SetMUX_2(unsigned char idx, unsigned char val)
{ 
 static unsigned char state=0;

 if (state==0)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
		 	 CS_LO;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_LO;
		 #endif
	 	}
	 state=1;
 	}
 else if (state==1)
 	{
 	 if (SendSPI2(idx, kWRITE_REG|kREG_MUX_ADS1256)) state=2;
 	}
 else if (state==2)
 	{
 	 if (SendSPI2(idx, 1)) state=3;
 	}
 else if (state==3)
 	{
 	 if (SendSPI2(idx, val)) state=4;
 	}
 else if (state==4)
 	{
 	 if (idx==0) 
 	 	{
 	 	 #ifdef ORANGEPI
	 	 	CS_HI;
		 #endif
 	 	}
	 else if (idx==1) 
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_HI;
		 #endif
	 	}
	 state=0;
	 return(kTRUE);
 	}
 return(kFALSE);
}



unsigned char WriteREG_2(unsigned char idx, unsigned char Addr, unsigned char val)
{
 static unsigned char state=0;

 if (state==0)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
		 	 CS_LO;
		 #endif
 	 	}
	 else if (idx==1) 
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_LO;
		 #endif
	 	}
	 state=1;
 	}
 else if (state==1)
 	{
 	 if (SendSPI2(idx, kWRITE_REG|Addr)) state=2;	 
 	}
 else if (state==2)
 	{
 	 if (SendSPI2(idx, 1)) state=3;
 	}
 else if (state==3)
 	{
	 if (SendSPI2(idx, val)) state=4;
 	}
 else if (state==4)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
		 	 CS_HI;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_HI;
		 #endif
	 	}
	 state=0;
	 return(kTRUE);
 	}
 return(kFALSE);
}


unsigned char GetData_2(unsigned char idx)
{
 static unsigned char state=0;
 static union uGlobal32bitDataFormat	dat;
// unsigned int i;

 if (state==0)
 	{
 	 dat.Int32=0;
	 if (idx==0)
	 	{
	 	 #ifdef ORANGEPI
		 	CS_LO;
		 #endif
	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_LO;
		 #endif
	 	}
	 state=1;
 	}
 else if (state==1)
 	{
 	 if (SendSPI2(idx, kRDATA_ADS1256))
 	 	{
	 	 state=2;
 	 	}
 	}
 else if (state==2)
 	{
 	 if (SendSPI2(idx, 0))
 	 	{
 	 	 dat.UInt8[2]=statADS1256;
	 	 state=3;
 	 	}
 	}
 else if (state==3)
 	{
 	 if (SendSPI2(idx, 0))
 	 	{
 	 	 dat.UInt8[1]=statADS1256;
	 	 state=4;
 	 	}
 	}
 else if (state==4)
 	{
 	 if (SendSPI2(idx, 0))
 	 	{
	 	 dat.UInt8[0]=statADS1256;
	 	 state=5;
 	 	}
 	}
 else if (state==5)
 	{
 	 #ifdef ORANGEPI
	 	 CS_HI;
	 #endif
	 if (dat.UInt8[2] & 0x80)
		 {
		  dat.UInt8[3]=0xFF;
		 }
	 datADS1256=dat.Int32;
	 state=0;
	 return(kTRUE);
 	}
 return(kFALSE);
}


unsigned char ReadREG_2(unsigned char idx, unsigned char val)
{
 static unsigned char state=0;
 static unsigned char stat;

 if (state==0)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
		 	 CS_LO;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_LO;
		 #endif
	 	}
	 state=1;
 	}
 else if (state==1)
 	{
 	 if (SendSPI2(idx, kREAD_REG|val))
 	 	{
 	 	 stat=statADS1256;
	 	 state=2;
 	 	}
 	}
 else if (state==2)
 	{
 	 if (SendSPI2(idx, 1))
 	 	{
 	 	 stat=statADS1256;
	 	 state=3;
 	 	}
 	}
 else if (state==3)
 	{
 	 if (SendSPI2(idx, 0))
 	 	{
 	 	 stat=statADS1256;
	 	 state=4;
 	 	}
 	}
 else if (state==4)
 	{
 	 if (idx==0)
 	 	{
 	 	 #ifdef ORANGEPI
		 	 CS_HI;
		 #endif
 	 	}
	 else if (idx==1)
	 	{
	 	 #ifdef ORANGEPI
		 	 CS2_HI;
		 #endif
	 	}
	 state=0;
	 statADS1256=stat;
	 return(kTRUE);
 	}
 return(kFALSE);
}



void ADS1256Proc2(void)
{
 unsigned char stat;
// static unsigned char stateChange;

 if (FlagsSystem.PowerUP==kFALSE) return;
 if (StateADS1256[idxADS1256]==kSTATE_WAKEUP_ADS1256)
 	 {
	  if (CommandADS1256_2(idxADS1256,kWAKEUP_ADS1256))
	  	{
	  	 StateADS1256[idxADS1256]=kSTATE_RESET_ADS1256;
		 usleep(kWaitSPIADS);
	  	}
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_RESET_ADS1256)
 	 {
	   if (CommandADS1256_2(idxADS1256, kRESET_ADS1256))
	   	  {
	  	   StateADS1256[idxADS1256]=kSTATE_CONFIG1_ADS1256;
		   usleep(kWaitSPIADS);
	   	  }
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_CONFIG1_ADS1256)
 	 {
	  if (WriteREG_2(idxADS1256, kREG_DRATE_ADS1256,k30_SPS))
	  	 {
	  	  StateADS1256[idxADS1256]=kSTATE_CONFIG2_ADS1256;
		  usleep(kWaitSPIADS);
	  	 }
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_CONFIG2_ADS1256)
 	 {
 	  if (WriteREG_2(idxADS1256, kREG_ADCON_ADS1256,(0<<PGA0)))
 	  	 {
	  	  StateADS1256[idxADS1256]=kSTATE_CAL_ADS1256;
		  usleep(kWaitSPIADS);
 	  	 }
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_CAL_ADS1256)
 	 {
	  if (WriteREG_2(idxADS1256, kREG_STATUS_ADS1256,(1<<BUFEN)|(1<<ACAL)))
	  	 {
		  StateADS1256[idxADS1256]=kSTATE_SET_MUX_ADS1256;
		  usleep(kWaitSPIADS);
	  	 }
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_SET_MUX_ADS1256)
 	 {
 	  if (SetMUX_2(idxADS1256, kTblMUX[CH_ADS1256]))
 	  	  {
	  	   StateADS1256[idxADS1256]=kSTATE_READREG_ADS1256;
		   usleep(kWaitMUXADS);
 	  	  }
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_READREG_ADS1256)
 	 {
 	  if (ReadREG_2(idxADS1256, kREG_STATUS_ADS1256))
 	  	{
		  stat=statADS1256;
		  if ((stat & 0x01)==0)
		  	  {
			   StateADS1256[idxADS1256]=kSTATE_READ_ADC_ADS1256;
		  	  }
 	  	}
 	 }
 else if (StateADS1256[idxADS1256]==kSTATE_READ_ADC_ADS1256)
 	 {
 	  if (GetData_2(idxADS1256))
 	  	{
		  ADC_ADS1256[idxADS1256][CH_ADS1256]=datADS1256;
		  CH_ADS1256++;
		  if (CH_ADS1256>=kMaxCH_ADS1256)
		  	  {
		  	   idxADS1256++;
			   if (idxADS1256>=2) idxADS1256=0;
			   CH_ADS1256=0;
			   RDY_ADS1256=kTRUE;
		  	  }
		  StateADS1256[idxADS1256]=kSTATE_SET_MUX_ADS1256;
		  usleep(kWaitSAMPLINGADS);				  
 	  	}
 	 }
}


void *ADS1256Task(void* args)
{
 InitADS1256();
 while(1)
 	{
 	 ADS1256Proc2();
 	 usleep(100);
 	}
}

