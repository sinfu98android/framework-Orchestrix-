#ifndef ADS1256_H
#define ADS1256_H
//#include "SPIDriver.h"
//#include "SPI.h"
#include "IOProcess.h"

#define kWAKEUP_ADS1256					0x00
#define kRDATA_ADS1256					0x01
#define kREAD_REG						0x10
#define kWRITE_REG						0x50
#define kRESET_ADS1256					0xFE


#define kREG_STATUS_ADS1256		0x00
#define kREG_MUX_ADS1256		0x01
#define kREG_ADCON_ADS1256		0x02
#define kREG_DRATE_ADS1256		0x03
#define kREG_IO_ADS1256			0x04
#define kREG_OFC0_ADS1256		0x05
#define kREG_OFC1_ADS1256		0x06
#define kREG_OFC2_ADS1256		0x07
#define kREG_FSC0_ADS1256		0x08
#define kREG_FSC1_ADS1256		0x09
#define kREG_FSC2_ADS1256		0x0A

//*********** REG 0 ***********//
#define ID3			7
#define ID2			6
#define ID1			5
#define ID0			4
#define ORDER		3
#define ACAL		2
#define BUFEN		1
#define DRDY		0
//*********** REG 1 ***********//
#define PSEL3		7
#define PSEL2		6
#define PSEL1		5
#define PSEL0		4
#define NSEL3		3
#define NSEL2		2
#define NSEL1		1
#define NSEL0		0
//*********** REG 2 ***********//
#define CLK1		6
#define CLK0		5
#define SDCS1		4
#define SDCS0		3
#define PGA2		2
#define PGA1		1
#define PGA0		0

#define k30K_SPS	0xF0
#define k15K_SPS	0xE0
#define k7500_SPS	0xD0
#define k3750_SPS	0xC0
#define k2000_SPS	0xB0
#define k1000_SPS	0xA1
#define k500_SPS	0x92
#define k100_SPS	0x82
#define k60_SPS		0x72
#define k50_SPS		0x63
#define k30_SPS		0x53
#define k25_SPS		0x43
#define k15_SPS		0x33
#define k10_SPS		0x23
#define k5_SPS		0x13
#define k2_5_SPS	0x03


#define kWaitSPIADS			100000
#define kWaitMUXADS			50000
#define kWaitSAMPLINGADS	50000
#define kTotalADS1256		2
#define kMaxCH_ADS1256		7

enum eStateADS1256{
	kSTATE_WAKEUP_ADS1256,
	kSTATE_RESET_ADS1256,
	kSTATE_CONFIG1_ADS1256,
	kSTATE_CONFIG2_ADS1256,
	kSTATE_CAL_ADS1256,
	kSTATE_SET_MUX_ADS1256,
	kSTATE_READREG_ADS1256,
	kSTATE_READ_ADC_ADS1256,
};

struct stTblCal{
	int TC_Data;
	int	ADCData;
};



extern int ADC_ADS1256[kTotalADS1256][kMaxCH_ADS1256];
extern int TC[];
extern enum eStateADS1256	StateADS1256[kTotalADS1256];

void InitADS1256(void);
void CalcTC(void);
void ADS1256Proc(void);
void ADS1256Proc2(void);
void CommandADS1256(unsigned char cmd);
void *ADS1256Task(void* args);


#endif
