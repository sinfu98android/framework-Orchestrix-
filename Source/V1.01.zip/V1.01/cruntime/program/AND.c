#include "AND.h"
#include "System.h"
#include "UART.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//float ValueAND;

void InitAND(unsigned char idx)
{
 
}


float ParseAND(unsigned char *pBuff)
{
#define kMaxCaptureDigit	16
 unsigned char i, startDigit;
 float temp;
 unsigned char Sign, ZeroTrailling, ZeroPoint;
 unsigned int	Exp;
 unsigned char	TotalDigit;


 Sign=kFALSE;					// Assume positive number
 startDigit=255;
 for (i=0; i<255; i++)
 	 {
	  if (((pBuff[i]>='0')&&(pBuff[i]<='9')))//||(pBuff[i]='-'))
	  	  {
		   startDigit=i;
		   break;
	  	  }
 	 }
 if (startDigit==255) return(0);
 if (pBuff[startDigit-1]=='-') Sign=kTRUE;
 temp=0;
 ZeroTrailling=kFALSE;
 ZeroPoint=kFALSE;
 Exp=1;
 TotalDigit=0;
 for (i=startDigit; i<(startDigit+kMaxCaptureDigit); i++)
 	 {
	  if (((pBuff[i]>='0')&&(pBuff[i]<='9'))||(pBuff[i]=='.')||(pBuff[i]==','))
	  	  {
		   if ((pBuff[i]=='.')||(pBuff[i]==','))
		   	   {
			    ZeroPoint=kTRUE;
		   	   }
		   if (pBuff[i]>'0') ZeroTrailling=kTRUE;
		   if ((pBuff[i]>='0')&&(pBuff[i]<='9'))
		   	   {
			    temp*=Exp;
			    temp+=pBuff[i] & 0x0F;
			    if (ZeroTrailling) Exp=10;
			    if (ZeroPoint) temp/=10;
			    TotalDigit++;
		   	   }
	  	  }
	  else break;
 	 }
 if (Sign) temp*=-1;
 if (TotalDigit<4) temp=kFLT_MAX;
 return(temp);
}


void ANDProcess(unsigned char idx)
{
 if (UARTRdy[idx])
 	{
	 if (ReceiveComplete[idx])
	 	{
	 	 UART_RESPONE[idx]=kTRUE;
		 TrialRespone[idx]=0;
		 ReceiveComplete[idx]=kFALSE;		 
		 if ((BuffRX[idx][ptrRX[idx]-2]==0x0D)&&
		      (BuffRX[idx][ptrRX[idx]-1]==0x0A)&&
		      (BuffRX[idx][2]==',')&&
		      (((BuffRX[idx][0]=='S')&&(BuffRX[idx][1]=='T'))||
		      	  ((BuffRX[idx][0]=='U')&&(BuffRX[idx][1]=='S'))||
		      	  ((BuffRX[idx][0]=='O')&&(BuffRX[idx][1]=='L'))||
		      	  ((BuffRX[idx][0]=='Q')&&(BuffRX[idx][1]=='T')))) 
			 	{
			      	 DataPLC_RX[idx].DataFloat[0]=ParseAND(&BuffRX[idx][0]);			 
			 	}
		 TickCOM_[idx]++;
		 ptrRX[idx]=0;		 
	 	}
	 if (FlagsSystem.Tick100mS)
	 	{
	 	 TrialRespone[idx]++;
		 if (TrialRespone[idx]>20)
		 	{
		 	 UARTRdy[idx]=kFALSE;
			 UART_RESPONE[idx]=kFALSE;
			 CloseUART(idx);
		 	}
	 	}
 	}
}

