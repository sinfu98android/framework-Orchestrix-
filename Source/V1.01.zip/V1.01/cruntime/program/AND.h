#ifndef AND_H
#define AND_H

#define kFLT_MAX	3.40282347e+38F

//extern float ValueAND;

void InitAND(unsigned char idx);
void ANDProcess(unsigned char idx);
#endif
