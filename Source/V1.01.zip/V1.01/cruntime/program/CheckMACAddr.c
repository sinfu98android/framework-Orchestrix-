#include <sys/ioctl.h>
#include <net/if.h> 
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "CheckMACAddr.h"


unsigned char mac_address[6];
char ip_address[30];
char mac_addressstr[30];
char ethName[30];
struct stNetMACIP	BuffMAC[kMaxNetwork];


void CheckMACAddr(void)
{
    struct ifreq 	ifr;
    struct ifconf   ifc;
    struct ifreq 	ifr_;
//	struct ifreq * 	it;
    char buf[2048];
	unsigned char i;
	int n;//, tot;
//	char dump[30];

	memset(BuffMAC,0, sizeof(BuffMAC));
	memset(ethName,0,sizeof(ethName));
	memset(mac_addressstr,0,sizeof(mac_addressstr));

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock == -1) { /* handle error*/ };

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
    if (ioctl(sock, SIOCGIFCONF, &ifc) == -1) { /* handle error */ }

    struct ifreq* it = ifc.ifc_req;
    const struct ifreq* const end = it + (ifc.ifc_len / sizeof(struct ifreq));
	//printf("total: %ld \r\n", ifc.ifc_len / sizeof(struct ifreq));
	n=0;
    for (; it != end; ++it) 
		{
         strcpy(ifr.ifr_name, it->ifr_name);
		 strcpy(BuffMAC[n].Name, ifr.ifr_name);
		 ifr_=*it;
		 ioctl(sock, SIOCGIFHWADDR, &ifr_);		 
		 for (i=0; i<6; i++) BuffMAC[n].MAC[i]=ifr_.ifr_hwaddr.sa_data[i] &0xFF;
		 ioctl(sock, SIOCGIFADDR, &ifr_);		 
		 for (i=0; i<6; i++) BuffMAC[n].IP[i]=ifr_.ifr_addr.sa_data[i] &0xFF;
#if 1
		  printf("%02d:\t%16s\tMAC:%02x:%02x:%02x:%02x:%02x:%02x\tIP:%d:%d:%d:%d\r\n",
		  			n,
		  			BuffMAC[n].Name,
					BuffMAC[n].MAC[0], BuffMAC[n].MAC[1], BuffMAC[n].MAC[2], BuffMAC[n].MAC[3], BuffMAC[n].MAC[4], BuffMAC[n].MAC[5],
					BuffMAC[n].IP[2], BuffMAC[n].IP[3], BuffMAC[n].IP[4], BuffMAC[n].IP[5]);
#endif		 		 
		 n++;
    	}
// printf("Position: %d\r\n", n);
// printf("\r\n");

 if (n)
	{
	 for (i=0; i<n; i++)
	 	{
	 	 if ((BuffMAC[i].IP[2]==192)||(BuffMAC[i].IP[2]==172)||(BuffMAC[i].IP[2]==10))			// Check IP class A, B, and C
	 	 	{
			 strcat((char*)ethName, (char*)BuffMAC[i].Name);
			 memcpy(mac_address, BuffMAC[i].MAC, 6);
			 sprintf((char*)ip_address, "%d:%d:%d:%d", BuffMAC[i].IP[2],BuffMAC[i].IP[3], BuffMAC[i].IP[4], BuffMAC[i].IP[5]);
			 sprintf((char*)mac_addressstr, "%02X%02X%02X%02X%02X%02X", BuffMAC[i].MAC[0], BuffMAC[i].MAC[1],BuffMAC[i].MAC[2], BuffMAC[i].MAC[3], BuffMAC[i].MAC[4], BuffMAC[i].MAC[5]);
			 printf("MAC Addr: %s\r\n", mac_addressstr);
			 printf("Name LAN Success: %s\r\n", (char*)ethName);
			 printf("IP: %s  --> %d.%d.%d.%d\r\n", ip_address, BuffMAC[i].IP[2], BuffMAC[i].IP[3], BuffMAC[i].IP[4], BuffMAC[i].IP[5]);
	 	 	}
	 	}
	}
}

