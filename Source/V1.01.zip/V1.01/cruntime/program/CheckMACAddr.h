#ifndef CHECKMACADDR_H
#define CHECKMACADDR_H


#define kMaxNetwork	16

struct stNetMACIP{
	char Name[64];
	unsigned char MAC[6];
	unsigned char IP[6];
};


extern unsigned char mac_address[6];
extern char ip_address[30];
extern char mac_addressstr[30];

void CheckIPAddr(void);
void CheckMACAddr(void);
//void *CheckMACAdd(void* args);
#endif
