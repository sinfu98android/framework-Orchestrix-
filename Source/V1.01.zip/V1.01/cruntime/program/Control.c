#include "Control.h"
#include "System.h"
#include "IOProcess.h"
#include <sys/types.h>
#include <stdio.h>
#include "UART.h"
//#include "UART2.h"
#include "PLCProtocol.h"
#include "ModbusTCP.h"
#include "Project.h"
#include "ADS1256.h"
#include "CheckMACAddr.h"
#include "PLC.h"
#include "WEBClient.h"
#include "cache.h"

int					TickSampling=0;
pthread_cond_t cond_control = PTHREAD_COND_INITIALIZER; 
pthread_mutex_t lock_control = PTHREAD_MUTEX_INITIALIZER; 
int				CPUtemp, CPULoad,CPUMem;

void *ControlProcess(void* args)
{
 printf("Control Run ....\r\n");
 InitProjectProcess();
 InitADS1256(); 
 InitIO();
 IOdat.Output.OutputDat[0]=0x00;
 updateIO=kTRUE;
 while(1)
	{
	 IOdatProc.Output.OutputDat[0]=IOdatVir.Output.OutputDat[0];
	 IOdatProc.Input.InputDat[0]=IOdat.Input.InputDat[0];
#ifdef PLC
		PLCProcess();
#else
	 	ProjectProcess();
#endif

 	 if (FlagsSystem.Tick1mS) PLCProtocolProcess();

	 IOdat.Output.OutputDat[0]=IOdatProc.Output.OutputDat[0];
 	 IOProcess();
	 if (FlagsSystem.Tick1S) printf("testing \r\n");
	 SystemProcess();
	 usleep(1000);
	}
 pthread_mutex_unlock(&lock_control); 	
 exit(0);
}
