#ifndef CONTROL_H
#define CONTROL_H
#include <pthread.h> 
#include <stdio.h> 
#include <unistd.h> 
#include <sys/types.h>
#include <stdlib.h>
#include "stdint.h"


extern pthread_cond_t cond_control ;
extern pthread_mutex_t lock_control;
extern int	CPUtemp, CPULoad,CPUMem;

void *ControlProcess(void* args);

#endif
