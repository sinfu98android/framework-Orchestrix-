#ifndef EMAIL_H
#define EMAIL_H

void SendEmail(void);
#endif