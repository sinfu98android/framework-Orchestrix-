#include "Flash.h"
#include <stdio.h>
#include <stdint.h>
#include "Modbus.h"
#include "System.h"



void STORE_DATA(void)
{
 FILE 	*fp;
 unsigned char	*pDat;

 return;
 
 VarModbus.VarProject.SaveParameter=kFALSE;
 printf("Saving Parameter\r\n");
 fp = fopen("parameter.dat", "w");
 pDat=(unsigned char *)&VarModbus.BuffByte[0];
 fwrite(pDat, 2000, 1, fp);	//kSizeofModbusFile
 fclose(fp);
 printf("Saving Parameter Success !!!\r\n");
}


void LOAD_DATA(void)
{
  FILE 	*fp;
  //unsigned char	*pDat;

  return;
  
 if ((fp = fopen("parameter.dat", "r")) == NULL)
		{
		  printf("File parameter Fail !!!! ");
		 return;
		}
 else
		{
		 fread(VarModbus.BuffByte, kSizeofModbusFile, 1, fp);
		 fclose(fp);
		}
}