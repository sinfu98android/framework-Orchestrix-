#ifndef FLASH_H
#define FLASH_H

#define kMaxSizeCode		1000000

extern char BuffCode[kMaxSizeCode];

void STORE_DATA(void);
void LOAD_DATA(void);
void OPEN_CODE(void);

#endif