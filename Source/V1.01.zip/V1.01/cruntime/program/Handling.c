#include "Handling.h"
#include "UART.h"
//#include "UART2.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/io.h>
#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include "System.h"
#include <termios.h>
#include "PLCProtocol.h"

#if 0
void *HandlingTask(void* args)
{

  while (1) 
	{
	 if ((UARTRdy[0]==kFALSE)&&(PLCType[0]>kNoPLC))
		{
		 printf("Init UART 0.... UARTRdy: %d\r\n", UARTRdy[0]);
		 if (PLCType[0]==kMitsubishi) InitUART(0, 0, B9600, kEVEN_PARITY, k7_BIT, k1_STOP);
		 else if (PLCType[0]==kOmron) InitUART(0, 0, B9600, kEVEN_PARITY, k7_BIT, k2_STOP);		// EVEN, 7 Bit, 2 Stop bit
		 else if (PLCType[0]==kLC_AND) InitUART(0, 0, B9600, kNO_PARITY, k8_BIT, k1_STOP);
		 else if (PLCType[0]==kModbus) InitUART(0, 1, B115200, kNO_PARITY, k8_BIT, k1_STOP);
		} 
	else
		{
		 if (((UART_RESPONE[0]==kTRUE)&&(PLCType[0]>kNoPLC))||
		 	(PLCType[0]==kNoPLC))
		 		{
			 	  if ((UARTRdy[1]==kFALSE)&&(PLCType[1]>kNoPLC))
			 	 	{
					 printf("Init UART 1....\r\n");
					 if (PLCType[1]==kMitsubishi) InitUART(1, 0, B9600, kEVEN_PARITY, k7_BIT, k1_STOP);
					 else if (PLCType[1]==kOmron) InitUART(1, 0, B9600, kEVEN_PARITY, k7_BIT, k2_STOP);		// EVEN, 7 Bit, 2 Stop bit
					 else if (PLCType[1]==kLC_AND) InitUART(1, 0, B9600, kNO_PARITY, k8_BIT, k1_STOP);
					 else if (PLCType[1]==kModbus) InitUART(1, 1, B115200, kNO_PARITY, k8_BIT, k1_STOP);
			 	 	}
				 else 
				 	{
				 	 if (((UART_RESPONE[1]==kTRUE)&&(PLCType[1]>kNoPLC))||
					 	(PLCType[1]==kNoPLC))
				 	 	 {
					 	  if ((UARTRdy[2]==kFALSE)&&(PLCType[2]>kNoPLC))
					 	 	{
							 printf("Init UART 2....\r\n");
							 if (PLCType[2]==kMitsubishi) InitUART(2, 0, B9600, kEVEN_PARITY, k7_BIT, k1_STOP);
							 else if (PLCType[2]==kOmron) InitUART(2, 0, B9600, kEVEN_PARITY, k7_BIT, k2_STOP);		// EVEN, 7 Bit, 2 Stop bit
							 else if (PLCType[2]==kLC_AND) InitUART(2, 0, B9600, kNO_PARITY, k8_BIT, k1_STOP);
							 else if (PLCType[2]==kModbus) InitUART(2, 1, B115200, kNO_PARITY, k8_BIT, k1_STOP);
					 	 	}							  
					 	 }
				 	}				  
			 	}
		}	
	 usleep(100000);
	}
 exit(0);
}
#endif
