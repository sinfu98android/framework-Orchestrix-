#ifndef HANDLING_H
#define HANDLING_H
#include <stdint.h>

#if 0
void *HandlingTask(void* args);
#endif
#endif