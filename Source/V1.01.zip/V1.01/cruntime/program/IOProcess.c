#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/io.h>
#include <sys/types.h>
#include <fcntl.h>
#include "IOProcess.h"
#include "Control.h"
#include <time.h>
#include "MiscDataConv.h"
#include "PLCProtocol.h"
#include <sys/types.h>
//#include <wiringPi.h>
#ifdef PCIO
	#include "ParalelLPT.h" 
#endif

#ifdef ORANGEPI
	#include <armbianio.h>
//	#include "ADS1256.h"
	#include "orangepiIO.h"
#endif

#include "System.h"
#include "Project.h"


struct stIOVar	IOdat;
struct stIOVar	IOdatProc;
struct stIOVar	IOdatVir;
int				ForceInput;

pthread_cond_t cond = PTHREAD_COND_INITIALIZER; 
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;


//unsigned char testIO;
unsigned char updateIO;
int			tickIO=0;
int			countScaler;
short		testIO;

void InitIO(void)
{

 #ifdef ORANGEPI
	 InitOrangepiIO();
 #endif
 printf("Init IO OK...\r\n");

 #ifdef PCIO
	InitIO_LPT();
 #endif

 IOdat.Input.InputDat[0]=0;
 IOdat.Output.OutputDat[0]=0;
}


void IOProcess(void)
{
 IOdat.Input.InputDat[0]=IOdatVir.Input.InputDat[0];
#ifdef ORANGEPI
 UpdateSerIO();
#endif

#if 0
#ifdef PLCIO
 if (PLCParam[0].PLCType==kMitsubishi)
 	{
 	 DataPLC_TX[0].DataWord[100]=IOdat.Output.OutputDat[0];
	 IOdat.Input.InputDat[0]|=DataPLC_RX[0].DataWord[0];
 	}
 else if (PLCParam[0].PLCType==kModbus)
 	{
 	 DataPLC_TX[0].DataWord[20]=IOdat.Output.OutputDat[0];
	 IOdat.Input.InputDat[0]|=DataPLC_RX[0].DataWord[0];
//	 if (FlagsSystem.Tick1S) printf("here... %d  %d\r\n", DataPLC_TX[0].DataWord[20], IOdat.Output.OutputDat[0]);
 	}
#endif
#endif
#ifdef PCIO
// IOdat.Output.OutputDat[0]=0x00;
 UpdateLPTIO();
#endif
}

void CloseIO(void)
{
#ifdef PCIO
	CloseLPT();
#endif
}
