#ifndef IOPROCESS_H
#define IOPROCESS_H
//#define ORANGEPI
#include <stdint.h>
#include <pthread.h> 

//#define ORANGEPI
//#define PCIO
//#define   PLCIO


#define kMaxOutput		16
#define kMaxInput		16

struct stIOBit{
	unsigned int	Bit0	:1;
	unsigned int	Bit1	:1;
	unsigned int	Bit2	:1;
	unsigned int	Bit3	:1;
	unsigned int	Bit4	:1;
	unsigned int	Bit5	:1;
	unsigned int	Bit6	:1;
	unsigned int	Bit7	:1;	
	unsigned int	Bit8	:1;
	unsigned int	Bit9	:1;
	unsigned int	Bit10	:1;
	unsigned int	Bit11	:1;
	unsigned int	Bit12	:1;
	unsigned int	Bit13	:1;
	unsigned int	Bit14	:1;
	unsigned int	Bit15	:1;
	unsigned int	Bit16	:1;
	unsigned int	Bit17	:1;
	unsigned int	Bit18	:1;
	unsigned int	Bit19	:1;
	unsigned int	Bit20	:1;
	unsigned int	Bit21	:1;
	unsigned int	Bit22	:1;
	unsigned int	Bit23	:1;	
	unsigned int	Bit24	:1;
	unsigned int	Bit25	:1;
	unsigned int	Bit26	:1;
	unsigned int	Bit27	:1;
	unsigned int	Bit28	:1;
	unsigned int	Bit29	:1;
	unsigned int	Bit30	:1;
	unsigned int	Bit31	:1;	
};

union uOutput{
	struct stIOBit		Bit;
	uint32_t			OutputDat[kMaxOutput>>1];
	uint16_t			OutWord[kMaxOutput];
	uint8_t				OutByte[kMaxOutput<<1];
};

union uInput{
	struct stIOBit		InputBit;
	uint32_t			InputDat[kMaxInput>>1];
	uint16_t			InWord[kMaxInput];
	uint8_t				InByte[kMaxInput<<1];
};


struct stIOVar{
	union uOutput	Output;
	union uInput		Input;	
};


extern struct stIOVar	IOdat, IOdatProc;
extern struct stIOVar	IOdatVir;
extern unsigned char 	updateIO;
extern pthread_cond_t 	cond;
extern pthread_mutex_t 	lock;
extern int				ForceInput;

void InitIO(void);
void *IOTask(void* args);
void CloseIO(void);
void IOProcess(void);
void UpdateSerIO(void);


#endif
