#ifndef MISC_DATA_CONV
#define MISC_DATA_CONV
#include "stdint.h"


enum eVarType{
	k8Bit,
	k16Bit,
	k32Bit,
};


extern const unsigned int 	kBitTable[];
//extern struct stModbus		ModbusReceive;
extern short counting;

unsigned int CalculateCRC(unsigned char * pBuff, short size);
unsigned char NibleHexToASCII(unsigned char val);
void Int2Hex(uint32_t val, unsigned char digit, char* dest);
unsigned char ASCIINibleToBin(unsigned char ASCINible);
short ASCIIHexToBin(unsigned char *pBuf);
short ASCIIHexToBin_16Bit_2nd_Mode(unsigned char *pBuf, enum eVarType VarType);
unsigned char CalculateFCS(unsigned char *pdat, short size);			// XOR Function
void LoadString(char *pSrc, char *pDes);
char *my_itoa(long long int num, char *str);
void FloatToStr(float val, char* str, unsigned char  decimal);
int strToInt(char *str);
int strpos(char * pSub, char *pStr);
void strcpyPos(char *pSrc, char *pDest, int Pos, char Delimiter);
unsigned char CmpStr(char *pSrc1, char *pSrc2);
#endif
