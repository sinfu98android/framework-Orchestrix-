#include "MitsubishiProtocol.h"
#include "UART.h"
#include "System.h"
#include "PLCProtocol.h"


#define kSTX		0x02
#define kETX		0x03
#define kEOT    	0x04
#define kENQ		0x05
#define kACK		0x06
#define kNACK		0x15

#define kGetData	0x01
#define kSetData	0x11
#define kGetM		0x03
#define kSetM		0x04
#define kGetX		0x05
#define kGetY		0x06


unsigned short	 	testTick;



unsigned char CalCheckSum(unsigned char *pBuff, short buffsize)
{
 short i;
 unsigned char temp;
 
 temp=0;
 for (i=0; i<buffsize; i++)
 	{
 	 temp+=*pBuff++;
 	}
 return(temp);
}



unsigned char NibleToASCIIHex(unsigned char val)
{
 unsigned char temp;
 
 if ((val>=0)&&(val<=9)) temp=val+'0';
 else if ((val>=10)&&(val<=15)) temp=(val-10)+'A';
 else temp=0;
 return(temp);
}


void InitMitsubishiProtocol(unsigned char idx)
{
// StatePLC[idx]=kIdleState_PLC;	//kReadPLC;
}



void ReadDataMitsubishi(unsigned char idx, unsigned short Addr, unsigned short Total)
{
 unsigned char checksum;
 unsigned char cmd, datasize;
 short		  addr,size;
// struct stBuffUART	*pBuffUART;

// pBuffUART=pVarHMI->PLCID.pBuffUART;	//pVarHMI->PLCID->pBuffUART;
 cmd=kGetData;
 addr=Addr<< 1;
 size=Total << 1;
 BuffRX[idx][0]=kSTX;
 BuffRX[idx][1]=NibleToASCIIHex((unsigned char)(cmd>>4)&0x0F);
 BuffRX[idx][2]=NibleToASCIIHex((unsigned char) cmd & 0x0F);
 BuffRX[idx][3]=NibleToASCIIHex((unsigned char) (addr>>8) & 0x0F);	//pVarHMI->Addr>>8)&0x0F);
 BuffRX[idx][4]=NibleToASCIIHex((unsigned char) (addr>>4)&0x0F);
 BuffRX[idx][5]=NibleToASCIIHex((unsigned char) (addr)&0x0F);
 BuffRX[idx][6]=NibleToASCIIHex((unsigned char)(size>>4)&0x0F);
 BuffRX[idx][7]=NibleToASCIIHex((unsigned char) size & 0x0F);
 BuffRX[idx][8]=kETX;
 checksum=CalCheckSum(&(BuffRX[idx][1]), 8);
 BuffRX[idx][9]=NibleToASCIIHex(checksum>>4);
 BuffRX[idx][10]=NibleToASCIIHex(checksum & 0x0F);
 datasize=11;
 SendUART(idx, datasize);
 StartReceiveUART(idx);
}



void WriteDataMitsubishi(unsigned char idx, unsigned short Addr, unsigned short Total)
{
 unsigned char checksum;
 unsigned char cmd, datasize, i;
 short		  addr,size;
 short 			temp;

// printf("Write MITSUBISHI !!!\r\n");
 cmd=kSetData;
 addr=Addr << 1;
 size=Total<< 1;
 BuffRX[idx][0]=kSTX;
 BuffRX[idx][1]=NibleToASCIIHex((unsigned char)(cmd>>4)&0x0F);
 BuffRX[idx][2]=NibleToASCIIHex((unsigned char) cmd & 0x0F);
 BuffRX[idx][3]=NibleToASCIIHex((unsigned char) (addr>>8) & 0x0F);	//pVarHMI->Addr>>8)&0x0F);
 BuffRX[idx][4]=NibleToASCIIHex((unsigned char) (addr>>4)&0x0F);
 BuffRX[idx][5]=NibleToASCIIHex((unsigned char) (addr)&0x0F);
 BuffRX[idx][6]=NibleToASCIIHex((unsigned char)(size>>4)&0x0F);
 BuffRX[idx][7]=NibleToASCIIHex((unsigned char) size & 0x0F);
 for (i=0; i<Total; i++)
 	{
 	 temp=DataPLC_TX[idx].DataWord[Addr+i];
	 BuffRX[idx][8+(i <<2)]=NibleToASCIIHex((unsigned char)(temp>>4)&0x0F);
	 BuffRX[idx][9+(i <<2)]=NibleToASCIIHex((unsigned char)(temp&0x0F));
	 BuffRX[idx][10+(i <<2)]=NibleToASCIIHex((unsigned char)(temp>>12)&0x0F);
	 BuffRX[idx][11+(i <<2)]=NibleToASCIIHex((unsigned char)(temp>>8)&0x0F);
 	}
 BuffRX[idx][8+(Total<<2)]=kETX;
 checksum=CalCheckSum(&(BuffRX[idx][1]), 8+(Total<<2));
 BuffRX[idx][13]=NibleToASCIIHex(checksum>>4);
 BuffRX[idx][14]=NibleToASCIIHex(checksum & 0x0F);
 datasize=11+(Total<<2);
 SendUART(idx, datasize);
 StartReceiveUART(idx); 
}

#if 0
unsigned char SendToMitsubishi(struct stVarHMI *pVarHMI)
{
 unsigned char datasize;
 
 if (pVarHMI->Param.cmd==kCmdReadData) datasize=GetDataMitsubishi(pVarHMI);
 else if (pVarHMI->Param.cmd==kCmdWriteData) datasize=SetDataMitsubishi(pVarHMI);
 return(datasize);
}
#endif


unsigned char CheckSumMitsubishi(unsigned char idx)
{
 unsigned char 	checksum;
 unsigned char	 buff[2];

 checksum=CalCheckSum(&(BuffRX[idx][1]), ptrRX[idx]-3);
 buff[0]=NibleToASCIIHex(checksum>>4);
 buff[1]=NibleToASCIIHex(checksum & 0x0F);
 if ((buff[0]=BuffRX[idx][ptrRX[idx]-2])&&(buff[1]=BuffRX[idx][ptrRX[idx]-1])&&(BuffRX[idx][0]==kSTX)) return(kTRUE);
 return(kFALSE);
}


unsigned char ParseMitsubishi(unsigned char idx)
{
 short			i;
 unsigned char	Status;
 
 Status=kFALSE;
// if (PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat)
 if (WriteStat[idx])
 	{
 	 if (BuffRX[idx][ptrRX[idx]-1]==kACK)
 	 	{
 	 	 Status=kTRUE;
//		 PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat=kFALSE;
		 WRStatusCOM[idx][AddrCOM[idx]]=kFALSE;
 		 WriteStat[idx]=kFALSE;
		}
 	 else
 	 	{
 	 	 BuffRX[idx][0]=kEOT;
 	 	 SendUART(idx, 1);
 	 	} 	
 	}
 else
 	{
	 if (CheckSumMitsubishi(idx))
	 	{
		 Status=kTRUE; 	
		 for (i=0; i<ComTot[idx]; i++)
	 	 	{
	 	 	 DataPLC_RX[idx].DataWord[ComAddr[idx]+i]=ASCIIHexToBin(&(BuffRX[idx][1+(i<<2)]));
	 	 	}
//	  	 printf("Total %d %d,  Data: %d %x %x %x %x %x %x %x\r\n", testTick, ptrRX[idx], DataPLC_RX.DataWord[0], DataPLC_RX.DataWord[1], DataPLC_RX.DataWord[2], DataPLC_RX.DataWord[3], DataPLC_RX.DataWord[4],DataPLC_RX.DataWord[5], DataPLC_RX.DataWord[6], DataPLC_RX.DataWord[7]);
	 	}
 	}
if (Status)
	{
	 TickCOM_[idx]++;
	}
return(Status);
}



void MitsubishiProtocolProcess(unsigned char idx)
{
//unsigned char temp;

 //if (StatePLC[idx]==kIdleState_PLC) StatePLC[idx]=kReadPLC;
 int n;
 
 for (n=0; n<kMaxBuffDEV; n++)
	{
	 if (WRStatusCOM[idx][n])
		{
		 AddrCOM[idx]=n;
		 WriteStat[idx]=kTRUE;
		 break;
		}
	}

 if (ReceiveComplete[idx])
	 {
	   if (ParseMitsubishi(idx)) 
	   	{
   	 	 PLCParam[idx].Queue++;
		 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kNULL_DataType) PLCParam[idx].Queue=0;
	   	 Respond[idx]=kTRUE;
		 TrialRespone[idx]=0;
		 UART_RESPONE[idx]=kTRUE;
		 DetectModem=IdxModem;		 
	   	}
 	  ptrRX[idx]=0;
	  ReceiveComplete[idx]=kFALSE;
	}


#if 1
 if ((FlagsSystem.Tick1mS)||(Respond[idx]))
	 {
	  if (TimeOutResp[idx]) TimeOutResp[idx]--;
	  if ((TimeOutResp[idx]==0)||(Respond[idx]))
		{
		 if (TimeOutResp[idx]==0)
		 	{
		 	 TrialRespone[idx]++;
			 if (TrialRespone[idx]>=3)
			 	{
			 	 if (UART_RESPONE[idx]==kFALSE)
			 	 	{
			 	 	 UARTRdy[idx]=kFALSE;
					 CloseUART(idx);
			 	 	}
			 	}
		 	}
		 if ((Respond[idx])&&(DlyCOM[idx]<1))
			{
			 DlyCOM[idx]++;
			}
		 else
			{
			 if (WriteStat[idx])
				{
				 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_Data)
				 	{
					 ComAddr[idx]=AddrCOM[idx];	//PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;		// 100;
					 ComTot[idx]=1;				//PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;		// 1
					 WriteDataMitsubishi(idx, ComAddr[idx], ComTot[idx]);
					 DlyCOM[idx]=0;
					 TimeOutResp[idx]=kTimeOutResp;	//8;
					 Respond[idx]=kFALSE;
				 	}
				}
			 else
				{
				 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_Data)
				 	{
					 ComAddr[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;		//0;
					 ComTot[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;		//8;	//4;
					 ReadDataMitsubishi(idx, ComAddr[idx], ComTot[idx]);
					 DlyCOM[idx]=0;
					 TimeOutResp[idx]=kTimeOutResp;  //8;
					 Respond[idx]=kFALSE;
				 	}
				}
			}
		}
	}
#endif 
}
