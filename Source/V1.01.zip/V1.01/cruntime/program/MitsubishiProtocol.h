#ifndef MITSUBISHI_PROTOCOL_H
#define MITSUBISHI_PROTOCOL_H
#include "MiscDataConv.h"

void InitMitsubishiProtocol(unsigned char idx);
void MitsubishiProtocolProcess(unsigned char idx);
//unsigned char SendToMitsubishi(struct stVarHMI *pVarHMI);
//unsigned char ParseMitsubishi(struct stVarHMI *pVarHMI);
#endif

