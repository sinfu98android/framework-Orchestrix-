#include "Modbus.h"
#include "System.h"
#include "UART.h"
//#include "UARTHandler.h"
#include <stdio.h>
#include <stdlib.h>
#include "PLCProtocol.h"

unsigned char 				totaldata;
unsigned char 				Test;
unsigned char 				SlaveAddr;
unsigned short				OffsetAddr;
unsigned char 				Status;
unsigned short				TimeoutDev;
struct stHMIvar				Current;
struct stHMIvar				TableVarHMI[kMaxVarHMI];
unsigned short				pTableVarHMI;
unsigned char					ModbusMode;
union uVarModbus				VarModbus;
union uVarModbus2			VarModbus2;
union uVarModbusFlags			FlagsModbus;
struct stModbus				ModbusReceive;
unsigned char 				Buff_[64];
unsigned int					Testing;
unsigned short				COMTick_, COMTick;
unsigned char					DataValid;
struct stModbus				ModbusReceive;



void GetCoil(unsigned int Addr, unsigned char Tot)	// Tot in bytes
{
 unsigned int temp1, temp2;
 unsigned int i, j;

 temp1=Addr >> 3;
 temp2=Addr % 8;
 for(i=0; i<Tot; i++) Buff_[i]=FlagsModbus.CoilModbus[temp1+i];
 for (i=0; i<temp2; i++)
 	 {
	  for (j=0; j<Tot; j++)
	  	  {
		   Buff_[j]<<=1;
		   if (Buff_[j+1] & 0x80) Buff_[j]|=0x01;
	  	  }
 	 }
}

void SetCoil(unsigned int Addr, unsigned char val)
{
 unsigned int temp1, temp2;

 temp1=Addr >>3;
 temp2=Addr % 8;
 if (val) FlagsModbus.CoilModbus[temp1]|=kBitTable[temp2];
 else FlagsModbus.CoilModbus[temp1]&=(~kBitTable[temp2]);
}


void ReadHoldingData(unsigned char idx, unsigned char SlaveAddr, unsigned short Addr, unsigned short Total)
{
 #if 1
 unsigned short crc;

 BuffRX[idx][0]=SlaveAddr ;
 BuffRX[idx][1]=kReadHoldingRegister;
 BuffRX[idx][2]=Addr>> 8;
 BuffRX[idx][3]=Addr& 0xFF;
 BuffRX[idx][4]=Total>> 8;
 BuffRX[idx][5]=Total & 0xFF;
 crc=CalculateCRC(&BuffRX[idx][0], 6);
 BuffRX[idx][6]=crc & 0xFF;
 BuffRX[idx][7]=crc >> 8;
 SendUART(idx, 8);
 StartReceiveUART(idx); 
 //printf("Sending Modbus !!!\r\n");
#endif 
 return;
}


void WriteContinousData(unsigned char idx, unsigned char SlaveAddr, unsigned short Addr, unsigned short Total)
{
 unsigned short n;
 unsigned short crc;

 BuffRX[idx][0]=SlaveAddr;
 BuffRX[idx][1]=kWriteContinousData;
 BuffRX[idx][2]=Addr>> 8;
 BuffRX[idx][3]=Addr & 0xFF;
 BuffRX[idx][4]=Total>> 8;
 BuffRX[idx][5]=Total & 0xFF;
 BuffRX[idx][6]=Total<<1; 
 for (n=0; n<Total; n++)
 	{
 	 BuffRX[idx][7+n*2]=DataPLC_TX[idx].DataWord[Addr+n]>>8;
 	 BuffRX[idx][8+n*2]=DataPLC_TX[idx].DataWord[Addr+n];
 	}
 crc=CalculateCRC(&BuffRX[idx][0], 7+(Total*2));
 BuffRX[idx][7+(Total*2)]=crc & 0xFF;
 BuffRX[idx][8+(Total*2)]=crc >> 8;
 SendUART(idx, 9+(Total*2));
 StartReceiveUART(idx);
 return;
}


void InitModbus(unsigned char idx)
{
 //StatePLC[idx]=0;	//kIdleState_PLC;	//kReadPLC;
}


unsigned char CheckCRC(unsigned idx)
{
 unsigned short crc;

 crc=CalculateCRC(&BuffRX[idx][0], ptrRX[idx]-2);
 if (((crc & 0xFF)==BuffRX[idx][ptrRX[idx]-2]) && ((crc >>8)==BuffRX[idx][ptrRX[idx]-1]) && (DevNum[idx]==BuffRX[idx][0])) 
 	{ 	 
 	 COMTick_++;
 	 return(kTRUE);
 	 }
 else return(kFALSE);
}


unsigned char ParseModbusMaster(unsigned char idx)
{
 uint16_t 	n, temp;
 unsigned char stat;

 stat=kFALSE;
 if (CheckCRC(idx))
	{
	 stat=kTRUE;
	 if (BuffRX[idx][1]==kReadHoldingRegister)
	 	{
		 for (n=0; n<ComTot[idx]; n++)
		 	 {
			  temp=BuffRX[idx][3+(n*2)]<<8;
			  temp|=BuffRX[idx][4+(n*2)];
			  DataPLC_RX[idx].DataWord[ComAddr[idx]+n]=temp;
		 	 }
	 	}
	 else if (BuffRX[idx][1]==kWriteContinousData)
	 	{
	 	 //PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat=kFALSE; 	 
		 WRStatusCOM[idx][AddrCOM[idx]]=kFALSE;
 		 WriteStat[idx]=kFALSE;
		 IdxWR[idx]++;
	 	}
	}
 return(stat);
}



void ModbusProcess(unsigned char idx)
{
 //printf("Here...\r\n");
 #if 1
 int n;
 for (n=0; n<kMaxBuffDEV; n++)
   {
	if (WRStatusCOM[idx][n])
	   {
		AddrCOM[idx]=n;
		WriteStat[idx]=kTRUE;
		break;
	   }
   }
 #endif

 #if 0
 if (WRStatusCOM[idx][IdxWR[idx]])
	{
	 AddrCOM[idx]=IdxWR[idx];
	 WriteStat[idx]=kTRUE;
//	 break;
	}
 else IdxWR[idx]++;
 #endif
 
// if (StatePLC[idx]==kIdleState_PLC) StatePLC[idx]=kReadPLC;
 if (CheckCRC(idx)&&(ptrRX[idx]>5)) ReceiveComplete[idx]=kTRUE;
 if (ReceiveComplete[idx])
	 {
	   if (ParseModbusMaster(idx)) 
	   	{
	   	 //printf("Modbus Receive !!!!!!!!!!!!!!!!!!!!!!!!\r\n");
	   	 TickCOM_[idx]++;
	   	 Respond[idx]=kTRUE;
		 TrialRespone[idx]=0;
		 UART_RESPONE[idx]=kTRUE;
		 DetectModem=IdxModem;	
		 PLCParam[idx].Queue++;
		 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kNULL_DataType) PLCParam[idx].Queue=0;
	   	}
//	  if (StatePLC[idx]==kReadPLC) StatePLC[idx]=kWritePLC;
//	  else if (StatePLC[idx]==kWritePLC) StatePLC[idx]=kReadPLC;
//	  StatePLC[idx]=kReadPLC;
 	  ptrRX[idx]=0;
	  ReceiveComplete[idx]=kFALSE;
	}


#if 1
 if ((FlagsSystem.Tick1mS)||(Respond[idx]))
	  {
	   if (TimeOutResp[idx]) TimeOutResp[idx]--;
	   if ((TimeOutResp[idx]==0)||(Respond[idx]))
		 {
		  if (TimeOutResp[idx]==0)
		 	 {
		 	 TrialRespone[idx]++;
			 if (TrialRespone[idx]>=3)
			 	{
			 	 if (UART_RESPONE[idx]==kFALSE)
			 	 	{
			 	 	 UARTRdy[idx]=kFALSE;
					 CloseUART(idx);
			 	 	}
			 	}
		 	}
		 if ((Respond[idx])&&(DlyCOM[idx]<1))
			{
			 DlyCOM[idx]++;
			}
		 else
			{
			 //if (PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat)					// Write
			 if (WriteStat[idx])
			 	{
			 	 //printf("!!!!!! Modbus IO  %d\r\n", AddrCOM[idx]);
				 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_HoldingReg) 	
			 	 	{
			 	 	 ComAddr[idx]=0;	//0;	//AddrCOM[idx];				//PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;
					 ComTot[idx]=58;	//1;								//PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;				 
					 DevNum[idx]=PLCParam[idx].DevNum;
					 WriteContinousData(idx, DevNum[idx], ComAddr[idx],ComTot[idx]);
					 DlyCOM[idx]=0;
					 TimeOutResp[idx]=kTimeOutResp;	//8;
					 Respond[idx]=kFALSE;
				 	}			 	 
			 	}
			 else
			 	{
				 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_HoldingReg) 	// Read
			 	 	{
			 	 	 ComAddr[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;
					 ComTot[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;
					 DevNum[idx]=PLCParam[idx].DevNum;
					 ReadHoldingData(idx, DevNum[idx], ComAddr[idx],ComTot[idx]);
					 DlyCOM[idx]=0;
					 TimeOutResp[idx]=kTimeOutResp;  //8;
					 Respond[idx]=kFALSE;
			 	 	}		 	
			 	}
			}
		}
	}
#endif 
}

