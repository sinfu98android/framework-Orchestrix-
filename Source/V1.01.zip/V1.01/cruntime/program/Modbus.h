#ifndef MODBUS_H
#define MODBUS_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include "MiscDataConv.h"
#include "Project.h"

#define 	kCmdNull							0x00
#define	kReadCoil							0x01		// Max 1bit
#define	kReadBitData					0x02		// Max 8 bits
#define	kReadHoldingRegister		0x03		// Max 60 words
#define	kReadInputRegister			0x04		// Max 15 words
#define	kWriteCoil							0x05		// Max 1 bit
#define	kWriteHoldingRegister		0x06		// Max 1 word
#define	kWriteContinousData		0x10		// Max 60 words	// This not support now

#define kModbusSlaveMode	0
#define kModbusMasterMode	1


#define kMaxVarHMI		100
#define kMaxBuffLocal	4096

#define kMaxModbusData	kMaxBuffLocal

struct stHMIvar{
	unsigned char 	SlaveAddr;
	unsigned char 	FunctionCode;
	unsigned short	OffAddr;
	unsigned short	Total;
	unsigned short	LocalDest;
};


struct stLC_AND4406A{
	uint32_t				CPUCycle;									//  40001
	uint32_t				Tick;											// 40003
	float					LC_AND4406A[5];					//  40005-14
};

union uVarModbus{
	unsigned char					BuffByte[kMaxModbusData*2];
	uint16_t 	 					DataModbus[kMaxModbusData];
	uint32_t						BuffMem[kMaxModbusData/2];
	struct stProjectProcess			VarProject;
};
#define kSizeofModbusFile		sizeof(union uVarModbus)/sizeof(unsigned char)



union uVarModbus2{
	unsigned char					BuffByte[kMaxModbusData*2];
	uint16_t 	 					DataModbus[kMaxModbusData];
	uint32_t						BuffMem[kMaxModbusData/2];
	struct stLC_AND4406A			VarAND4406A;
};
#define kSizeofModbusFile		sizeof(union uVarModbus)/sizeof(unsigned char)

union uVarModbusFlags{
	unsigned char 			CoilModbus[10];
};

#if 1
union uDataModbus{
	unsigned int		TotalData;
	unsigned int		Data[32];
};


struct stModbus{
	unsigned char			DeviceNumber;
	unsigned char 			FunctionCode;
	unsigned int 			OffsetAddr;
	union uDataModbus		Data;
	
};
#endif


//extern unsigned short			BuffLocal[kMaxBuffLocal];
extern union uVarModbus			VarModbus;
extern union uVarModbus2		VarModbus2;
extern unsigned int				Testing;
extern unsigned short			COMTick_, COMTick;
extern unsigned char			DataValid;


void InitModbus(unsigned char idx);
void ModbusMasterProcess(unsigned char idx);
void ModbusProcess(unsigned char idx);
#endif 

