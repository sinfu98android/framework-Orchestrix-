#include "ModbusTCP.h"
#include "System.h"

//#define MAXMSG  		 8192

pthread_t 			idModbusServerTCP;  //, id2;
union uBuffer 		VarTCP[kMaxClient];
unsigned int			TickTCP, TickTCP_;
unsigned char			SlaveAddrTCP;
int16_t				OffsetAddrTCP, TotalData;
int					ClientIdx;
struct timeval		TimeOut;
unsigned int			ClientTimeOut[kMaxClient];




void DumpData(short Idx)
{
// if (VarTCP[Idx].TCPClient.FunctionCode!=0x03) 
  	{
	  printf("Slave Address:%d, FunctionCode:%d, OffsetAddr:%d, Total:%d\r\n", VarTCP[Idx].TCPClient.SlaveAddress, VarTCP[Idx].TCPClient.FunctionCode, (VarTCP[Idx].TCPClient.OffsetAddrMSB<<8)|VarTCP[Idx].TCPClient.OffsetAddrLSB, (VarTCP[Idx].TCPClient.TotalDataMSB<<8)|VarTCP[Idx].TCPClient.TotalDataLSB);
 	  printf("%d, %d, %d, %d, %d, %d, %d, %d\r\n", VarTCP[Idx].Buffer[0], VarTCP[Idx].Buffer[1],VarTCP[Idx].Buffer[2],VarTCP[Idx].Buffer[3],VarTCP[Idx].Buffer[4],VarTCP[Idx].Buffer[5],VarTCP[Idx].Buffer[6],VarTCP[Idx].Buffer[7]);
	  printf("%d, %d, %d, %d, %d, %d, %d, %d\r\n", VarTCP[Idx].Buffer[8], VarTCP[Idx].Buffer[9],VarTCP[Idx].Buffer[10],VarTCP[Idx].Buffer[11],VarTCP[Idx].Buffer[12],VarTCP[Idx].Buffer[13],VarTCP[Idx].Buffer[14],VarTCP[Idx].Buffer[15]); 
	  printf("Parsing\r\n");
 	}
}



int ParseModbusServer(short Idx)
{
 int 			stat;
 unsigned char 	Polling;
 short			n;

 stat=0;
 #if 0
	DumpData(Idx);
 #endif
 if (VarTCP[Idx].TCPClient.SlaveAddress==SlaveAddrTCP)
 	{
 	 if (VarTCP[Idx].TCPClient.FunctionCode==kReadHoldingRegister)			// Read Holding Register
 	 	{
 	 	 OffsetAddrTCP=(VarTCP[Idx].TCPClient.OffsetAddrMSB<<8)|(VarTCP[Idx].TCPClient.OffsetAddrLSB);
 	 	 TotalData=(VarTCP[Idx].TCPClient.TotalDataMSB<<8)|(VarTCP[Idx].TCPClient.TotalDataLSB);
 	 	 Polling=VarTCP[Idx].TCPClient.PollingCount;
 	 	 VarTCP[Idx].TCPServer.PollingCount=Polling;
 	 	 VarTCP[Idx].TCPServer.TotalDataByte=TotalData*2;
 	 	 VarTCP[Idx].TCPServer.TotalDataProtocol=3+VarTCP[Idx].TCPServer.TotalDataByte;
 	 	 for (n=0; n<TotalData; n++)
 	 	 	{
 	 	 	 VarTCP[Idx].Buffer[9+n*2]=VarModbus.DataModbus[OffsetAddrTCP+n]>>8;
 	 	 	 VarTCP[Idx].Buffer[10+n*2]=VarModbus.DataModbus[OffsetAddrTCP+n] & 0xFF;
 	 	 	}
 	 	 stat=VarTCP[Idx].TCPServer.TotalDataProtocol+6;
//		 Tick++;
//		 printf("Offset: %d   Total %d   Tick: %d\r\n", OffsetAddr, TotalData, Tick);
 	 	}
 	 else if (VarTCP[Idx].TCPClient.FunctionCode==kWriteContinousData)
 	 	{
 	 	 OffsetAddrTCP=(VarTCP[Idx].TCPClient.OffsetAddrMSB<<8)|(VarTCP[Idx].TCPClient.OffsetAddrLSB);
 	 	 TotalData=(VarTCP[Idx].TCPClient.TotalDataMSB<<8)|(VarTCP[Idx].TCPClient.TotalDataLSB);
 	 	 VarTCP[Idx].TCPServer.TotalDataProtocol=6;
 	 	 for (n=0; n<TotalData; n++)
 	 	 	{
	  	 	 VarModbus.DataModbus[OffsetAddrTCP+n]=(VarTCP[Idx].Buffer[n*2+13]<<8)|VarTCP[Idx].Buffer[n*2+14];
 	 	 	}
 	 	 stat=VarTCP[Idx].TCPServer.TotalDataProtocol+6;
 	 	}
 	}
 return(stat);
}



void *ModbusServer(void* args)
{
 int opt = kTRUE;
 int master_socket , addrlen , new_socket , client_socket[kMaxClient] , 
 max_clients = kMaxClient , activity, i , valread , sd;  
 int max_sd;  
 struct sockaddr_in address;  
 int				status;
 uint16_t			n;
                
    //set of socket descriptors 
 SlaveAddrTCP=1;
 sleep(2);
 fd_set readfds;  
         
    //a message 
 char *message = "";	//ECHO Daemon v1.0 \r\n";  
     
    //initialise all client_socket[] to 0 so not checked 
 for (i = 0; i < max_clients; i++)  
  	{  
     client_socket[i] = 0;  
    }  
         
 //create a master socket 
 while(1)
 	{
 	 sleep(2);
	 if( (master_socket = socket(AF_INET , SOCK_STREAM , 0)) == 0)  
	    {  
	     printf("socket failed \r\n");  
	   	}  
	 else break;
 	}
     
    //set master socket to allow multiple connections , 
    //this is just a good habit, it will work without this 
 while(1)
 	{
 	 sleep(2);
	 if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )  
	    {  
	     printf("setsockopt Failure !!!\r\n");  
	    }  
	 else break;
 	}
     
    //type of socket created 
address.sin_family = AF_INET;  
address.sin_addr.s_addr = INADDR_ANY;
address.sin_port = htons(PORT_MODBUS);
         
		 
 //bind the socket to localhost port 8888 
 //test=0;
 while(1)
 	{
     sleep(2);
	 if (bind(master_socket, (struct sockaddr *)&address, sizeof(address))<0)  
		{  
			printf("bind failed !!!\r\n");  
		}
	 else break;
 	}
printf("Listener on port %d \r\n", PORT_MODBUS);  

    //try to specify maximum of 3 pending connections for the master socket 
while(1)
	{
 	 sleep(1);
	 if (listen(master_socket, 3) < 0)  
	    {  
	        printf("listen failure !!!\r\n");  
	    }
	 else break;
	}
         
    //accept the incoming connection 
addrlen = sizeof(address);  
puts("Waiting for connections ...\r\n");  
         
while(1)  
    {  
     FD_ZERO(&readfds);  
     FD_SET(master_socket, &readfds);
     max_sd = master_socket;  
             
     for ( i = 0 ; i < max_clients ; i++)  
        {  
            //socket descriptor 
            sd = client_socket[i];  
            //if valid socket descriptor then add to read list 
            if(sd > 0)  
                FD_SET( sd , &readfds);  
            //highest file descriptor number, need it for the select function 
            if(sd > max_sd)  
                max_sd = sd;  
        }  

     TimeOut.tv_sec = 1;
	 TimeOut.tv_usec = 0;
     activity = select( max_sd + 1 , &readfds , NULL , NULL , &TimeOut);
	 
//		activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);  
     if ((activity < 0) && (errno!=EINTR))  
        {  
            printf("select error\r\n");  
        }  
             
        //If something happened on the master socket , 
        //then its an incoming connection 
     if (FD_ISSET(master_socket, &readfds))  
     	{     	
         if ((new_socket = accept(master_socket, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)  
           	{  
	         printf("accept Failure !!!!\r\n");  
			}  
             
            //inform user of socket number - used in send and receive commands 
          #ifdef DEBUG_SERVER_TCP
	      	printf("New connection , socket fd is %d , ip is : %s , port : %d \r\n" , new_socket , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));  
		  #endif
           
            //send new connection greeting message 
          if( send(new_socket, message, strlen(message), 0) != strlen(message) )  
	         {  
	                printf("send\r\n");  
	         }                   
		  #ifdef DEBUG_SERVER_TCP
	          puts("Welcome message sent successfully");  
		  #endif
                 
            //add new socket to array of sockets 

          for (i = 0; i < max_clients; i++)  
            	{  
                //if position is empty 
                 if( client_socket[i] == 0 )  
	                {  
	                 client_socket[i] = new_socket;
					 ClientTimeOut[i]=kTimeOut;
					 #ifdef DEBUG_SERVER_TCP
		               printf("New User %d\r\n" , i);  
					 #endif
	                 break;  
	                }  
	            }  
       	}  
             
        //else its some IO operation on some other socket

	for (i = 0; i < max_clients; i++)  
	    { 
	     sd = client_socket[i];  
	                 
	     if (FD_ISSET( sd , &readfds))  
	       	 {  
	          //Check if it was for closing , and also read the 
	          //incoming message 
	          memset (VarTCP[i].Buffer,0, sizeof(VarTCP[i].Buffer));
			  valread=read(sd, VarTCP[i].Buffer, sizeof(VarTCP[i].Buffer));
	          if (valread <= 0)
	               {  
	                //Somebody disconnected , get his details and print 
	                getpeername(sd , (struct sockaddr*)&address, (socklen_t*)&addrlen);
					#ifdef DEBUG_SERVER_TCP
		                printf("Host disconnected , ip %s , port %d \r\n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));
					#endif
	                  //Close the socket and mark as 0 in list for reuse 
	                close( sd );
	                client_socket[i] = 0;
	               }  	                     
		                //Echo back the message that came in 
		 	  else 
			       {  
					 if (valread>0) 
					 	{
				       	 ClientTimeOut[i]=kTimeOut;
//						 printf("Data Receive: %d \r\n", valread);
						#ifdef DEBUG_SERVER_TCP
							//unsigned char j;
							//printf("\r\n");
							//printf("\r\n");
						  	//printf("DataReceive %d bytes  -->", valread);
							//for (j=0; j<valread; j++) printf("%d, ", VarTCP[i].Buffer[j]);
							//printf("\r\n");
 					  	#endif
						n=ParseModbusServer(i);
						 if (n)
							{
							#ifdef DEBUG_SERVER_TCP
							 //unsigned char j;
							 //printf("DataSending %d bytes  -->", n);
							 //for (j=0; j<n; j++) printf("%d, ", VarTCP[i].Buffer[j]);
							 //printf("\r\n");
							#endif
							
							 TickTCP_++;
		 					 //status=write(sd, VarTCP[i].Buffer, );
							 status=write(sd, VarTCP[i].Buffer, n);
							 if (status<0) break;
							}
					 	}
			       }  
			 }  
		 else
			 {
			  if (client_socket[i])
			  	{
			   	 if (ClientTimeOut[i]) ClientTimeOut[i]--;
			   	 else
			   		{
			   	 	 printf("TimeOut Idx %d  Socket %d\r\n", i, sd);
					 close( sd );
		             client_socket[i] = 0; 
			   		}
			  	}
			 }
			
		}  
    }  
  return 0;
 }


void InitThreadModbusTCP(void)
	
{
 int ret;
   
    /*creating thread*/
 ret=pthread_create(&idModbusServerTCP,NULL,&ModbusServer,NULL);
 if(ret==0)
 	{
 	 printf("Modbus Server created successfully.\r\n");
 	}
 else
 	{
     printf("Thread not created.\r\n");
     return; /*return from main*/
    }
 
}


