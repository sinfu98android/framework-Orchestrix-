#ifndef MODBUSTCP_H
#define MODBUSTCP_H
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include "Modbus.h"
#include "Project.h"


#define DEBUG_SERVER_TCP


#define PORT_MODBUS   	 502
#define kTimeOut	100
#define	kMaxClient	128

union uLittleEndian{
	unsigned char	Byte[2];
	 uint16_t		Word;
};


struct stData{
	unsigned int	DeviceID;
	unsigned int 	ServerTick;
	unsigned int 	ClientTick;
};


struct stModbusTCPClient{							// Master
	unsigned char 	PollingCount;		// 0
	unsigned char 	PollingCount2;		// 1
	unsigned char 	Reserved1;			// 2
	unsigned char 	Reserved2;			// 3
	unsigned char 	Reserved3;			// 4
	unsigned char 	TotalDataProtocol;	// 5
	unsigned char 	SlaveAddress;		// 6
	unsigned char 	FunctionCode;		// 7
	unsigned char	OffsetAddrMSB;		// 8
	unsigned char	OffsetAddrLSB;		// 9	
	unsigned char	TotalDataMSB;		// 10
	unsigned char	TotalDataLSB;		// 11
//	unsigned char	TotalDataBytes;		// 12
};

struct stModbusTCPServer{				// Slave
	unsigned char	 	PollingCount;		// 0
	unsigned char	 	Reserved0;			// 1
	unsigned char	 	Reserved1;			// 2
	unsigned char	 	Reserved2;			// 3
	unsigned char	 	Reserved3;			// 4
	unsigned char	 	TotalDataProtocol;	// 5
	unsigned char	 	SlaveAddress;		// 6
	unsigned char	 	FunctionCode;		// 7
	unsigned char		TotalDataByte;		// 8		Function Code 0x03
	union uLittleEndian	Data[126];			// 9		MSB First only for Function Code 0x03
};

#if 0
struct stVarModbus{	
	unsigned int			Tick;
};
#endif

union uBuffer{
	unsigned char 			Buffer[1024];
	struct stData			DataTCP;
	struct stModbusTCPClient  TCPClient;
	struct stModbusTCPServer TCPServer;
};

union uModbusData{
	union uLittleEndian	DataModbus[2048];
	
};

extern unsigned char		TCPRun;
extern union uBuffer 		VarTCP[kMaxClient];
extern unsigned int			TickTCP, TickTCP_;

void *ModbusServer(void* args);
void InitThreadModbusTCP(void);

#endif
