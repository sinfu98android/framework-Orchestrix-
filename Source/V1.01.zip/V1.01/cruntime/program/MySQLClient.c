#include "MySQLClient.h"
//#include "ClientSocket.h"
//#include <my_global.h>
#include <mysql.h>
#include <stdio.h>
#include "System.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "MiscDataConv.h"
#include "AND.h"
#include "Project.h"

//#define MYSQL_DEBUG

const struct stMySQLCmd	tblMYSQLCmd[]=
	{
		{"", 													""		},			// kIdle_MySQLState
		{"select * from Callibration ORDER BY ID DESC LIMIT 1;",	""		},			// kReadCall
	 	{"INSERT INTO LoggingAnalog VALUES(0,", 				");"		},			// kPostingAnalog
		{"INSERT INTO LoggingCyc VALUES(0,", 					");"		},			// kPostingDigital
	};

enum eMySQLState MySQLState;
pthread_cond_t UpdateMySQL = PTHREAD_COND_INITIALIZER; 
pthread_mutex_t lockUpdateMySQL = PTHREAD_MUTEX_INITIALIZER; 



void InitMySQL(void)
{
 MySQLState=kReadCall;
}


void GetDateTimeStr(void)
{

}


void *MySQLTask(void* args)
{
 MYSQL *conn;
 MYSQL_RES *res;
 MYSQL_ROW row;
 unsigned char Stat;
// const char *kStrHeader="INSERT INTO LoggingAnalog VALUES(0,";
// const char *kStrSeparator=",";
 const char *kStrComa=",";
 const char *kStrMinus="-";
 const char *kStrSpace=" ";
 const char *kStrDoubleColon=":";
 const char *kStrQuote="'"; 
// const char *kStrEnd=");";
 /* Change me */
 char *server = "127.0.0.1";
 char *user = "remote";
 char *password = "remote";
 char *database = "IOT";
 char StrHead[1024];
 char sNumber[30];
 unsigned char n;
// int  Tick=0;


while(1)
	{
 	 pthread_cond_wait(&UpdateMySQL, &lockUpdateMySQL);
	 while(1)
	 	{
		 if ((MySQLState)&&(tm.tm_year))
		 	{
		 	 memset(&StrHead, 0, sizeof(StrHead));
			 conn = mysql_init(NULL);
			 if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
				{
				 fprintf(stderr, "%s\r\n", mysql_error(conn));
				 Stat=kFALSE;
				 //exit(1);
				}
			 else Stat=kTRUE;
			 if (Stat)
			 	{
			 	 if ((MySQLState==kPostingAnalog)||
				      (MySQLState==kPostingDigital))
			 	 	{
			 		 LoadString((char *)tblMYSQLCmd[MySQLState].StartCmd, &StrHead[0]); 
					 LoadString((char *)kStrQuote, &StrHead[strlen(StrHead)]); 		// '
					 sprintf(sNumber, "%d", tm.tm_year+1900);					// Year
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));
					 LoadString((char *)kStrMinus, &StrHead[strlen(StrHead)]);
					 sprintf(sNumber, "%02d", tm.tm_mon+1);						// Month
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));
					 LoadString((char *)kStrMinus, &StrHead[strlen(StrHead)]);
					 sprintf(sNumber, "%02d", tm.tm_mday);						// Date
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));	 
					 LoadString((char *)kStrSpace, &StrHead[strlen(StrHead)]);
					 sprintf(sNumber, "%02d", tm.tm_hour);						// Hour
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));
					 LoadString((char *)kStrDoubleColon, &StrHead[strlen(StrHead)]);
					 sprintf(sNumber, "%02d", tm.tm_min);						// Minute
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));
					 LoadString((char *)kStrDoubleColon, &StrHead[strlen(StrHead)]);
					 sprintf(sNumber, "%02d", tm.tm_sec);						// Second
					 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));
					 LoadString((char *)kStrQuote, &StrHead[strlen(StrHead)]); 		// '
					 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 if (MySQLState==kPostingAnalog)
					 	{
#if 0					 	
					 	 FloatToStr(AnalogLogging[0], (char*)&sNumber[0], 2);		// Var0
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLogging[1], (char*)&sNumber[0], 2);		// Var1
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLogging[2], (char*)&sNumber[0], 2);		// Var2
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLogging[3], (char*)&sNumber[0], 2);		// Var3
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
						 FloatToStr(AnalogLoggingMin[0], (char*)&sNumber[0], 2);		// Var0 Min
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMax[0], (char*)&sNumber[0], 2);	// Var0 Max
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMin[1], (char*)&sNumber[0], 2);		// Var1 Min
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMax[1], (char*)&sNumber[0], 2);	// Var1 Max
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
						 FloatToStr(AnalogLoggingMin[2], (char*)&sNumber[0], 2);		// Var2 Min
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMax[2], (char*)&sNumber[0], 2);	// Var2 Max
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMin[3], (char*)&sNumber[0], 2);		// Var3 Min
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 		// ,
					 	 FloatToStr(AnalogLoggingMax[3], (char*)&sNumber[0], 2);	// Var3 Max
#endif						 
						 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));			//
						 strncat(&StrHead[0],(char *)tblMYSQLCmd[MySQLState].EndCmd, strlen(tblMYSQLCmd[MySQLState].EndCmd));					 
					 	}
					 else if (MySQLState==kPostingDigital)
					 	{
					 	 for (n=0; n<kMaxCycDev; n++)
					 	 	{
#if 0					 	 	
							 my_itoa(CycLogging[n].FwdTime, sNumber);									//
							 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));							//
							 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]);						//
							 my_itoa(CycLogging[n].RevTime, sNumber);									//
							 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));							//
							 LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]);						//
							 my_itoa(CycLogging[n].Cycle, sNumber);									//
							 strncat(&StrHead[0], &sNumber[0], strlen(sNumber));							//												 
							 if (n<(kMaxCycDev-1)) LoadString((char *)kStrComa, &StrHead[strlen(StrHead)]); 	//						 
#endif							 
					 	 	}
						 strncat(&StrHead[0],(char *)tblMYSQLCmd[MySQLState].EndCmd, strlen(tblMYSQLCmd[MySQLState].EndCmd));					 
					 	}
			 	 	}
				 else if (MySQLState==kReadCall)
				 	{
				 	 LoadString((char *)tblMYSQLCmd[MySQLState].StartCmd, &StrHead[0]);
				 	}
				 #ifdef MYSQL_DEBUG
					 printf("Query:  %s  %d\r\n", &StrHead[0], MySQLState);
				 #endif
				 if (mysql_query(conn, &StrHead[0])) 
					{
					 fprintf(stderr, "%s\r\n", mysql_error(conn));
					 Stat=kFALSE;
					}
				 else
				 	{
				 	 if (MySQLState==kReadCall)
				 	 	{
						 res = mysql_use_result(conn);
						 while ((row = mysql_fetch_row(res)) != NULL)
							{
							 if (MySQLState==kReadCall)
							 	{
								 #ifdef MYSQL_DEBUG
									printf("%10s  %10s  %10s  %10s  %10s\r\n", row[0], row[1], row[2], row[3], row[4]);
								 #endif
#if 0								 
								 AnalogCallibration[0]= atof(row[1]);
								 AnalogCallibration[1]= atof(row[2]);
								 AnalogCallibration[2]= atof(row[3]);
								 AnalogCallibration[3]= atof(row[4]);
//								 printf("%.2f  %.2f  %.2f  %.2f  \r\n", AnalogCallibration[0], AnalogCallibration[1], AnalogCallibration[2], AnalogCallibration[3]);
#endif
							 	}
							}
						 mysql_free_result(res);
				 	 	}			 	
				 	}
			 	}
			 mysql_close(conn);
			 if (Stat)
			 	{
				 MySQLState++;
				 if (MySQLState>=kEndMySQLState) 
				 	{
				 	 MySQLState=kIdle_MySQLState;
					 break;
				 	}			 	
			 	}
		 	}
		}
	}
}



