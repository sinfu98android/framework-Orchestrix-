#ifndef MYSQL_H
#define MYSQL_H
#include <pthread.h> 

enum eMySQLState{
	kIdle_MySQLState,
	kReadCall,		
	kPostingAnalog,
	kPostingDigital,
	kEndMySQLState,
};


struct stMySQLCmd{
	const char			*StartCmd;
	const char			*EndCmd;
};

extern enum eMySQLState MySQLState;
extern pthread_cond_t UpdateMySQL;
extern pthread_mutex_t lockUpdateMySQL;


void InitMySQL(void);
void *MySQLTask(void* args);

#endif
