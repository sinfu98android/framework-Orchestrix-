#include "OmronProtocol.h"
#include "UART.h"
#include "System.h"
#include "PLCProtocol.h"

#define 	kEvenParity		0
#define 	kOddParity		1


unsigned char 	FCS;
unsigned short	DataSize;



unsigned char AddParity7Bit(unsigned char dat, unsigned char Parity)
{
 unsigned char i;
 unsigned char temp, temp1;

 temp=dat;
 temp1=0;
 for (i=0; i<7; i++)
 	 {
	  temp1+=temp & 0x01;
	  temp=temp>>1;
 	 }
 temp1&=0x01;
 if (Parity==kEvenParity)
 	 {
	  if (temp1) temp=dat|0x80;
	  else temp=dat&0x7F;
 	 }
 else
 	 {
	  if (temp1) temp=dat&0x7F;
	  else temp=dat|0x80;
 	 }
 return(temp);
}


void InitOmronProtocol(unsigned char idx)
{
 DevNum[idx]=0;
}


void AddParity(unsigned char idx, unsigned char size, unsigned char Parity)
{
 unsigned char i;

 for (i=0; i<size; i++)
 	 {
	  BuffRX[idx][i]=AddParity7Bit(BuffRX[idx][i], kEvenParity);
 	 }
}


void Read_DevD_Omron(unsigned char idx, unsigned char Devnum, unsigned short Addr, unsigned short Total)
{
 BuffRX[idx][0]='@';
 BuffRX[idx][1]=NibleHexToASCII((Devnum>>4)& 0x0F);
 BuffRX[idx][2]=NibleHexToASCII(Devnum & 0x0F);
 BuffRX[idx][3]='F';
 BuffRX[idx][4]='A';
 BuffRX[idx][5]='0';
 BuffRX[idx][6]='8';
 BuffRX[idx][7]='0';
 BuffRX[idx][8]='0';
 BuffRX[idx][9]='0';
 BuffRX[idx][10]='0';
 BuffRX[idx][11]='2';
 BuffRX[idx][12]='0';
 BuffRX[idx][13]='0';
 BuffRX[idx][14]='0';
 BuffRX[idx][15]='0';
 BuffRX[idx][16]='0';
 BuffRX[idx][17]='0';
 BuffRX[idx][18]='0';
 BuffRX[idx][19]='0';
 BuffRX[idx][20]='0';
 BuffRX[idx][21]='0';
 BuffRX[idx][22]='F';
 BuffRX[idx][23]='C';
 BuffRX[idx][24]='0';
 BuffRX[idx][25]='0';
 BuffRX[idx][26]='0';
 BuffRX[idx][27]='1';
 BuffRX[idx][28]=NibleHexToASCII((kReadOmronCOM>>4)& 0x0F);	// Read Command MSB
 BuffRX[idx][29]=NibleHexToASCII(kReadOmronCOM & 0x0F);		// Read Command LSB
 BuffRX[idx][30]=NibleHexToASCII((kDevRegD>>4)& 0x0F);		// Device D MSB
 BuffRX[idx][31]=NibleHexToASCII(kDevRegD & 0x0F);			// Device D LSB
 BuffRX[idx][32]=NibleHexToASCII((Addr>>12)& 0x0F);			// Addr MSB
 BuffRX[idx][33]=NibleHexToASCII((Addr>>8)& 0x0F);			//
 BuffRX[idx][34]=NibleHexToASCII((Addr>>4)& 0x0F);			//
 BuffRX[idx][35]=NibleHexToASCII((Addr)& 0x0F);				// Addr LSB
 BuffRX[idx][36]='0';
 BuffRX[idx][37]='0';
 BuffRX[idx][38]=NibleHexToASCII((Total>>12)& 0x0F);			// Data Size MSB
 BuffRX[idx][39]=NibleHexToASCII((Total>>8)& 0x0F);			//
 BuffRX[idx][40]=NibleHexToASCII((Total>>4)& 0x0F);			//
 BuffRX[idx][41]=NibleHexToASCII((Total)& 0x0F);				// Data Size LSB
 FCS=CalculateFCS(&BuffRX[idx][0],42);
 BuffRX[idx][42]=NibleHexToASCII((FCS>>4)& 0x0F);		//'0';	// FCS MSB
 BuffRX[idx][43]=NibleHexToASCII(FCS & 0x0F);		//'2';	// FCS LSB
 BuffRX[idx][44]='*';
 BuffRX[idx][45]=0x0D;
 DataSize=46;
 AddParity(idx, DataSize, kEvenParity);
 SendUART(idx, DataSize);
 StartReceiveUART(idx);
}


void Write_DevD_Omron(unsigned char idx, unsigned char Devnum, unsigned short Addr, unsigned short Total)
{
 short i, temp;

 BuffRX[idx][0]='@';
 BuffRX[idx][1]=NibleHexToASCII((Devnum>>4)& 0x0F);
 BuffRX[idx][2]=NibleHexToASCII(Devnum & 0x0F);
 BuffRX[idx][3]='F';
 BuffRX[idx][4]='A';
 BuffRX[idx][5]='0';
 BuffRX[idx][6]='8';
 BuffRX[idx][7]='0';
 BuffRX[idx][8]='0';
 BuffRX[idx][9]='0';
 BuffRX[idx][10]='0';
 BuffRX[idx][11]='2';
 BuffRX[idx][12]='0';
 BuffRX[idx][13]='0';
 BuffRX[idx][14]='0';
 BuffRX[idx][15]='0';
 BuffRX[idx][16]='0';
 BuffRX[idx][17]='0';
 BuffRX[idx][18]='0';
 BuffRX[idx][19]='0';
 BuffRX[idx][20]='0';
 BuffRX[idx][21]='0';
 BuffRX[idx][22]='F';
 BuffRX[idx][23]='C';
 BuffRX[idx][24]='0';
 BuffRX[idx][25]='0';
 BuffRX[idx][26]='0';
 BuffRX[idx][27]='1';
 BuffRX[idx][28]=NibleHexToASCII((kWriteOmronCOM>>4)& 0x0F);	// Read Command MSB
 BuffRX[idx][29]=NibleHexToASCII(kWriteOmronCOM & 0x0F);		// Read Command LSB
 BuffRX[idx][30]=NibleHexToASCII((kDevRegD>>4)& 0x0F);		// Device D MSB
 BuffRX[idx][31]=NibleHexToASCII(kDevRegD & 0x0F);			// Device D LSB
 BuffRX[idx][32]=NibleHexToASCII((Addr>>12)& 0x0F);			// Addr MSB
 BuffRX[idx][33]=NibleHexToASCII((Addr>>8)& 0x0F);			//
 BuffRX[idx][34]=NibleHexToASCII((Addr>>4)& 0x0F);			//
 BuffRX[idx][35]=NibleHexToASCII((Addr)& 0x0F);				// Addr LSB
 BuffRX[idx][36]='0';
 BuffRX[idx][37]='0';
 BuffRX[idx][38]=NibleHexToASCII((Total>>12)& 0x0F);			// Data Size MSB
 BuffRX[idx][39]=NibleHexToASCII((Total>>8)& 0x0F);			//
 BuffRX[idx][40]=NibleHexToASCII((Total>>4)& 0x0F);			//
 BuffRX[idx][41]=NibleHexToASCII((Total)& 0x0F);				// Data Size LSB
 for (i=0; i<Total; i++)
 	 {
	  temp=DataPLC_TX[idx].DataWord[i];
	  BuffRX[idx][42+(i<<2)]=NibleHexToASCII((temp>>12)&0x0F);
	  BuffRX[idx][43+(i<<2)]=NibleHexToASCII((temp>>8)&0x0F);
	  BuffRX[idx][44+(i<<2)]=NibleHexToASCII((temp>>4)&0x0F);
	  BuffRX[idx][45+(i<<2)]=NibleHexToASCII(temp & 0x0F);
 	 }
 FCS=CalculateFCS(&BuffRX[idx][0],42+(Total<<2));
 BuffRX[idx][42+(Total<<2)]=NibleHexToASCII((FCS>>4)& 0x0F);		//'0';	// FCS MSB
 BuffRX[idx][43+(Total<<2)]=NibleHexToASCII(FCS & 0x0F);		//'2';	// FCS LSB
 BuffRX[idx][44+(Total<<2)]='*';
 BuffRX[idx][45+(Total<<2)]=0x0D;
 DataSize=46+(Total<<2);
 AddParity(idx, DataSize, kEvenParity);
 SendUART(idx, DataSize);
 StartReceiveUART(idx);
}


void Write_DevCIO_Omron(unsigned char idx, unsigned char Devnum, unsigned short Addr, unsigned short Total)
{
 short i, temp;

 BuffRX[idx][0]='@';
 BuffRX[idx][1]=NibleHexToASCII((Devnum>>4)& 0x0F);
 BuffRX[idx][2]=NibleHexToASCII(Devnum & 0x0F);
 BuffRX[idx][3]='F';
 BuffRX[idx][4]='A';
 BuffRX[idx][5]='0';
 BuffRX[idx][6]='8';
 BuffRX[idx][7]='0';
 BuffRX[idx][8]='0';
 BuffRX[idx][9]='0';
 BuffRX[idx][10]='0';
 BuffRX[idx][11]='2';
 BuffRX[idx][12]='0';
 BuffRX[idx][13]='0';
 BuffRX[idx][14]='0';
 BuffRX[idx][15]='0';
 BuffRX[idx][16]='0';
 BuffRX[idx][17]='0';
 BuffRX[idx][18]='0';
 BuffRX[idx][19]='0';
 BuffRX[idx][20]='0';
 BuffRX[idx][21]='0';
 BuffRX[idx][22]='F';
 BuffRX[idx][23]='C';
 BuffRX[idx][24]='0';
 BuffRX[idx][25]='0';
 BuffRX[idx][26]='0';
 BuffRX[idx][27]='1';
 BuffRX[idx][28]=NibleHexToASCII((kWriteOmronCOM>>4)& 0x0F);	// Read Command MSB
 BuffRX[idx][29]=NibleHexToASCII(kWriteOmronCOM & 0x0F);		// Read Command LSB
 BuffRX[idx][30]=NibleHexToASCII((kDevRegCIO>>4)& 0x0F);		// Device D MSB
 BuffRX[idx][31]=NibleHexToASCII(kDevRegCIO & 0x0F);			// Device D LSB
 BuffRX[idx][32]=NibleHexToASCII((Addr>>12)& 0x0F);			// Addr MSB
 BuffRX[idx][33]=NibleHexToASCII((Addr>>8)& 0x0F);			//
 BuffRX[idx][34]=NibleHexToASCII((Addr>>4)& 0x0F);			//
 BuffRX[idx][35]=NibleHexToASCII((Addr)& 0x0F);				// Addr LSB
 BuffRX[idx][36]='0';
 BuffRX[idx][37]='0';
 BuffRX[idx][38]=NibleHexToASCII((Total>>12)& 0x0F);			// Data Size MSB
 BuffRX[idx][39]=NibleHexToASCII((Total>>8)& 0x0F);			//
 BuffRX[idx][40]=NibleHexToASCII((Total>>4)& 0x0F);			//
 BuffRX[idx][41]=NibleHexToASCII((Total)& 0x0F);				// Data Size LSB
 for (i=0; i<Total; i++)
 	 {
	  temp=DataPLC_TX[0].DataWord[i];
	  BuffRX[idx][42+(i<<2)]=NibleHexToASCII((temp>>12)&0x0F);
	  BuffRX[idx][43+(i<<2)]=NibleHexToASCII((temp>>8)&0x0F);
	  BuffRX[idx][44+(i<<2)]=NibleHexToASCII((temp>>4)&0x0F);
	  BuffRX[idx][45+(i<<2)]=NibleHexToASCII(temp & 0x0F);
 	 }
 FCS=CalculateFCS(&BuffRX[idx][0],42+(Total<<2));
 BuffRX[idx][42+(Total<<2)]=NibleHexToASCII((FCS>>4)& 0x0F);		//'0';	// FCS MSB
 BuffRX[idx][43+(Total<<2)]=NibleHexToASCII(FCS & 0x0F);		//'2';	// FCS LSB
 BuffRX[idx][44+(Total<<2)]='*';
 BuffRX[idx][45+(Total<<2)]=0x0D;
 DataSize=46+(Total<<2);
 AddParity(idx, DataSize, kEvenParity);
 SendUART(idx, DataSize);
 StartReceiveUART(idx);
}


void Read_DevCIO_Omron(unsigned char idx, unsigned char Devnum, unsigned short Addr, unsigned short Total)
{
 BuffRX[idx][0]='@';
 BuffRX[idx][1]=NibleHexToASCII((Devnum>>4)& 0x0F);
 BuffRX[idx][2]=NibleHexToASCII(Devnum & 0x0F);
 BuffRX[idx][3]='F';
 BuffRX[idx][4]='A';
 BuffRX[idx][5]='0';
 BuffRX[idx][6]='8';
 BuffRX[idx][7]='0';
 BuffRX[idx][8]='0';
 BuffRX[idx][9]='0';
 BuffRX[idx][10]='0';
 BuffRX[idx][11]='2';
 BuffRX[idx][12]='0';
 BuffRX[idx][13]='0';
 BuffRX[idx][14]='0';
 BuffRX[idx][15]='0';
 BuffRX[idx][16]='0';
 BuffRX[idx][17]='0';
 BuffRX[idx][18]='0';
 BuffRX[idx][19]='0';
 BuffRX[idx][20]='0';
 BuffRX[idx][21]='0';
 BuffRX[idx][22]='F';
 BuffRX[idx][23]='C';
 BuffRX[idx][24]='0';
 BuffRX[idx][25]='0';
 BuffRX[idx][26]='0';
 BuffRX[idx][27]='1';
 BuffRX[idx][28]=NibleHexToASCII((kReadOmronCOM>>4)& 0x0F);	// Read Command MSB
 BuffRX[idx][29]=NibleHexToASCII(kReadOmronCOM & 0x0F);		// Read Command LSB
 BuffRX[idx][30]=NibleHexToASCII((kDevRegCIO>>4)& 0x0F);		// Device D MSB
 BuffRX[idx][31]=NibleHexToASCII(kDevRegCIO & 0x0F);			// Device D LSB
 BuffRX[idx][32]=NibleHexToASCII((Addr>>12)& 0x0F);			// Addr MSB
 BuffRX[idx][33]=NibleHexToASCII((Addr>>8)& 0x0F);			//
 BuffRX[idx][34]=NibleHexToASCII((Addr>>4)& 0x0F);			//
 BuffRX[idx][35]=NibleHexToASCII((Addr)& 0x0F);				// Addr LSB
 BuffRX[idx][36]='0';
 BuffRX[idx][37]='0';
 BuffRX[idx][38]=NibleHexToASCII((Total>>12)& 0x0F);			// Data Size MSB
 BuffRX[idx][39]=NibleHexToASCII((Total>>8)& 0x0F);			//
 BuffRX[idx][40]=NibleHexToASCII((Total>>4)& 0x0F);			//
 BuffRX[idx][41]=NibleHexToASCII((Total)& 0x0F);				// Data Size LSB
 FCS=CalculateFCS(&BuffRX[idx][0],42);
 BuffRX[idx][42]=NibleHexToASCII((FCS>>4)& 0x0F);		//'0';	// FCS MSB
 BuffRX[idx][43]=NibleHexToASCII(FCS & 0x0F);		//'2';	// FCS LSB
 BuffRX[idx][44]='*';
 BuffRX[idx][45]=0x0D;
 DataSize=46;
 AddParity(idx, DataSize, kEvenParity);
 SendUART(idx, DataSize);
 StartReceiveUART(idx);
}


unsigned char CheckParityUART_7Bit(unsigned char idx)
{
 unsigned char i;
 unsigned char temp, temp1;

 temp=kTRUE;
 for (i=0; i<ptrRX[idx]; i++)
		 {
		  temp1=AddParity7Bit((BuffRX[idx][i] & 0x7F), kEvenParity);
		  if (BuffRX[idx][i]==temp1)
				  {
				   BuffRX[idx][i]&=0x7F;
				  }
		  else temp=kFALSE;
		 }
 return(temp);
}

void ParseOmronProtocol(unsigned char idx)
{
 short i, temp;

//if (PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat) PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat=kFALSE;
if (WriteStat[idx])
	{
	 WRStatusCOM[idx][AddrCOM[idx]]=kFALSE;
 	 WriteStat[idx]=kFALSE;
	}
else
	 {
	  if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_Data)
	  	{
		  temp=ptrRX[idx]-4;
		  temp=temp-35;
		  temp=temp >> 2;
		  for (i=0; i<temp; i++)
			 {
			  DataPLC_RX[idx].DataWord[ComAddr[idx]+i]=ASCIIHexToBin_16Bit_2nd_Mode(&BuffRX[idx][35+(i<<2)], k16Bit);
			 }
	  	}
	 }
}


void OmronProtocolProcess(unsigned char idx)
{
 unsigned char temp;
 int n;
 
 for (n=0; n<kMaxBuffDEV; n++)
	{
	 if (WRStatusCOM[idx][n])
		{
		 AddrCOM[idx]=n;
		 WriteStat[idx]=kTRUE;
		 break;
		}
	}

 if (ReceiveComplete[idx])
	{
//	 if (CheckParityUART_7Bit(idx))
		  {
		   temp=(unsigned char)ASCIIHexToBin_16Bit_2nd_Mode(&BuffRX[idx][1], k8Bit);
		   if ((temp==DevNum[idx])&&(BuffRX[idx][0]=='@')&&(BuffRX[idx][ptrRX[idx]-1]==0x0D)&&(BuffRX[idx][ptrRX[idx]-2]=='*'))
			   {
				temp=ASCIIHexToBin_16Bit_2nd_Mode(&BuffRX[idx][ptrRX[idx]-4], k8Bit);
				FCS=CalculateFCS(&BuffRX[idx][0],ptrRX[idx]-4);
				if (FCS==temp)
					{
					 ParseOmronProtocol(idx);
					 ReceiveComplete[idx]=kFALSE;
				   	 Respond[idx]=kTRUE;
					 TrialRespone[idx]=0;
					 UART_RESPONE[idx]=kTRUE;
					 DetectModem=IdxModem;	
					 TickCOM_[idx]++;
					 PLCParam[idx].Queue++;
					 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kNULL_DataType) PLCParam[idx].Queue=0;
					}
			   }
	  	}
	  StartReceiveUART(idx);
 	}


 //if (FlagSystem.Tick1S) DataPLC_TX.DataWord[0]++;

 if ((FlagsSystem.Tick1mS)||(Respond[idx]))
		 {
		  if (TimeOutResp[idx]) TimeOutResp[idx]--;
		  if ((TimeOutResp[idx]==0)||(Respond[idx]))
			  {
			    if (TimeOutResp[idx]==0)
				{
				 TrialRespone[idx]++;
				 if (TrialRespone[idx]>=3)
				 	{
				 	  if (UART_RESPONE[idx]==kFALSE)
					 	{
					 	 UARTRdy[idx]=kFALSE;
						 CloseUART(idx);
					 	}
					}
				}			   
			    if ((Respond[idx])&&(DlyCOM[idx]<1))
				{
				 DlyCOM[idx]++;
				}
			    else
				 {
				   //if (PLCParam[idx].DataParam[PLCParam[idx].Queue].WriteStat)
				   if (WriteStat[idx])
					{
					 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_Data)
					 	{
						 ComAddr[idx]=AddrCOM[idx];		//PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;		// 100;
						 ComTot[idx]=1;						//PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;		// 4;
						 DevNum[idx]=PLCParam[idx].DevNum;
						 Write_DevD_Omron(idx, DevNum[idx], ComAddr[idx], ComTot[idx]);
						 DlyCOM[idx]=0;
						 TimeOutResp[idx]=kTimeOutResp;	//8;
						 Respond[idx]=kFALSE;
					 	}
					}
				   else
					{
					 if (PLCParam[idx].DataParam[PLCParam[idx].Queue].DataType==kReg_Data)
					 	{
						 ComAddr[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Addr;		// //ComAddr[idx]=0;
						 ComTot[idx]=PLCParam[idx].DataParam[PLCParam[idx].Queue].Size;	  //ComTot[idx]=4;
						 DevNum[idx]=PLCParam[idx].DevNum;			 
						 Read_DevD_Omron(idx, DevNum[idx],ComAddr[idx],ComTot[idx]);
						 DlyCOM[idx]=0;
						 TimeOutResp[idx]=kTimeOutResp;  //8;
						 Respond[idx]=kFALSE;
					 	}
					}
				  }
			  	}
		 }
}
