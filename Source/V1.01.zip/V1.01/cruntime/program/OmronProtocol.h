#ifndef OMRONPROTOCOL_H
#define OMRONPROTOCOL_H
#include "MiscDataConv.h"

#define 	kReadOmronCOM		1
#define 	kWriteOmronCOM		2


#define		kDevRegCIO			0x80
#define		kDevRegD			0x82


struct stOmronFormat{
	unsigned char	Header;			// 0	'@'
	unsigned char	AddrMSB;		// 1	'Addr MSB'
	unsigned char	AddrLSB;		// 2	'Addr LSB'
	unsigned char	CharF;			// 3	'F'
	unsigned char	CharA;			// 4	'A'
	unsigned char	ResponeTime;	// 5	Respone Time
	unsigned char	ICF_8;			// 6	'8'
	unsigned char	ICF_0;			// 7	'0'
	unsigned char	RSV_L;			// 8	'0'
	unsigned char	RSV_M;			// 9	'0'
	unsigned char	GCT_L;			// 10	'0'
	unsigned char	GCT_M;			// 11	'2'
	unsigned char	DNA_L;			// 12	'0'
	unsigned char	DNA_M;			// 13	'0'
	unsigned char	DA1_L;			// 14	'0'
	unsigned char	DA1_M;			// 15	'0'
	unsigned char	DA2_L;			// 16	'0'
	unsigned char	DA2_M;			// 17	'0'
	unsigned char	SNA_L;			// 18	'0'
	unsigned char	SNA_M;			// 19	'0'
	unsigned char	SA1_L;			// 20	'0'
	unsigned char	SA1_M;			// 21	'0'
	unsigned char	SA2_L;			// 22	'F'
	unsigned char	SA2_M;			// 23	'C'
	unsigned char	SID_L;			// 24	'0'
	unsigned char	SID_M;			// 25	'0'
	unsigned char	CMD0;			// 26	'0'
	unsigned char	CMD1;			// 27	'1'
	unsigned char	CODE0;			// 28	'0'
	unsigned char	CODE1;			// 29	'1'			Code COM 	1=Read 		2=Write
	unsigned char	DEVTYPE0;		// 30	'8'			0x82=Device D
	unsigned char	DEVTYPE1;		// 31	'2'
	unsigned char	ADR3;			// 32	'0'			Addr MSB
	unsigned char	ADR2;			// 33	'0'
	unsigned char	ADR1;			// 34	'0'
	unsigned char	ADR0;			// 35	'0'			Addr LSB
	unsigned char	CMD6;			// 36	'0'
	unsigned char	CMD7;			// 37	'0'
	unsigned char	SIZE3;			// 38	'0'			Datasize
	unsigned char	SIZE2;			// 39	'0'
	unsigned char	SIZE1;			// 40	'0'
	unsigned char	SIZE0;			// 41	'1'
	unsigned char	FCSH;			// 42	'7'			Checksum XOR
	unsigned char	FCSL;			// 43	'6'
	unsigned char	ENDC;			// 44	'0x2A' // *
	unsigned char	CR_ENTER;		// 45	'0x0D'





};

//extern short	TimeOutResp;

void InitOmronProtocol(unsigned char idx);
void OmronProtocolProcess(unsigned char idx);
#endif
