#include "PLC.h"#include "Flash.h"#include "IOProcess.h"#include "System.h"#include <stdint.h>#include <string.h>#include <stdio.h>#include "MiscDataConv.h"#include <ctype.h>short 				RegD[kMaxRegD];short 				RegZ[kMaxRegZ];				// For Indirectunion uBitReg 		RegM[kMaxRegM];union uBitReg 		RegM_[kMaxRegM];union uBitReg 		RegMEdgeP[kMaxRegM];union uBitReg 		RegMEdgeN[kMaxRegM];union uBitReg 		RegX[kMaxInput];union uBitReg 		RegX_[kMaxInput];union uBitReg 		RegXEdgeP[kMaxInput];union uBitReg 		RegXEdgeN[kMaxInput];union uBitReg 		RegY[kMaxInput];union uBitReg 		RegY_[kMaxInput];union uBitReg 		RegYEdgeP[kMaxInput];union uBitReg 		RegYEdgeN[kMaxInput];struct stTimer		Timer[512];struct stPLCCode	PLCCode[32767];unsigned int		PLCRUN, PLCERR, PLCRUN_, PLCSTOP_, PLCRUN_LAST;char 				BuffCode[kMaxSizeCode];struct stCodeParse	BuffParse[8192];int					CodeLine, LineParse;int					PLCCycle, PLCCycle_;unsigned char		PLC1stRUN;const char *kFileName="/var/www/html/program/code.txt";
const short kTblMasking[]={ 0x0001, 0x0002, 0x0004, 0x0008, 0x0010, 0x0020, 0x0040, 0x0080,
					 		0x0100, 0x0200, 0x0400, 0x0800, 0x1000, 0x2000, 0x4000, 0x8000};

const struct stTblCmd	kTblCmd[]={		
	{kEND,				(char*)"END",			0},		// 0 END	
	{kLD,				(char*)"LD",			1}, 	// 1 LD		M0	
	{kLDI,				(char*)"LDI",			1}, 	// 2 LDI		M0	
	{kLDP,				(char*)"LDP",			1}, 	// 3 LDP		M0	
	{kLDN,				(char*)"LDN",			1}, 	// 4 LDN		M0	
	{kGREATER,			(char*)"GRT", 			2}, 	// 5 >			D0,K1	
	{kGREATEQUAL,		(char*)"GRTEQ",			2}, 	// 6 >=		D0,K1	
	{kLOWER,			(char*)"LOW", 			2}, 	// 7 <			D0,K1	
	{kLOWEQUAL, 		(char*)"LOWEQ",			2}, 	// 8 <=		D0,K1	
	{kEQUAL,			(char*)"EQ",			2}, 	// 9 ==		D0,K1			
	{kANL,				(char*)"ANL",			1}, 	// 10 ANL		M0				
	{kANLI, 			(char*)"ANLI",			1}, 	// 11 ANLI 	M0	
	{kORL,				(char*)"ORL",			1}, 	// 12 ORL		M0	
	{kORLI, 			(char*)"ORLI",			1}, 	// 13 ORLI 	M0	
	{kANP,				(char*)"ANP",			1}, 	// 14 ANP		M0	
	{kANN,				(char*)"ANN",			1}, 	// 15 ANN		M0	
	{kORP,				(char*)"ORP",			1}, 	// 16 ORP		M0	
	{kORN,				(char*)"ORN",			1}, 	// 17 ORN		M0	
	{kANL_GREATER,		(char*)"ANGRT",			2}, 	// 18		D0,K1	
	{kANL_GREATER32,	(char*)"DANGRT", 		2}, 	// 19		D0,K1	
	{kORL_GREATER,		(char*)"ORGRT",			2}, 	// 20	D0,K1	
	{kORL_GREATER32,	(char*)"DORGRT", 		2}, 	// 21 	D0,K1	
	{kANL_GREATEQUAL,	(char*)"ANGRTEQ",		2}, 	// 22	D0,K1	
	{kANL_GREATEQUAL32, (char*)"DANGRTEQ",		2}, 	// 23 	D0,K1	
	{kORL_GREATEQUAL,	(char*)"ORGRTEQ",		2}, 	// 24	D0,K1	
	{kORL_GREATEQUAL32, (char*)"DORGRTEQ",		2}, 	// 25 	D0,K1	
	{kANL_LOWER,		(char*)"ANLOW",			2}, 	// 26	D0,K1	
	{kANL_LOWER32,		(char*)"DANLOW", 		2},		// 27		{kORL_LOWER,		(char*)"ORLOW",	 		2},		// 28 	ORLO  ?????		{kORL_LOWER32,		(char*)"DORLOW", 		2},		// 29	
	{kANL_LOWEQUAL, 	(char*)"ANLOWEQ",		2},		// 30	
	{kANL_LOWEQUAL32,	(char*)"DANLOWEQ",		2}, 	// 31	
	{kORL_LOWEQUAL, 	(char*)"ORLOWEQ",		2}, 	// 32	
	{kORL_LOWEQUAL32,	(char*)"DORLOWEQ",		2}, 	// 33	
	{kANL_EQUAL,		(char*)"ANEQ",			2}, 	// 34	
	{kANL_EQUAL32,		(char*)"DANEQ", 		2}, 	// 35	
	{kORL_EQUAL,		(char*)"OREQ",			2}, 	// 36	
	{kORL_EQUAL32,		(char*)"DOREQ", 		2}, 	// 37	
	{kSET,				(char*)"SET",			1}, 	// 38 SET		M0	
	{kRST,				(char*)"RST",			1}, 	// 39 RST		M0	
	{kALT,				(char*)"ALT",			1}, 	// 40 ALT		M0	
	{kOUT,				(char*)"OUT",			1}, 	// 41 OUT		M0	
	{kBRA,				(char*)"BRA",			0}, 	// 42 BRA	
	{kBRE,				(char*)"BRE",			0}, 	// 43 BRE	
	{kMOV,				(char*)"MOV",			2}, 	// 44 MOV		K1,D0		{kMOV32,			(char*)"DMOV",			2}, 	// 45 DMOV 	K1,D0		
	{kADD,				(char*)"ADD",			3}, 	// 46 ADD		D0,K1,D2	
	{kADD32,			(char*)"DADD",			3}, 	// 47 DADD 	D0,K1,D2	
	{kSUB,				(char*)"SUB",			3}, 	// 48 SUB		D0,K1,D2	
	{kSUB32,			(char*)"DSUB",			3}, 	// 49 DSUB 	D0,K1,D2	
	{kMUL,				(char*)"MUL",			3}, 	// 50 MUL		D0,K1,D2	
	{kMUL32,			(char*)"DMUL",			3}, 	// 51 DMUL 	D0,K1,D2	
	{kDIV,				(char*)"DIV",			3}, 	// 52 DIV		D0,K1,D2	
	{kDIV32,			(char*)"DDIV",			3}, 	// 53 DDIV 	D0,K1,D2	
	{kAND,				(char*)"AND",			3}, 	// 54 AND		D0,K1,D2	
	{kAND32,			(char*)"DAND",			3}, 	// 55 DAND 	D0,K1,D2	
	{kOR,				(char*)"OR",			3}, 	// 56 OR		D0,K1,D2		{kOR32, 			(char*)"DOR",			3}, 	// 57 DOR		D0,K1,D2		{kXOR,				(char*)"XOR",			3}, 	// 58 XOR		D0,K1,D2		{kXOR32,			(char*)"DXOR",			3}, 	// 59 DXOR 	D0,K1,D2		{kNOT,				(char*)"NOT",			3}, 	// 60 NOT		D0,K1,D2		{kNOT32,			(char*)"DNOT",			3}, 	// 61 DNOT 	D0,K1,D2		{kINC,				(char*)"INC",			1}, 	// 62 NOT		D0,K1,D2		{kINC32,			(char*)"DINC",			1}, 	// 63 DNOT 	D0,K1,D2};#define kMaxCmdPLC	sizeof(kTblCmd)/(sizeof(struct stTblCmd))
const struct stTblVAR	kTblVar[]= 	{
	{kRegM,			'M'},
	{kRegX,			'X'},
	{kRegY,			'Y'},	{kRegT,			'T'},	{kRegD,			'D'},
	{kRegZ,			'Z'},
	{kConst,		'K'},
	};#define kMaxkTblVar	sizeof(kTblVar)/sizeof(struct stTblVAR)void InitPLC(void){ PLCRUN_LAST=kFALSE; ResetPLC(); OPEN_CODE();  if (ParseCode()==kNoError) 	{ 	 printf("RUN OK ....\r\n");	 PLCRUN=kTRUE;	 PLCERR=kFALSE; 	} else 	{ 	 printf("ERROR CODE  %d!!!\r\n", LineParse); 	 PLCERR=kTRUE;	 PLCRUN=kFALSE; 	}}
long get_file_size(char *filename){    FILE *fp = fopen(filename, "r");    if (fp==NULL)        return -1;    if (fseek(fp, 0, SEEK_END) < 0) {        fclose(fp);        return -1;    }    long size = ftell(fp);    // release the resources when not required    fclose(fp);    return size;}int FindCmd(char *Cmd){ short n;  for (n=0; n<kMaxCmdPLC; n++) 	{// 	 printf("%s %s\r\n", (char*)Cmd, (char*)kTblCmd[n].strCmd); 	 if (CmpStr((char*)Cmd, (char*)kTblCmd[n].strCmd)) 	 	{// 	 	 printf("found it  idx %d\r\n", n); 	 	 return(n); 	 	} 	} return(-1);}void OPEN_CODE(void){ FILE	*fp;  //unsigned char	*pDat;  int size,n,i,j,k;  unsigned char	Comment=kFALSE, Code=kFALSE, Space=kFALSE; size=get_file_size((char*)kFileName); memset(BuffParse,0,sizeof(BuffParse));  printf("filesize: %d\r\n", size);  if ((fp = fopen((char*)kFileName, "r")) == NULL)		{		  printf("File parameter Fail !!!! ");		 return;		} else		{		 fread(BuffCode, size, 1, fp);		 fclose(fp);		 for (n=0; n<size; n++) BuffCode[n]=toupper(BuffCode[n]);		// Upper case		 printf("\r\n");		 printf("Here Code:\r\n");		 i=0;		 j=0;		 k=0;		 Comment=kFALSE;		 Code=kFALSE;		 CodeLine=0;		 for (n=0; n<size; n++)		 	{//		 	 printf("%02x,", BuffCode[n]);			 if ((BuffCode[n]==0x0D)||(BuffCode[n]==0x0A))			 	{		 	 	 if (Code) CodeLine++;				 BuffParse[CodeLine].size=0;				 k=0;				 Comment=kFALSE;				 Code=kFALSE;				 Space=kFALSE;			 	}			 else if ((BuffCode[n]==' ')||(BuffCode[n]==',')||(BuffCode[n]==0x09))			 	{				 if (Code) Space=kTRUE;			 	}			 else if (BuffCode[n]=='/') Comment=kTRUE;			 else			 	{			 	 if (Comment==kFALSE)			 	 	{			 	 	 if ((Space)&&(Code))			 	 	 	{#if 0			 	 	 							 if (BuffParse[CodeLine].size==0)						 	{						 	 if (CheckLabel(BuffParse[CodeLine].Str[0]))						 	 	{								 printf("Label: %s\r\n", BuffParse[CodeLine].Str[0]);								 for (k=0; k<strlen(BuffParse[CodeLine].Str[0]); k++)						 	 	 	{						 	 	 	 BuffParse[CodeLine].Label[k]=BuffParse[CodeLine].Str[0][k];									 BuffParse[CodeLine].Str[0][k]=0;						 	 	 	}//								 strcat((char*)BuffParse[CodeLine].Label, BuffParse[CodeLine].Str[0]);								 BuffParse[CodeLine].size=0;								 						 	 	}							 else BuffParse[CodeLine].size++;						 	}						 else BuffParse[CodeLine].size++;		#endif						 BuffParse[CodeLine].size++;			 	 	 	 Space=kFALSE;						 Code=kFALSE;						 k=0;			 	 	 	}					 BuffParse[CodeLine].Str[BuffParse[CodeLine].size][k++]=BuffCode[n];					 if (k>=kMaxLengParam) k=kMaxLengParam-1;					 Code=kTRUE;			 	 	}			 	}		 	}		 i++;//		 printf("\r\n");		} printf("End Code\r\n"); for (n=0; n<=CodeLine; n++) 	{ 	  printf("%s:---> ", (char*)BuffParse[n].Label); 	  for (j=0; j<=BuffParse[n].size; j++) 	  	{ 	  	 printf("%s, ", (char*)BuffParse[n].Str[j]); 	  	}	  printf("  size %d \r\n", BuffParse[n].size);	   	}}unsigned char FindVar(char *val){ unsigned char n; for(n=0; n<kMaxkTblVar; n++) 	{ 	 if (val[0]==kTblVar[n].VarName) return(n);		  	} return(-1);}int FindAddr(char *val){ unsigned char 	n; char 			intstr[12]; int			temp; for (n=0; n<(strlen(val)-1); n++) intstr[n]=val[n+1]; temp=atoi(intstr); return(temp);}unsigned char CheckLabel(char* str){ if (str[strlen(str)-1]==':') return(kTRUE); else return(kFALSE);}unsigned char ParseCode(void){ unsigned int 	n; int			temp; unsigned char  endcode=kFALSE; printf("size %d\r\n", CodeLine); n=0; LineParse=0; while(1) 	{ 	 LineParse=n;	 	 if (CheckLabel(BuffParse[n].Str[0]))	 	{		 strcat((char*)BuffParse[n].Label, BuffParse[n].Str[0]);		 BuffParse[n].size-=1;	 	 temp=FindCmd((char*)BuffParse[n].Str[1]);	 	}	 else temp=FindCmd((char*)BuffParse[n].Str[0]);//	 printf("----> %s  %d\r\n", (char*)BuffParse[n].Str[0], temp); 	 if (temp<0) return(kErrCMD);	 PLCCode[n].Cmd=temp;	 if (temp==kEND) endcode=kTRUE;	 if (kTblCmd[PLCCode[n].Cmd].size!=BuffParse[n].size)	 	{	 	 printf("size not same.... cmd:%d,  %d   %d\r\n",PLCCode[n].Cmd, kTblCmd[n].size, BuffParse[n].size);	 	 return(kErrCMD);	 	}	 #if 1 	 	unsigned char 	i;	 	printf("%05d: %s, ", n, (char*)kTblCmd[PLCCode[n].Cmd].strCmd);		for (i=0; i<BuffParse[n].size; i++) printf("%s, ", (char*)BuffParse[n].Str[i+1]);		if (BuffParse[n].Label[0]) printf(" --->%s\r\n", (char*)BuffParse[n].Label);		else printf("\r\n");	 #endif 	 if (BuffParse[n].size==0) 	 	{	 	 	  	 	} 	 else if (BuffParse[n].size==1) 	 	{ 	 	 temp=FindVar(BuffParse[n].Str[1]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR0=temp;		 PLCCode[n].ParADDR0=FindAddr(BuffParse[n].Str[1]); 	 	}	 else if (BuffParse[n].size==2)	 	{ 	 	 temp=FindVar(BuffParse[n].Str[1]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR0=temp;		 PLCCode[n].ParADDR0=FindAddr(BuffParse[n].Str[1]);		  	 	 temp=FindVar(BuffParse[n].Str[2]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR1=temp;		 PLCCode[n].ParADDR1=FindAddr(BuffParse[n].Str[2]);	 	}	 else if (BuffParse[n].size==3)	 	{ 	 	 temp=FindVar(BuffParse[n].Str[1]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR0=temp;		 PLCCode[n].ParADDR0=FindAddr(BuffParse[n].Str[1]);		  	 	 temp=FindVar(BuffParse[n].Str[2]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR1=temp;		 PLCCode[n].ParADDR1=FindAddr(BuffParse[n].Str[2]);		  	 	 temp=FindVar(BuffParse[n].Str[3]);		 if (temp<0) return(kErrCMD);		 PLCCode[n].ParVAR2=temp;		 PLCCode[n].ParADDR2=FindAddr(BuffParse[n].Str[3]);	 	}	 else return(kErrCMD);	 n++;	 if (n>CodeLine) break; 	} if (endcode==kFALSE) return(kErrEND);// for (n=0; n<CodeLine; n++) printf("----> %d, %d, %d, %d, %d, %d, %d\r\n", PLCCode[n].Cmd, PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, PLCCode[n].ParVAR1, PLCCode[n].ParADDR1, PLCCode[n].ParVAR2, PLCCode[n].ParADDR2); return(kNoError); }void ResetPLC(void){ memset(RegD,0, sizeof(RegD)); memset(RegZ,0, sizeof(RegZ)); memset(RegM,0, sizeof(RegM)); memset(RegM_,0, sizeof(RegM_)); memset(RegX,0, sizeof(RegX)); memset(RegX_,0, sizeof(RegX_)); memset(RegY,0, sizeof(RegY)); memset(RegY_,0, sizeof(RegY_)); memset(PLCCode,0, sizeof(PLCCode)); memset(Timer,0, sizeof(Timer));}

void TimerProcess(void){
 unsigned short n;
 
 if (FlagsSystem.Tick100mS)
 	{
 	 for (n=0; n<128; n++)
 	 	{  		 Timer[n].Flags.TOUT_EdgeP=kFALSE;		 Timer[n].Flags.TOUT_EdgeN=kFALSE;
 	 	 if (Timer[n].Flags.RUN)
 	 	 	{
 	 	 	 if (Timer[n].Value) Timer[n].Value--;			 if (Timer[n].Value)			 	{			 	 if (Timer[n].Flags.TOUT==kTRUE)			 	 	{			 	 	 Timer[n].Flags.TOUT_EdgeN=kTRUE;			 	 	}			 	 Timer[n].Flags.TOUT=kFALSE;			 	}
			 else
			 	{ 				 if (Timer[n].Flags.TOUT==kFALSE) 				 	{ 				 	 Timer[n].Flags.TOUT_EdgeP=kTRUE; 				 	}
			 	 Timer[n].Flags.TOUT=kTRUE;
			 	}
 	 	 	}
 	 	}
 	}
 
 if (FlagsSystem.Tick10mS)
 	{
 	 for (n=256; n<512; n++)
 	 	{
 	 	 if (Timer[n].Flags.RUN)
 	 	 	{
 	 	 	 if (Timer[n].Value) Timer[n].Value--;
			 if (Timer[n].Value)				{				 if (Timer[n].Flags.TOUT==kTRUE)			 	 	{			 	 	 Timer[n].Flags.TOUT_EdgeN=kTRUE;			 	 	}				 Timer[n].Flags.TOUT=kFALSE;				}			else
			 	{				 if (Timer[n].Flags.TOUT==kFALSE) 				 	{ 				 	 Timer[n].Flags.TOUT_EdgeP=kTRUE; 				 	}
			 	 Timer[n].Flags.TOUT=kTRUE;
			 	}
 	 	 	}
 	 	} 	 
 	}}

void ResetTimer(short id){ Timer[id].Value=Timer[id].Preset;}
	void UpdateIO(void){ unsigned short n;
 for (n=0; n<kMaxOutput; n++)
 	{
	 IOdatProc.Output.OutWord[n]=(uint16_t)RegY[n].word;
 	}
 for (n=0; n<kMaxInput; n++)
 	{
	 RegX[n].word=IOdatProc.Input.InWord[n];
 	} // printf("Input:%d  %d\r\n", RegX[0].word, IOdatProc.Input.InWord[0]);}
unsigned char GetRegM(unsigned short id){
 short			addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (RegM[addr].word & kTblMasking[mask]) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegM_EdgeP(unsigned short id){ short	addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (RegMEdgeP[addr].word & kTblMasking[mask]) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegM_EdgeN(unsigned short id){ short	addr, mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (RegMEdgeN[addr].word & kTblMasking[mask]) return(kTRUE);
 return(kFALSE);}

void UpdateRegM(unsigned short id, unsigned char value){ short			addr, mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (value) RegM[addr].word|=kTblMasking[mask];
 else RegM[addr].word &=~(kTblMasking[mask]);}

unsigned char GetRegX(unsigned short id){ short			addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (RegX[addr].word & kTblMasking[mask]) return(kTRUE);
 return(kFALSE);}
unsigned char GetRegX_EdgeP(unsigned short id){
 unsigned short Edge;
 short			addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 Edge=RegX[addr].word^RegX_[addr].word;
 if ((Edge & kTblMasking[mask])&&(RegX[addr].word & kTblMasking[mask])) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegX_EdgeN(unsigned short id){
 unsigned short Edge;
 short			addr, mask;

 addr=id>>4;
 mask=id & 0x0F;
 Edge=RegX[addr].word^RegX_[addr].word;
 if ((Edge & kTblMasking[mask])&&((~RegX[addr].word) & kTblMasking[mask])) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegY(unsigned short id){ short			addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (RegY[addr].word & kTblMasking[mask]) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegY_EdgeP(unsigned short id){ unsigned short Edge; short			addr,mask;

 addr=id>>4;
 mask=id & 0x0F;
 Edge=RegY[addr].word^RegY_[addr].word;
 if ((Edge & kTblMasking[mask])&&(RegY[addr].word & kTblMasking[mask])) return(kTRUE);
 return(kFALSE);}

unsigned char GetRegY_EdgeN(unsigned short id){
 unsigned short Edge;
 short			addr, mask;

 addr=id>>4;
 mask=id & 0x0F;
 Edge=RegY[addr].word^RegY_[addr].word;
 if ((Edge & kTblMasking[mask])&&((~RegY[addr].word) & kTblMasking[mask])) return(kTRUE);
 return(kFALSE);}

void UpdateRegY(unsigned short id, unsigned char value){
 short			addr, mask;

 addr=id>>4;
 mask=id & 0x0F;
 if (value) RegY[addr].word|=kTblMasking[mask];
 else RegY[addr].word &=~(kTblMasking[mask]);}
unsigned char GetRegT(short id){ return(Timer[id].Flags.TOUT);}unsigned char GetRegT_EdgeP(short id){ return(Timer[id].Flags.TOUT_EdgeP);}unsigned char GetRegT_EdgeN(short id){ return(Timer[id].Flags.TOUT_EdgeN);}

void UpdateSpecialReg(void){
 if (PLCRUN)
 	{
 	 UpdateRegM(kAlwaysON, kTRUE);
	 UpdateRegM(kAlwaysOFF, kFALSE);
 	} else
 	{
 	 UpdateRegM(kAlwaysON, kFALSE);
	 UpdateRegM(kAlwaysOFF, kTRUE);
 	}
 
if (FlagsSystem.Cycle100mS) UpdateRegM(kCyc100mS, kTRUE);
else UpdateRegM(kCyc100mS, kFALSE);
if (FlagsSystem.Cycle500mS) UpdateRegM(kCyc500mS, kTRUE);
else UpdateRegM(kCyc500mS, kFALSE);
if (FlagsSystem.Cycle1S) UpdateRegM(kCyc1S, kTRUE);
else UpdateRegM(kCyc1S, kFALSE); if (PLC1stRUN) UpdateRegM(kFirstON, kTRUE); else UpdateRegM(kFirstON, kFALSE);} 
unsigned char GetRegBit(int type, int id){ if (type==kRegM)   {	return(GetRegM(id));   } else if (type==kRegX)   {	return(GetRegX(id));   } else if (type==kRegY)   {	return(GetRegY(id));   } else if (type==kRegT)   {	return(GetRegT(id));   } return(kFALSE);}unsigned char GetRegBitEdgeP(int type, int id){ if (type==kRegM)   {	return(GetRegM_EdgeP(id));   } else if (type==kRegX)   {	return(GetRegX_EdgeP(id));   } else if (type==kRegY)   {	return(GetRegY_EdgeP(id));   } else if (type==kRegT)   {	return(GetRegT_EdgeP(id));   } return(kFALSE);}unsigned char GetRegBitEdgeN(int type, int id){ if (type==kRegM)   {	return(GetRegM_EdgeN(id));   } else if (type==kRegX)   {	return(GetRegX_EdgeN(id));   } else if (type==kRegY)   {	return(GetRegY_EdgeN(id));   } else if (type==kRegT)   {	return(GetRegT_EdgeN(id));   } return(kFALSE);}int GetRegWord(int type, int id){ if (type==kRegD) 					   		// LOAD VAR 16 bit   {	return(RegD[id]);   } else if (type==kRegT)   {	return(Timer[id].Value);   } else if (type==kConst)   {	return(id);   } return(0);}int GetRegWord32(int type, int id){ if (type==kRegD) 					   		// LOAD VAR 16 bit   {	return(RegD[id]|(RegD[id+1]<<16));   } else if (type==kRegT)   {	return(Timer[id].Value);   } else if (type==kConst)   {	return(id);   } return(0);}void SetRegBit(int type, int id, unsigned char val){  if (type==kRegM) 	{ 	 UpdateRegM(id, val); 	} else if (type==kRegY) 	{ 	 UpdateRegY(id, val); 	}}void SetRegWord(int type, int id, int val){ if(type==kRegD) 	{ 	 RegD[id]=val; 	} else if (type==kRegT) 	{ 	 Timer[id].Value=val; 	}}void SetRegWord32(int type, int id, int val){ if(type==kRegD) 	{ 	 RegD[id]=val & 0xFFFF;	 RegD[id+1]=val>>16; 	} else if (type==kRegT) 	{ 	 Timer[id].Value=val; 	}}void ParsingPLC(void){ int n; unsigned char idxACC; unsigned char RegAcc[8]; int	   	   value1, value2, value3; long long int value4; unsigned char temp;  idxACC=0; for (n=0; n<sizeof(RegAcc); n++) RegAcc[n]=0; n=0; while(1) 	{// ******************** END ************************ 		 if (PLCCode[n].Cmd==kEND) break;// ******************** LD ************************	 else if (PLCCode[n].Cmd==kLD)	 	{	 	 RegAcc[idxACC]=GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);//		 printf("LD %d  %d  %d\r\n", PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, RegAcc[idxACC]);	 	}// ******************** LDI ************************	 	 else if (PLCCode[n].Cmd==kLDI)	 	{	 	 if (GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0)) RegAcc[idxACC]=kFALSE;		 else RegAcc[idxACC]=kTRUE;	 	}// ******************** LDP ************************	 	 else if (PLCCode[n].Cmd==kLDP)	 	{	 	 RegAcc[idxACC]=GetRegBitEdgeP(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);	 	}// ******************** LDN ************************	 	 else if (PLCCode[n].Cmd==kLDN)	 	{	 	 RegAcc[idxACC]=GetRegBitEdgeN(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);	 	}// ******************** GREATER ************************	 else if (PLCCode[n].Cmd==kGREATER)	 	{	 	 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);	 	 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);	 	 		 if (value1>value2) RegAcc[idxACC]=kTRUE;		 else RegAcc[idxACC]=kFALSE;	 	}	  // ******************** GREATER EQUAL ************************	  else if (PLCCode[n].Cmd==kGREATEQUAL)		 {		  value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);		  value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);	  		  if (value1>=value2) RegAcc[idxACC]=kTRUE;		  else RegAcc[idxACC]=kFALSE;		 }	    // ******************** LOWER ************************	   else if (PLCCode[n].Cmd==kLOWER)		  {		   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);		   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);	   		   if (value1<value2) RegAcc[idxACC]=kTRUE;		   else RegAcc[idxACC]=kFALSE;		  }       // ******************** LOWER EQUAL ************************		else if (PLCCode[n].Cmd==kLOWEQUAL)		   {			value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					if (value1<=value2) RegAcc[idxACC]=kTRUE;			else RegAcc[idxACC]=kFALSE;		   }		// ******************** EQUAL ************************		 else if (PLCCode[n].Cmd==kEQUAL)			{			 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1); 	 			 if (value1==value2) RegAcc[idxACC]=kTRUE;			 else RegAcc[idxACC]=kFALSE;			}	  	// ******************** ANL ************************		  else if (PLCCode[n].Cmd==kANL)			 {			  RegAcc[idxACC]&=GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			  			 }	  	// ******************** ANLI ************************		else if (PLCCode[n].Cmd==kANLI)			  {			   if (GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0)) temp=kFALSE;			   else temp=kTRUE;			   RegAcc[idxACC]&=temp; 			  }    	// ******************** ORL ************************		else if (PLCCode[n].Cmd==kORL)				{				 RegAcc[idxACC]|=GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			 				}	 	// ******************** ORLI ************************		else if (PLCCode[n].Cmd==kORLI)			  {			   if (GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0)) temp=kFALSE;			   else temp=kTRUE;			   RegAcc[idxACC]|=temp;		   			  }    	// ******************** ANP ************************		else if (PLCCode[n].Cmd==kANP)			{			 RegAcc[idxACC]&=GetRegBitEdgeP(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			 			}	 	// ******************** ANN ************************		else if (PLCCode[n].Cmd==kANN)			  {			   RegAcc[idxACC]&=GetRegBitEdgeN(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);		   			  }    	// ******************** ORP ************************		else if (PLCCode[n].Cmd==kORP)			 {			  RegAcc[idxACC]|=GetRegBitEdgeP(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);		  			 }	  	// ******************** ORN ************************		else if (PLCCode[n].Cmd==kORN)			  {			   RegAcc[idxACC]|=GetRegBitEdgeN(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);		   			  }    	// ******************** AND GREATER ************************		else if ((PLCCode[n].Cmd==kANL_GREATER)||(PLCCode[n].Cmd==kANL_GREATER32))			  {			   if (PLCCode[n].Cmd==kANL_GREATER)			   	  {				   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   	  }			   else			   		{				     value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				     value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   		}			   if (value1>value2) temp=kTRUE;			   else temp=kFALSE;			   RegAcc[idxACC]&=temp;			  }		// ******************** OR GREATER ************************		else if ((PLCCode[n].Cmd==kORL_GREATER)||(PLCCode[n].Cmd==kORL_GREATER32))			  {			   if (PLCCode[n].Cmd==kORL_GREATER)			   	  {				   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   	  }			   else			   		{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   		}			   if (value1>value2) temp=kTRUE;			   else temp=kFALSE;			   RegAcc[idxACC]|=temp;			  }	// ******************** AND GREATER EQUAL ************************		else if ((PLCCode[n].Cmd==kANL_GREATEQUAL)||(PLCCode[n].Cmd==kANL_GREATEQUAL32))			  {			   if (PLCCode[n].Cmd==kANL_GREATEQUAL)			   	  {				   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   	  }			   else 			   		{				     value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				     value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   		}			   if (value1>=value2) temp=kTRUE;			   else temp=kFALSE;			   RegAcc[idxACC]&=temp;			  }	// ******************** OR GREATER ************************		else if ((PLCCode[n].Cmd==kORL_GREATEQUAL)||(PLCCode[n].Cmd==kORL_GREATEQUAL32))			  {			   if (PLCCode[n].Cmd==kORL_GREATEQUAL)			   	  {				   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   	  }			   else			   		{				     value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   	 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   		}			   if (value1>=value2) temp=kTRUE;			   else temp=kFALSE;			   RegAcc[idxACC]|=temp;			  }	// ******************** AND LOWER ************************		else if ((PLCCode[n].Cmd==kANL_LOWER)||(PLCCode[n].Cmd==kANL_LOWER32))			  {			   if (PLCCode[n].Cmd==kANL_LOWER)			   	  {				   value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				   value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   	  }			   else			   		{					   value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					   value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			   		}			   if (value1<value2) temp=kTRUE;			   else temp=kFALSE;			   RegAcc[idxACC]&=temp;			  }	// ******************** OR LOWER ************************		else if ((PLCCode[n].Cmd==kORL_LOWER)||(PLCCode[n].Cmd==kORL_LOWER32))			{			 if (PLCCode[n].Cmd==kORL_LOWER)			 	{			     value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);			     value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 else			 	{				 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 if (value1<value2) temp=kTRUE;			 else temp=kFALSE;			 RegAcc[idxACC]|=temp;			}   // ******************** AND LOWER EQUAL ************************	   else if ((PLCCode[n].Cmd==kANL_LOWEQUAL)||(PLCCode[n].Cmd==kANL_LOWEQUAL32))			 {			  if (PLCCode[n].Cmd==kANL_LOWEQUAL)			  	 {				  value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				  value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			  	 }			  else			  	 {				  value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				  value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			  	 }			  if (value1<=value2) temp=kTRUE;			  else temp=kFALSE;			  RegAcc[idxACC]&=temp;			 }   // ******************** OR LOWER EQUAL ************************	   else if ((PLCCode[n].Cmd==kORL_LOWEQUAL)||(PLCCode[n].Cmd==kORL_LOWEQUAL32))			{			  if (PLCCode[n].Cmd==kORL_LOWEQUAL)			  	 {				  value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				  value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			  	 }			  else			  	 {				  value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				  value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			  	 }			  if (value1<=value2) temp=kTRUE;			  else temp=kFALSE;			  RegAcc[idxACC]|=temp;	   		}  // ******************** AND LOWER EQUAL ************************	  else if ((PLCCode[n].Cmd==kANL_EQUAL)||(PLCCode[n].Cmd==kANL_EQUAL32))			{			 if (PLCCode[n].Cmd==kANL_EQUAL)			 	{				 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 else			 	{				 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 if (value1==value2) temp=kTRUE;			 else temp=kFALSE;			 RegAcc[idxACC]&=temp;			}  // ******************** OR LOWER EQUAL ************************	  else if ((PLCCode[n].Cmd==kORL_EQUAL)||(PLCCode[n].Cmd==kORL_EQUAL32))			{			 if (PLCCode[n].Cmd==kORL_EQUAL)			 	{				 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 else			 	{				 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);				 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);			 	}			 if (value1==value2) temp=kTRUE;			 else temp=kFALSE;			 RegAcc[idxACC]|=temp;	  		} // ******************** SET ************************	 else if (PLCCode[n].Cmd==kSET)		   	{		   	 if (RegAcc[idxACC])		   	 	{		     	 SetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, kTRUE);		   	 	}	 		} // ******************** RST ************************	 else if (PLCCode[n].Cmd==kRST)			{		   	 if (RegAcc[idxACC])		   	 	{		   	 	 if (PLCCode[n].ParVAR0==kRegT)		   	 	 	{		   	 	 	 ResetTimer(PLCCode[n].ParADDR0);		   	 	 	}				 else if (PLCCode[n].ParVAR0==kRegD)				 	{				 	 RegD[PLCCode[n].ParADDR0]=0;				 	}				 else				 	{					 SetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, kFALSE);				 	}		   	 	}			} // ******************** ALT ************************	 else if (PLCCode[n].Cmd==kALT)			{			 if (RegAcc[idxACC])			 	{				 if (GetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0)) SetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, kFALSE);				 else SetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, kTRUE);			 	}			} // ******************** OUT ************************	 else if (PLCCode[n].Cmd==kOUT)			{			 SetRegBit(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, RegAcc[idxACC]);			 //printf("OUT %d  %d %d\r\n", PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, RegAcc[idxACC]);			} // ******************** BRA ************************	 else if (PLCCode[n].Cmd==kBRA)			{			 idxACC++;			 if (idxACC>=2) idxACC=1;			} // ******************** BRE ************************	 else if (PLCCode[n].Cmd==kBRE)			{			 if (idxACC==1)			 	{			 	 RegAcc[0]|=RegAcc[1];				 idxACC=0;				 RegAcc[1]=0;			 	}			} // ******************** MOV ************************	 else if ((PLCCode[n].Cmd==kMOV)||(PLCCode[n].Cmd==kMOV32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kMOV)				 	{				 	 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1, value1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1, value1);				 	}			 	}			} // ******************** ADD ************************	 else if ((PLCCode[n].Cmd==kADD)||(PLCCode[n].Cmd==kADD32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kADD)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 value1+=value2;				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);			 	}			} // ******************** SUB ************************	 else if ((PLCCode[n].Cmd==kSUB)||(PLCCode[n].Cmd==kSUB32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kSUB)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 value1-=value2;				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				}			} // ******************** MUL ************************	 else if ((PLCCode[n].Cmd==kMUL)||(PLCCode[n].Cmd==kMUL32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kMUL)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 value4=value1*value2;				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value4 & 0xFFFFFFFF);				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2+2, value4 >> 32);			 	}			} // ******************** DIV ************************	 else if ((PLCCode[n].Cmd==kDIV)||(PLCCode[n].Cmd==kDIV32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kDIV)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);				 	}				 value3=value1 % value2;				 value1/=value2;				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2+2, value3);			 	}			} // ******************** AND ************************	 else if ((PLCCode[n].Cmd==kAND)||(PLCCode[n].Cmd==kAND32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kAND)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1&=value2;					 SetRegWord(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1&=value2;					 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				 				 	}			 	}			} // ******************** OR ************************	 else if ((PLCCode[n].Cmd==kOR)||(PLCCode[n].Cmd==kOR32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kOR)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1|=value2;					 SetRegWord(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1|=value2;					 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);			 	 				 	}			 	}			} // ******************** XOR ************************	 	 else if ((PLCCode[n].Cmd==kXOR)||(PLCCode[n].Cmd==kXOR32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kXOR)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1^=value2;					 SetRegWord(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 value2=GetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1);					 value1^=value2;					 SetRegWord32(PLCCode[n].ParVAR2, PLCCode[n].ParADDR2, value1);			 	 				 	}			 	}			}	  // ******************** NOT ************************	 	 else if ((PLCCode[n].Cmd==kNOT)||(PLCCode[n].Cmd==kNOT32))			{			 if (RegAcc[idxACC])			 	{				 if (PLCCode[n].Cmd==kNOT)				 	{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1, ~value1);				 	}				 else				 	{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord32(PLCCode[n].ParVAR1, PLCCode[n].ParADDR1, ~value1);				 	}			 	}			} // ******************** INC ************************	 	 else if ((PLCCode[n].Cmd==kINC)||(PLCCode[n].Cmd==kINC32))			{			 if (RegAcc[idxACC])				{				 if (PLCCode[n].Cmd==kINC)					{					 value1=GetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, value1+1);					 					}				 else					{					 value1=GetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0);					 SetRegWord32(PLCCode[n].ParVAR0, PLCCode[n].ParADDR0, value1+1);					}				}			}		 	 	 n++; 	}}void GetEdgeBitProcess(void){ unsigned short n; unsigned short temp; for (n=0; n<kMaxRegM; n++) 	{	 temp=RegM[n].word^RegM_[n].word;	 RegMEdgeP[n].word=temp&RegM[n].word;	 RegMEdgeN[n].word=temp&(~RegM[n].word);	 RegM_[n].word=RegM[n].word; 	} for (n=0; n<kMaxInput; n++) 	{ 	 temp=RegX[n].word^RegX_[n].word;	 RegXEdgeP[n].word=temp&RegX[n].word;	 RegXEdgeN[n].word=temp&(~RegX[n].word);	 RegX_[n].word=RegX[n].word; 	}  for (n=0; n<kMaxOutput; n++) 	{ 	 temp=RegY[n].word^RegY_[n].word;	 RegYEdgeP[n].word=temp&RegY[n].word;	 RegYEdgeN[n].word=temp&(~RegY[n].word);	 RegY_[n].word=RegY[n].word; 	} }
void PLCProcess(void){#if 1 if (PLCSTOP_) PLCRUN=kFALSE; if (PLCRUN_) PLCRUN=kTRUE;
 PLC1stRUN=kFALSE;; if (PLCRUN!=PLCRUN_LAST)	{	 PLCRUN_LAST=PLCRUN;	 if (PLCRUN) PLC1stRUN=kTRUE;	} if (PLCRUN) 	{ 	 GetEdgeBitProcess(); 	 TimerProcess();
 	 UpdateSpecialReg();	 ParsingPLC();
 	} else ResetPLC();UpdateIO();PLCCycle_++;if (FlagsSystem.Tick1S)	{	 PLCCycle=PLCCycle_;	 PLCCycle_=0;	 printf("%d, %d\r\n", RegD[0], PLCCycle);	}//printf("OutY: %d\r\n", RegY[0].word);#endif}


