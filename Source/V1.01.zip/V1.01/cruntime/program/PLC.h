#ifndef PLC_H
#define PLC_H
#include <stdint.h>

#define kMaxParam		5
#define kMaxLengParam	16

#define kMaxRegM		1024
#define kMaxRegD		16384
#define kMaxRegZ		128


#define kAlwaysON		8000
#define kAlwaysOFF		8001
#define kFirstON		8002
#define kCyc100mS		8012
#define kCyc500mS		8013
#define kCyc1S			8014


enum eErrCode{
	kNoError,
	kErrCMD,
	kErrEND,
};



enum eCmd{
	kEND,
	kLD,
	kLDI,
	kLDP,
	kLDN,
	kGREATER,
	kGREATEQUAL,
	kLOWER,
	kLOWEQUAL,
	kEQUAL,
	kANL,
	kANLI,
	kORL,
	kORLI,
	kANP,
	kANN,
	kORP,
	kORN,
	kANL_GREATER,
	kANL_GREATER32,
	kORL_GREATER,
	kORL_GREATER32,
	kANL_GREATEQUAL,
	kANL_GREATEQUAL32,
	kORL_GREATEQUAL,
	kORL_GREATEQUAL32,
	kANL_LOWER,
	kANL_LOWER32,
	kORL_LOWER,
	kORL_LOWER32,
	kANL_LOWEQUAL,
	kANL_LOWEQUAL32,
	kORL_LOWEQUAL,
	kORL_LOWEQUAL32,
	kANL_EQUAL,
	kANL_EQUAL32,
	kORL_EQUAL,
	kORL_EQUAL32,
	kSET,
	kRST,
	kALT,
	kOUT,
	kBRA,
	kBRE,
	kMOV,
	kMOV32,
	kADD,
	kADD32,
	kSUB,
	kSUB32,	
	kMUL,
	kMUL32,	
	kDIV,
	kDIV32,
	kAND,
	kAND32,
	kOR,
	kOR32,
	kXOR,
	kXOR32,
	kNOT,
	kNOT32,
	kINC,
	kINC32,
	kLABEL,
//	kFOR,
//	kNEXT,
//	kPLSY,
};


struct stTimerFlags{
	unsigned char	RUN:1;
	unsigned char	TOUT:1;
	unsigned char	TOUT_EdgeP:1;
	unsigned char	TOUT_EdgeN:1;
};

struct stTimer{
	unsigned int			Value;
	unsigned int			Preset;
	struct stTimerFlags		Flags;
};


struct stTblCmd{
	enum eCmd		Cmd;
	char			*strCmd;
	unsigned char	size;
};


enum eVar{
	kRegM,
	kRegX,
	kRegY,
	kRegT,
	kRegD,
	kRegZ,
	kConst,
};

struct stTblVAR{
	enum eVar	VarType;
	char		VarName;
};


struct st16Bit{
 short		bit0	:1;
 short		bit1	:1;
 short		bit2	:1;
 short		bit3	:1;
 short		bit4	:1;
 short		bit5	:1;
 short		bit6	:1;
 short		bit7	:1;
 short		bit8	:1;
 short		bit9	:1;
 short		bit10	:1;
 short		bit11	:1;
 short		bit12	:1;
 short		bit13	:1;
 short		bit14	:1;
 short		bit15	:1;
};


union uBitReg{
	short			word;
	struct st16Bit	bit;
};


struct stPLCCode{
	enum eCmd	Cmd;
	char		Label[kMaxLengParam];
	int			ParVAR0;
	int			ParADDR0;
	int			ParVAR1;
	int			ParADDR1;
	int			ParVAR2;
	int			ParADDR2;
};


struct stCodeParse{
	char			Label[kMaxLengParam];
	char			Str[kMaxParam][kMaxLengParam];
	unsigned char	size;
};


extern unsigned int		PLCRUN, PLCERR, PLCRUN_, PLCSTOP_;

void InitPLC(void);
void PLCProcess(void);
unsigned char ParseCode(void);
void ResetPLC(void);
void OPEN_CODE(void);

#endif
