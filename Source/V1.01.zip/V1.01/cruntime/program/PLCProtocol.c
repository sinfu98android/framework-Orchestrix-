#include "PLCProtocol.h"
#include "MitsubishiProtocol.h"
#include "OmronProtocol.h"
#include "gps.h"
#include "AND.h"
#include "Modbus.h"
#include "UART.h"
#include "System.h"
#include <termios.h>
#include "TCPModbus.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <pthread.h>
#include "MiscDataConv.h"

int				CycleCOM=20000;
int 			scalerCom[kMax_UARTChan];



const int kTblBaudRate[]={
	0,
	B2400,
	B4800,
	B9600,
	B19200,
	B38400,
	B57600,
	B115200,
};

const char kTblDevParam[][16]={
	{"COM0"},
	{"COM1"},
	{"COM2"},
	{"COM3"},
	{"COM4"},
	{"COM5"},
	{"COM6"},
	{"COM7"},
	{"COM8"},
	{"COM9"},
	{"TCP0"},
	{"TCP1"},
	{"TCP2"},
	{"TCP3"},
	{"TCP4"},
	{"TCP5"},
	{"TCP6"},
	{"TCP7"},
	{"TCP8"},
	{"TCP9"},	
};
#define kMaxDevParam	sizeof(kTblDevParam)/16


const char kTblDataParam[][16]={
	{"COMDAT0"},
	{"COMDAT1"},
	{"COMDAT2"},
	{"COMDAT3"},
	{"COMDAT4"},
	{"COMDAT5"},
	{"COMDAT6"},
	{"COMDAT7"},
	{"COMDAT8"},
	{"COMDAT9"},
	{"TCPDAT0"},
	{"TCPDAT1"},
	{"TCPDAT2"},
	{"TCPDAT3"},
	{"TCPDAT4"},
	{"TCPDAT5"},
	{"TCPDAT6"},
	{"TCPDAT7"},
	{"TCPDAT8"},
	{"TCPDAT9"},	
};
#define kMaxParamDat	sizeof(kTblDataParam)/16


const char kPLCType[kMaxPLCType][16]={
	{"NOPLC"},
	{"OMRON"},
	{"MITSUBISHI"},
	{"LCAND"},
	{"MODBUS"},
	{"GPS"},
};
#define kMaxPLCType	sizeof(kPLCType)/16


const char kParity[][16]={
	{"NONE"},
	{"ODD"},
	{"EVEN"},
};
#define kMaxParity	sizeof(kParity)/16


const char kDataBit[][16]={
	{"NONE"},
	{"7BIT"},
	{"8BIT"},
};
#define kMaxDataBit	sizeof(kDataBit)/16


const char kStopBit[][16]={
	{"NONE"},
	{"1STOP"},
	{"2STOP"},
};
#define kMaxStopBit	sizeof(kStopBit)/16


const char kDataType[][16]={
	{"NONE"},
	{"B_DATA"},
	{"B_M"},
	{"REG_D"},
	{"REG_W"},
	{"HOLDING"},
};
#define kMaxDataType	sizeof(kDataType)/16



char					*ParamConfig="/var/www/html/program/param.txt";
const char 				ServerLokal[] = "127.0.0.1";
unsigned char			Respond[kMax_UARTChan];
short					TimeOutResp[kMax_UARTChan];
//enum eStatePLC			StatePLC[kMax_UARTChan];
signed char 			DlyCOM[kMax_UARTChan];
unsigned char			DevNum[kMax_UARTChan];
unsigned short			ComAddr[kMax_UARTChan];
unsigned short			ComTot[kMax_UARTChan];
int						TickCOM[kMax_UARTChan], TickCOM_[kMax_UARTChan];
union uDataPLCType		DataPLC_RX[kMax_UARTChan];
union uDataPLCType		DataPLC_TX[kMax_UARTChan];
struct  stUARTPLC		PLCParam[kMax_UARTChan];
struct  stTCPPLC		PLCParamTCP[kMax_TCPChan];
unsigned char			WRStatusCOM[kMax_UARTChan][kMaxBuffDEV];
unsigned char			WriteStat[kMax_UARTChan];
int 					AddrCOM[kMax_UARTChan];
int						IdxWR[kMax_UARTChan];
pthread_t				threadPLCProtocol;



// MITSUBISHI	Default (0, 0, B9600, kEVEN_PARITY, k7_BIT, k1_STOP)
// OMRON 		Default (0, 0, B9600, kEVEN_PARITY, k7_BIT, k2_STOP)
// LC AND		Default (0, 0, B9600, kNO_PARITY, k8_BIT, k1_STOP)
// MODBUS		Default (0, 1, B115200, kNO_PARITY, k8_BIT, k1_STOP)


void OpenParam(void)
{
 FILE *fptr;
 int res;
 int n, k, m, count;
 enum ePLCType	PLCType=kNoPLC;
 int			speedCyc=100000;
 unsigned char 	COMType;
 unsigned short	DevNum;
 unsigned short	Port;
 char			IPAddr[kMaxStrServer];
 int			Baudrate;
 char			Parity;
 char			DataBit;
 char			StopBit;
 short			idx;
 unsigned int	Addr;
 short			Size;
 char 			DataType;
 short			totQueue[kMax_UARTChan];
 short			totQueueTCP[kMax_TCPChan];
 struct stSplit BuffParse;
 struct stSplit BuffSplit;
 int totline=0;
// int totsplit=0;
 //int totMode=0;
 unsigned char stat=kFALSE;


 for (n=0; n<kMax_UARTChan; n++) totQueue[n]=0;
 for (n=0; n<kMax_TCPChan; n++) totQueueTCP[n]=0;
 
 MakeSureFileExist(ParamConfig);

 res=findSize(ParamConfig);
 if (res<=0) return;
 char myString[res+10];
 
 printf("Open Config:\r\n");
 if (res<=0) return;
 memset(myString, 0, sizeof(myString));
 for (n=0; n<kMaxString; n++) memset(BuffParse.str[n], 0, sizeof(BuffParse.str[n]));
 for (n=0; n<kMaxString; n++) memset(BuffSplit.str[n], 0, sizeof(BuffSplit.str[n])); 
 
 
 fptr = fopen(ParamConfig, "r");
 fread(myString, sizeof(myString), 1, fptr);
 fclose(fptr); 
 totline=SplitLine((char*)myString, (struct stSplit*)&BuffParse);
 printf("Total Line: %d \r\n", totline);
//for (n=0; n<totline; n++) printf("%s\r\n", (char*)&BuffParse.str[n]);
// printf("\r\n");

 for (n=0; n<totline; n++)
 	{
 	 if (BuffParse.str[n][0]=='#')
 	 	{
 	 	 printf(" NOTE: %s\r\n", (char*)BuffParse.str[n]);
 	 	}
	 else
	 	{
		 for (k=0; k<kMaxDevParam; k++)
		 	{
		 	 if (strpos((char*)&kTblDevParam[k], (char*)&BuffParse.str[n])>=0)
		 	 	{
		 	 	 memset((char*)&BuffSplit, 0, sizeof(BuffSplit));
		 	 	 SplitString((char*)BuffParse.str[n], (struct stSplit*)&BuffSplit,',');
				 stat=kTRUE;
	//**********************************************************************************// Get COM Type
				 count=0;
				 for (m=0; m<kMaxDevParam; m++)
				   {
					if (CmpStr((char*)&BuffSplit.str[0], (char*)&kTblDevParam[m]))
					   {
						COMType=m;
						printf("COM Type: %d, ", COMType);
						break;
					   }
					count++;
					if (count>=kMaxDevParam) stat=kFALSE;
				   }
				 if (stat==kFALSE) break;
	//**********************************************************************************// Get PLC Type
				 count=0;
				 for (m=0; m<kMaxPLCType; m++)
					{
					 if (CmpStr((char*)&BuffSplit.str[1], (char*)&kPLCType[m]))
						{
						 PLCType=m;
						 printf("PLC Type: %d, ", PLCType);
						 break;
						}
					 count++;
					 if (count>=kMaxPLCType) stat=kFALSE;
				 	}
				 if (stat==kFALSE) break;
	 //**********************************************************************************// Get Device Number
	 			  DevNum=atoi((char*)&BuffSplit.str[2]);
	 			  printf("Dev Number: %d, ", DevNum);
	 //**********************************************************************************// Get COM Parameter
	 			  if ((COMType==0)||(COMType==1)||(COMType==2)||(COMType==3)||(COMType==4)||				// COMType 0-9 ---> COM 0-9
				  	  (COMType==5)||(COMType==6)||(COMType==7)||(COMType==8)||(COMType==9))
		 			  	{
		 			  	 Baudrate=atoi((char*)&BuffSplit.str[3]);
					  	 printf("Baudrate: %d, ", Baudrate);
						 //******************************************************************//
						 count=0;
						 for (m=0; m<kMaxParity; m++)
							{
							 if (CmpStr((char*)&BuffSplit.str[4], (char*)&kParity[m]))
								{
								 Parity=m;
								 printf("Parity: %d, ", Parity);
								 break;
								}
							 count++;
							 if (count>=kMaxParity) stat=kFALSE;
							}
						 if (stat==kFALSE) break;
						 //******************************************************************//
						 count=0;
						 for (m=0; m<kMaxDataBit; m++)
							{
							 if (CmpStr((char*)&BuffSplit.str[5], (char*)&kDataBit[m]))
								{
								 DataBit=m;
								 printf("DataBit: %d, ", DataBit);
								 break;
								}
							 count++;
							 if (count>=kMaxDataBit) stat=kFALSE;
							}
						 if (stat==kFALSE) break;
						 //******************************************************************//
						 count=0;
						 for (m=0; m<kMaxStopBit; m++)
							{
							 if (CmpStr((char*)&BuffSplit.str[6], (char*)&kStopBit[m]))
								{
								 StopBit=m;
								 printf("StopBit: %d, ", StopBit);
								 break;
								}
							 count++;
							 if (count>=kMaxStopBit) stat=kFALSE;
							}
						 if (stat==kFALSE) break;								 
						 //******************************************************************//
						 speedCyc=strToInt((char*)BuffSplit.str[7]);
						 printf(" speedcyc COM: %s, %s %d", (char*)BuffSplit.str[0], (char*)BuffSplit.str[7], speedCyc);
		 			  	}
				  else if ((COMType==10)||(COMType==11)||(COMType==12)||(COMType==13)||(COMType==14)||		// COMType 10-19 ---> TCP0-9
				  		   (COMType==15)||(COMType==16)||(COMType==17)||(COMType==18)||(COMType==19))
						  	{
							  speedCyc=strToInt((char*)BuffSplit.str[5]);
							  printf(" speedcyc TCP: %s, %s %d", (char*)BuffSplit.str[0], (char*)BuffSplit.str[5], speedCyc);
						  	
			 			  	  memset((char*)&IPAddr, 0, sizeof(IPAddr));
						  	  strcat((char*)&IPAddr, (char*)&BuffSplit.str[3]);
						 	  printf("IP Addr: %s, ", (char*)&IPAddr);
							  Port=atoi((char*)&BuffSplit.str[4]);
							  printf("Port: %d, ", Port);
						  	}
	//**********************************************************************************// 
				 printf("\r\n");
				 if (stat)
				 	{			 
				 	 if ((COMType==0)||(COMType==1)||(COMType==2)||(COMType==3)||(COMType==4)||
				  	  (COMType==5)||(COMType==6)||(COMType==7)||(COMType==8)||(COMType==9))
				 	 	{
						 PLCParam[COMType].PLCType=PLCType;
						 PLCParam[COMType].DevNum=DevNum;
						 PLCParam[COMType].speedcyc=speedCyc;
						 if (Baudrate==2400) PLCParam[COMType].Baudrate=k2400;
						 else if (Baudrate==4800) PLCParam[COMType].Baudrate=k4800;
						 else if (Baudrate==9600) PLCParam[COMType].Baudrate=k9600;
						 else if (Baudrate==19200) PLCParam[COMType].Baudrate=k19200;
						 else if (Baudrate==38400) PLCParam[COMType].Baudrate=k38400;
						 else if (Baudrate==57600) PLCParam[COMType].Baudrate=k57600;
						 else if (Baudrate==115200) PLCParam[COMType].Baudrate=k115200;
						 else PLCParam[COMType].Baudrate=k9600;
						 PLCParam[COMType].Parity=Parity;
						 PLCParam[COMType].DataSize=DataBit;
						 PLCParam[COMType].StopSize=StopBit;
				 	 	}
					 else if ((COMType==10)||(COMType==11)||(COMType==12)||(COMType==13)||(COMType==14)||
				  		   (COMType==15)||(COMType==16)||(COMType==17)||(COMType==18)||(COMType==19))
					 	{
						 PLCParamTCP[COMType-10].PLCType=PLCType;
						 PLCParamTCP[COMType-10].DevNum=DevNum;
						 PLCParamTCP[COMType-10].Port=Port;
						 strcat((char*)&PLCParamTCP[COMType-10].Server, (char *)&IPAddr);
					 	}
				 	 
				 	}
	 	 	 	}
		 	}

		 for (k=0; k<kMaxParamDat; k++)
		 	{
		 	 if (strpos((char*)&kTblDataParam[k], (char*)&BuffParse.str[n])>=0)
		 	 	{
		 	 	 memset((char*)&BuffSplit, 0, sizeof(BuffSplit));
		 	 	 SplitString((char*)BuffParse.str[n], (struct stSplit*)&BuffSplit,',');
				 stat=kTRUE;
				 idx=k;		//kDataType
				 printf("%d --->", idx);
	//*********************************************************************************************// Get Data Type
				 count=0;
				 for (m=0; m<kMaxDataType; m++)
				    {
					 if (CmpStr((char*)&BuffSplit.str[1], (char*)&kDataType[m]))
					    {
						 DataType=m;
						 printf("DataType: %d, ", DataType);
						 break;
					    }
					 count++;
					 if (count>=kMaxDataType) stat=kFALSE;
				   	}
				 if (stat==kFALSE) break;
	 //*********************************************************************************************// Get Address
				 Addr=atoi((char*)&BuffSplit.str[2]);
	 			 printf("Addr: %d, ", Addr);
	 //*********************************************************************************************// Get Size
	 			 Size=atoi((char*)&BuffSplit.str[3]);
				 printf("Size: %d, ", Size);
	 //*********************************************************************************************//
				 printf("\r\n");
				 if (stat)
				 	{
				 	 if (idx<10)
				 	 	{
				 	 	 PLCParam[idx].DataParam[totQueue[idx]].DataType=DataType;
						 PLCParam[idx].DataParam[totQueue[idx]].Addr=Addr;
						 PLCParam[idx].DataParam[totQueue[idx]].Size=Size;
						 totQueue[idx]++;
				 	 	}
					 else if ((idx>=10)&&(idx<=19))
					 	{
					 	 PLCParamTCP[idx-10].DataParam[totQueueTCP[idx-10]].DataType=DataType;
						 PLCParamTCP[idx-10].DataParam[totQueueTCP[idx-10]].Addr=Addr;
						 PLCParamTCP[idx-10].DataParam[totQueueTCP[idx-10]].Size=Size;
						 totQueueTCP[idx-10]++;
					 	}
				 	}		
		 	 	}
		 	}
	 	}
 	}
//	 	 	 printf("item:%d, ", totsplit);	// %s %s %\r\n", totsplit, (char*)&BuffParse.str[n]);
//	 	 	 for (i=0; i<totsplit; i++) printf("%s ", (char*)&BuffSplit.str[i]);
//			 printf("\r\n");
}

// COM0, MITSUBISHI, 0, 9600, EVEN, 7BIT, 1STOP
// COM1, MODBUS, 1, 9600, NONE, 8BIT, 1STOP
// TCP0, MODBUS, 127.0.0.1, 502


void InitPLCProtocol(void)
{
 unsigned char n, i;
 int ret;

 for (n=0; n<kMax_UARTChan; n++)
 	{
 	 WriteStat[n]=kFALSE;
	 IdxWR[n]=0;
 	 PLCParam[n].PLCType=kNoPLC;
	 PLCParam[n].Baudrate=k9600;
	 PLCParam[n].Parity=kNO;
	 PLCParam[n].DataSize=k8BITS;
	 PLCParam[n].StopSize=k1STOP;
 	 PLCParam[n].DevNum=0;
	 PLCParam[n].Queue=0;
	 PLCParam[n].speedcyc=0;
	 //PLCParam[n].Port=0;
	 //for (i=0; i<kMaxStrServer; i++) PLCParam[n].Server[i]=0;
	 for (i=0; i<kMaxDataParam; i++)
	 	{
	 	 PLCParam[n].DataParam[i].DataType=kNULL_DataType;
		 PLCParam[n].DataParam[i].Addr=0;
		 PLCParam[n].DataParam[i].Size=0;
		 PLCParam[n].DataParam[i].WriteStat=kFALSE;
	 	}
 	}

 for (n=0; n<kMax_TCPChan; n++)
 	{
 	 PLCParamTCP[n].PLCType=kNoPLC;
 	 PLCParamTCP[n].DevNum=0;
	 PLCParamTCP[n].Queue=0;
	 PLCParamTCP[n].Port=0;
	 PLCParamTCP[n].speedcyc=0;
	 for (i=0; i<kMaxStrServer; i++) PLCParamTCP[n].Server[i]=0;
	 for (i=0; i<kMaxDataParam; i++)
	 	{
	 	 PLCParamTCP[n].DataParam[i].DataType=kNULL_DataType;
		 PLCParamTCP[n].DataParam[i].Addr=0;
		 PLCParamTCP[n].DataParam[i].Size=0;
		 PLCParamTCP[n].DataParam[i].WriteStat=kFALSE;
	 	}
 	}

 OpenParam(); 
// exit(0);

 for (n=0; n<kMax_UARTChan; n++)
 	{
 	 scalerCom[n]=0;
	 if (PLCParam[n].PLCType==kOmron) InitOmronProtocol(n);
	 else if (PLCParam[n].PLCType==kMitsubishi) InitMitsubishiProtocol(n);
	 else if (PLCParam[n].PLCType==kLC_AND) InitAND(n);
	 else if (PLCParam[n].PLCType==kModbus) InitModbus(n);
	 else if (PLCParam[n].PLCType==kGPS) InitGPS(n);
	 StartReceiveUART(n); 
 	}
 
 for (n=0; n<kMax_TCPChan; n++)
 	{
	 if (PLCParamTCP[n].PLCType==kModbus) InitTCPModbus((char*)&PLCParamTCP[n].Server, PLCParamTCP[n].Port); 
 	}

 ret=pthread_create(&threadPLCProtocol,NULL,&HandlingTask,NULL);
 if(ret==0) printf("HandlingTask successfully.\r\n");
 else
	{
	 printf("HandlingTask not created.\n");
	 return; /*return from main*/
	} 
 
}


void PLCProtocolProcess(void)
{
 unsigned char n;
// static short idx=0;
 //int temp;
 
 if (PLCParam[0].PLCType==kNoPLC) return;
// if (scaler
 for (n=0; n<kMax_UARTChan; n++)
	{
	  if (UARTRdy[n]) ReadUART(n);
	}
 for (n=0; n<kMax_UARTChan; n++) CheckUART(n);


 for (n=0; n<kMax_UARTChan; n++)
 	{
	 if (PLCParam[n].PLCType!=kNoPLC)
	 	{
		 if (UARTRdy[n])
		 	{
			 if (PLCParam[n].PLCType==kOmron)
			 	{
				 if (scalerCom[n]) scalerCom[n]--;
				 else
				 	{
				 	 scalerCom[n]=PLCParam[n].speedcyc;
	 	 		 	 OmronProtocolProcess(n);
				 	}
			 	}
			 else if (PLCParam[n].PLCType==kMitsubishi)
			 	{
				 if (scalerCom[n]) scalerCom[n]--;
				 else
				 	{
				 	 scalerCom[n]=PLCParam[n].speedcyc;
	 	 		 	 MitsubishiProtocolProcess(n);
				 	}		 	 
			 	}
			 else if (PLCParam[n].PLCType==kLC_AND)
			 	{
				 if (scalerCom[n]) scalerCom[n]--;
				 else
				 	{
				 	 scalerCom[n]=PLCParam[n].speedcyc;
				 	 ANDProcess(n);
				 	}
			 	}
			 else if (PLCParam[n].PLCType==kModbus) 
			 	{
				 if (scalerCom[n]) 
				 	{
				 	 scalerCom[n]--;
//					 printf("Scaler Mddbus: %d %ld\r\n", scalerCom[n], GetTickCPU());
				 	}
				 else
				 	{			 	
				 	 scalerCom[n]=PLCParam[n].speedcyc;
//					 printf("Modbus Cycle: %d %ld\r\n", PLCParam[n].speedcyc, GetTickCPU());
//					 printf("Timeout: %d\r\n", TimeOutResp[n]);
				 	 ModbusProcess(n); 
				 	}
			 	}
			 else if (PLCParam[n].PLCType==kGPS) 
			 	{
				 if (scalerCom[n]) scalerCom[n]--;
				 else
				 	{
				 	 scalerCom[n]=PLCParam[n].speedcyc;
				 	 GPSProcess(n);
				 	}
			 	}
		 	}
	 	}
 	}
// usleep(PLCParam[n].speedcyc);
}


void *HandlingTask(void* args)
{
 unsigned char i=0;

 i=0;
 while (1) 
	{
	 if (((i)&&(UART_RESPONE[i-1]))||(i==0))
 	 	{
 	 	 if (PLCParam[i].PLCType>kNoPLC)
 	 	 	{
			 if (UARTRdy[i]==kFALSE)
			 	{
 	 	 		 InitUART(i, PLCParam[i].DevNum, kTblBaudRate[PLCParam[i].Baudrate], PLCParam[i].Parity, PLCParam[i].DataSize, PLCParam[i].StopSize);
			 	}
 	 	 	}
 	 	} 
	 i++;
	 if (i>=kMax_UARTChan) i=0;
	 usleep(100000);
	}
 exit(0);
}


