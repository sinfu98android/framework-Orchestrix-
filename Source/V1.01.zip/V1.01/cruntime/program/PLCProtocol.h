#ifndef PLCPROTOCOL_H
#define PLCPROTOCOL_H
#include "UART.h"
#include "MiscDataConv.h"

#define 	kTimeOutResp		100	//500		//250	//100			//250
#define 	kMaxDataParam		128
#define 	kMaxStrServer		64
#define 	kMax_TCPChan		3

#define 	kMaxBuffDEV	8192

#if 0
enum eStatePLC{
	kIdleState_PLC,
	kWritePLC,
	kReadPLC,
	kWriteBitMem,
	kReadBitMem,
	kWriteOutputY,
	kReadInputX,
	kEndStatePLC,
};
#endif

enum eCOMType{
	kNULL_COMType,
	kCOM,
	kTCP,
};

enum ePLCType{
	kNoPLC,
	kOmron,
	kMitsubishi,
	kLC_AND,
	kModbus,
	kGPS,
	kMaxPLCType
};

enum eBaudrate{
	kNO_BAUD,
	k2400,
	k4800,
	k9600,
	k19200,
	k38400,
	k57600,
	k115200,
};

enum eParityParam{
	kNO,
	kODD,
	kEVEN,
};

enum eBitdataSize{
	kNO_BITs,
	k7BITS,
	k8BITS,
};

enum eStopdataSize{
	kNO_STOP,
	k1STOP,
	k2STOP,
};


union uDataPLCType{
		unsigned char		DataByte[kMaxBuffDEV<<1];
		unsigned short	DataWord[kMaxBuffDEV];
		short			DataShort[kMaxBuffDEV];
		unsigned int		DataUInt[kMaxBuffDEV>>1];
		int				DataInt[kMaxBuffDEV>>1];		
		float				DataFloat[kMaxBuffDEV>>1];
		
//		unsigned char	DataWirless[kMaxPageBuff][kMaxPayLoad];
};


enum eDataType{
		kNULL_DataType,
		kBit_Data,
		kBit_M,
		kReg_Data,
		kReg_W,
		kReg_HoldingReg,
};

struct stDATAParam{
	enum eDataType		DataType;
	unsigned int		Addr;
	short				Size;
	unsigned char		WriteStat;
};

struct  stUARTPLC{
	enum ePLCType		PLCType;
	unsigned short		DevNum;
	enum eBaudrate		Baudrate;
	enum eParityParam	Parity;
	char 				Server[kMaxStrServer];
	int					Port;
	enum eBitdataSize	DataSize;
	enum eStopBit		StopSize;
	struct stDATAParam	DataParam[kMaxDataParam];
	short				Queue;	
	int					speedcyc;
};


struct  stTCPPLC{
	enum ePLCType		PLCType;
	unsigned short		DevNum;
	char 				Server[kMaxStrServer];
	int					Port;
	enum eBitdataSize	DataSize;
	enum eStopBit		StopSize;
	struct stDATAParam	DataParam[kMaxDataParam];
	short				Queue;
	int					speedcyc;
};


extern unsigned char		Respond[kMax_UARTChan];;
extern short				TimeOutResp[kMax_UARTChan];
//extern enum eStatePLC		StatePLC[kMax_UARTChan];
extern signed char 			DlyCOM[kMax_UARTChan];
extern unsigned char		DevNum[kMax_UARTChan];
extern unsigned short		ComAddr[kMax_UARTChan];
extern unsigned short		ComTot[kMax_UARTChan];
extern int					TickCOM[kMax_UARTChan], TickCOM_[kMax_UARTChan];
extern union uDataPLCType	DataPLC_RX[kMax_UARTChan];
extern union uDataPLCType	DataPLC_TX[kMax_UARTChan];
extern struct  stUARTPLC	PLCParam[kMax_UARTChan];
extern struct  stTCPPLC		PLCParamTCP[kMax_TCPChan];
extern unsigned char		WRStatusCOM[kMax_UARTChan][kMaxBuffDEV];
extern unsigned char		WriteStat[kMax_UARTChan];
extern int 					AddrCOM[kMax_UARTChan];
extern int					IdxWR[kMax_UARTChan];
extern int					CycleCOM;

void InitPLCProtocol(void);
void PLCProtocolProcess(void);
void *HandlingTask(void* args);

#endif
