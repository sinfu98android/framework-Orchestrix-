#include "ParalelLPT.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/io.h>
#include <fcntl.h>
#include <sys/types.h>
#include "IOProcess.h"


int tem;
unsigned char DATOUT, DATAIN;
unsigned int  IO_OUT, IO_IN;



void InitLPT(void)
{
 if (ioperm(BASEPORT, 3, 1)) {perror("ioperm"); exit(1);}
 tem = fcntl(0, F_GETFL, 0);
 fcntl (0, F_SETFL, (tem | O_NDELAY)); 
}


unsigned char SetPortDAT(unsigned char val)
{
 outb(val, BASEPORT);
 return(inb(STATUSPORT));
}


unsigned char GetPortStat(void)
{
 return(inb(STATUSPORT));
}


void CS_HI(void)
{
 DATOUT|=0x01;
 outb(DATOUT, BASEPORT);
}

void CS_LO(void)
{
 DATOUT&=~0x01;
 outb(DATOUT, BASEPORT); 
}

void SCK_HI(void)
{
 DATOUT|=0x02;
 outb(DATOUT, BASEPORT);
}

void SCK_LO(void)
{
 DATOUT&=~0x02;
 outb(DATOUT, BASEPORT); 
}

void DAT_HI(void)
{
 DATOUT|=0x04;
 outb(DATOUT, BASEPORT);
}

void DAT_LO(void)
{
 DATOUT&=~0x04;
 outb(DATOUT, BASEPORT); 
}


void InitIO_LPT(void)
{
 InitLPT();
 DATOUT=0xF8;
 sleep(1);
}

void UpdateLPTIO(void)
{
 unsigned char i;
 unsigned int temp;
 unsigned char getin;

 temp=IOdat.Output.OutByte[0];
 CS_LO();
 for (i=0; i<8; i++)
 	{
 	 if (temp & 0x80) DAT_HI();
	 else DAT_LO();
 	 SCK_HI();
	 SCK_LO();
	 temp=temp<<1;
 	}
 CS_HI();
 CS_HI();
 CS_LO();	 
 CS_LO();

 temp=0;
 for (i=0; i<8; i++)
 	{
	 temp=temp<<1;
	 getin=inb(STATUSPORT);
	 if (getin & 0x40) temp|=0x01;
  	 SCK_HI();
	 SCK_HI();
	 SCK_LO();
	 SCK_LO();
 	}
 IOdat.Input.InByte[0]=temp;	//getin;	//inb(STATUSPORT);	//temp;
}


void CloseLPT(void)
{
 fcntl(0, F_SETFL, tem);
 outb(0, BASEPORT);
 //take away permissions to access port
 if (ioperm(BASEPORT, 3, 0)) {perror("ioperm"); exit(1);}
}

