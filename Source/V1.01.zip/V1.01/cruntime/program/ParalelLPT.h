#ifndef PARALELLPT_H
#define PARALELLPT_H

#define BASEPORT 		0x378 /* lp1 */
#define STATUSPORT		BASEPORT+1
#define CONTROLPORT		BASEPORT+2

extern unsigned int  IO_OUT, IO_IN;

void InitIO_LPT(void);
unsigned char SetPortDAT(unsigned char val);
void CloseLPT(void);
void UpdateLPTIO(void);


#endif
