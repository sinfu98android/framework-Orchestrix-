#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Project.h"
#include "System.h"
#include "Modbus.h"
#include "MiscDataConv.h"

#define kDensityPasir		2620
#define kDensityTensla	2550
#define kDensityCement	3150
#define kDensityWater	1000


#define kWidthLength		78
//#define kWidthMisc			25
//#define kWidthName			50

const char kstrFrame[]={"************************************************************************"};
const char kstrCompany[]={"PT. BETON KOKOH JAYA SENTOSA"};
const char kstrAddress[]={"JL. RING ROAD SELATAN KM 12345678"};
const char kstrCity[]={"JOGJAKARTA"};
const char kstrName[]={"Mukidi"};
const char kstrNoPol[]={"L1845TW"};
const char kstrCustomer[]={"PT.JASA MARGA"};



char 	Frame[kWidthLength];
char	Company[kWidthLength];
char	Address[kWidthLength];
char	City[kWidthLength];
char	Name[kWidthLength];
char	NoPol[kWidthLength];
char	Customer[kWidthLength];
char NoPO[kWidthLength];
char Mutu[kWidthLength];
float	Volume;
char	*pChar;
unsigned char TypeMortar;
unsigned char PrintingCmd;


void CentreAllignString(char* String, unsigned char MaxLength)
{
 char				CharAllign[512];	
 unsigned char 		lengthStr;
 short 				n, i;
 char 				*pStr;

 memset(CharAllign,0,sizeof(CharAllign));			// Fill zero 
 lengthStr=strlen(String);
 n=MaxLength-lengthStr;
 n=n>>1;
 memset(CharAllign,' ', n);			// Fill space
 pStr=String;
 for (i=0; i<lengthStr; i++)
	{
	 CharAllign[n+i]=*pStr++;
	}
 pStr=(char*)CharAllign;
 memcpy(String,pStr,MaxLength);
}

#if 0
void LoadString(char * StringSrc, char * StringDest)
{
 unsigned char lengthStrSrc;
 
 memset(StringDest,0,kWidthLength);
 lengthStrSrc=strlen(StringSrc);
 if (lengthStrSrc>=kWidthLength) lengthStrSrc=kWidthLength;
 memcpy(StringDest, StringSrc, lengthStrSrc);
}
#endif

void FitString(char*pStr, char MaxLength)
{
 unsigned char lengthStrSrc;

 lengthStrSrc=strlen(pStr);
 pStr+=lengthStrSrc;
 if (lengthStrSrc<=MaxLength) memset(pStr, ' ', MaxLength-lengthStrSrc);
}


#if 0
void LoadAtribute(void)
{
 unsigned char n;
 float tempFloat;
 float AccVolume;
 

 for (n=0; n<25; n++)
	{
	  if (VarModbus.VarBatchingPlant.strName.Char8[n]<' ') 
	 	{
	 	 Name[n]=0;
		 break;
	 	}
	 else Name[n]=VarModbus.VarBatchingPlant.strName.Char8[n];
	}

 for (n=0; n<25; n++)
	{
	 if (VarModbus.VarBatchingPlant.strCompanyName.Char8[n]<' ') 
	 	{
	 	 Customer[n]=0;
		 break;
	 	}
	 else Customer[n]=VarModbus.VarBatchingPlant.strCompanyName.Char8[n];
	}

 for (n=0; n<25; n++)
	{
	 if (VarModbus.VarBatchingPlant.strNoPol.Char8[n]<' ') 
	 	{
	 	 NoPol[n]=0;
		 break;
	 	}
	 else NoPol[n]=VarModbus.VarBatchingPlant.strNoPol.Char8[n];
	}

 for (n=0; n<25; n++)
	{
	 if (VarModbus.VarBatchingPlant.strNoPO.Char8[n]<' ') 
	 	{
	 	 NoPO[n]=0;
		 break;
	 	}
	 else NoPO[n]=VarModbus.VarBatchingPlant.strNoPO.Char8[n];
	}

  for (n=0; n<25; n++)
	{
	 if (VarModbus.VarBatchingPlant.strAddress.Char8[n]<' ') 
	 	{
	 	 Address[n]=0;
		 break;
	 	}
	 else Address[n]=VarModbus.VarBatchingPlant.strAddress.Char8[n];
	}
  tempFloat=VarModbus.VarBatchingPlant.TotalAgregat[0]+VarModbus.VarBatchingPlant.TotalAgregat[1];
  tempFloat/=kDensityPasir;
  AccVolume=tempFloat;
  tempFloat=VarModbus.VarBatchingPlant.TotalAgregat[2]+VarModbus.VarBatchingPlant.TotalAgregat[3];
  tempFloat/=kDensityTensla;
  AccVolume+=tempFloat;
  tempFloat=VarModbus.VarBatchingPlant.TotalCement[0]+VarModbus.VarBatchingPlant.TotalCement[1];
  tempFloat/=kDensityCement;
  AccVolume+=tempFloat;
  tempFloat=VarModbus.VarBatchingPlant.TotalWater;
  tempFloat/=kDensityWater;
  AccVolume+=tempFloat;
  Volume=AccVolume;
}
#endif

void *Printer(void* args)
{
 
 while(1)
	{
	 if (PrintingCmd)
		{	
// 		 LoadAtribute();
			FILE *fp = fopen( "/dev/lp0", "w" );
			if ( fp == NULL ) 
					{
					 perror( "Unable to open printer\r\n" );
					}
			else 
					{
//					 Volume=1.2345;
//					 TypeMortar=10;
//					 if (TypeMortar>=kSizeofkMortarType) TypeMortar=kSizeofkMortarType-1;
				 
//					 LoadString((char*)kMortarType[VarModbus.VarProject.OrderType], (char*)Mutu);
//					 FitString((char*) Mutu, 5);
					 
//					 FitString((char*) Customer, 36);
//					 FitString((char*) Address, 36);

		//			 system("setterm -bold on");
					 printf("printing ...\r\n"); 
					 fprintf(fp,"\r\n");
 					 fprintf(fp,"\r\n"); 
					 fprintf(fp,"\r\n");
 					 fprintf(fp,"\r\n");					 
 					 fprintf(fp,"\r\n");					 					 
 					 fprintf(fp,"\r\n");					 
 					 fprintf(fp,"\r\n");					 
	//				 fprintf(fp,"                %s     %02d/%02d/%d \r\n", Customer, tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
	//				 fprintf(fp,"                %s     %s\r\n", Address, NoPO);
	//				 fprintf(fp,"                %s\r\n", NoPol);
	//				 fprintf(fp,"                %02d:%02d\r\n", tm.tm_hour, tm.tm_min);
					 fprintf(fp,"\r\n");					 
 					 fprintf(fp,"\r\n");					 
  					 fprintf(fp,"\r\n");
	//				 fprintf(fp,"  %s   10    %.2f\r\n", Mutu,Volume);
					 fprintf(fp,"\r\n\f");
		//			 system("setterm -bold off");
					 fclose( fp );			 
					}
		 PrintingCmd=kFALSE;
		}
	 sleep(1);
	}
 return 0;	
}
