#ifndef PRINTER_H
#define PRINTER_H


extern unsigned char PrintingCmd;

void *Printer(void* args);
#endif