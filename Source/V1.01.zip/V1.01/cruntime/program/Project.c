#include "Project.h"
#include "System.h"
#include "Modbus.h"
#include "stdint.h"
#include "stdio.h"
#include "ModbusTCP.h"
#include "IOProcess.h"
#include "Printer.h"
#include "CheckMACAddr.h"
#include <sys/ioctl.h>
#include <unistd.h>
#include <linux/kd.h>
#include "MySQLClient.h"
//#include "rfid.h"
#include "ADS1256.h"
#include "PLC.h"
#include "TCPClient.h"



const unsigned int kTblAnimation[]={0x0001, 0x0002, 0x0004, 0x0008, 0x0010, 0x0020, 0x0040, 0x0080, 0x0100, 0x0200, 0x0400, 0x0800, 0x1000,
								 0x2000, 0x1000, 0x0800, 0x0400, 0x0200, 0x0100, 0x0080, 0x0040, 0x0020, 0x0010, 0x0008, 0x0004, 0x0002};
#define ksizeofkTblAnimation		sizeof(kTblAnimation)/sizeof(unsigned int)

uint16_t			SecurityTimeout;
unsigned char 		anim;
unsigned char 		TickUpdateMySQL;
int					VarTesting=100, VarTesting2;
float				VarFloat;
char				VarString[kMaxString];


void InitProjectProcess(void)
{
 printf("Load Parameter ....\r\n");
 LOAD_DATA();
 printf("Start Up Data: %x\r\n", VarModbus.VarProject.FirstInit );
 if (VarModbus.VarProject.FirstInit != (uint16_t)kFirstInit)
		{
		  VarModbus.VarProject.FirstInit =(uint16_t)kFirstInit;
		  STORE_DATA();
		  printf("Store Data: %x\r\n", VarModbus.VarProject.FirstInit );
		  printf("FirstInit !!!!\r\n");
		} 
 VarModbus.VarProject.SaveParameter=kFALSE;
 TickUpdateMySQL=0;
 #ifdef PLC
	 InitPLC();
 #endif
 VarFloat=1.234;
}


void VarHMI(void)
{
 unsigned char i;

 if (FlagsSystem.Tick100mS) VarModbus.VarProject.CPUTick++;
 if (FlagsSystem.Tick1S)
		{
		 VarModbus.VarProject.CPUCycle=CPUCycle;
		 VarModbus.VarProject.TCPCycle=TickTCP;
		 VarModbus.VarProject.TickCache=TickCache;
		 VarModbus.VarProject.TickTCPModbus=TickTCPModbus;
		 VarModbus.VarProject.COMTick=COMTick;	 		// Modbus

	 	 for (i=0; i<kDBG_MAX_ITEM; i++)
	 	 	{
			 VarModbus.VarProject.DBG[0+i]=DBG[0][i];
			 VarModbus.VarProject.DBG[10+i]=DBG[1][i];
	 	 	}
//		 printf("Water:%d  CPU Cycle: %d    TCP Cycle: %d    Omron COM: %d    Modbus COM: %d   Security:%d\r\n", VarModbus.VarBatchingPlant.WaterState, CPUCycle,  TickTCP, TickCOM,  COMTick, VarModbus.VarBatchingPlant.Security);
		} 

 if (VarModbus.VarProject.SaveParameter)
		{
		  VarModbus.VarProject.SaveParameter=kFALSE;
		  STORE_DATA();
		}
 if ((VarModbus.VarProject.MACAddr.MACAddr8[0]==mac_address[0])&&
	 (VarModbus.VarProject.MACAddr.MACAddr8[1]==mac_address[1])&&
	 (VarModbus.VarProject.MACAddr.MACAddr8[2]==mac_address[2])&&
	 (VarModbus.VarProject.MACAddr.MACAddr8[3]==mac_address[3])&&
	 (VarModbus.VarProject.MACAddr.MACAddr8[4]==mac_address[4])&&
	 (VarModbus.VarProject.MACAddr.MACAddr8[5]==mac_address[5]))
		{
	     	 VarModbus.VarProject.Security=0;
		}
 else
	{
	 if (FlagsSystem.Tick1S)
		{
		 if (VarModbus.VarProject.Security<5) VarModbus.VarProject.Security++;
		 //printf("Var Testing: %d  %.3f  Cache Tick:%d\r\n", VarTesting, VarFloat, TickCache);
		} 
	}
 VarTesting++;
}


void ProjectProcess(void)
{
 VarHMI();
 //IOdatProc.Output.Bit.Bit0=FlagsSystem.Cycle500mS;
// IOdatProc.Output.OutputDat[0]=0xFF;
if (FlagsSystem.Tick1S)	
	{
	}
}

