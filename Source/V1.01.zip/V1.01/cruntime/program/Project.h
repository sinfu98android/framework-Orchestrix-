#ifndef BATCHINGPLANT_H
#define	BATCHINGPLANT_H
#include "Flash.h"
//#include "HX711.h"
#include <stdint.h>
#include <time.h>
#include "IOProcess.h"
#include "TCPModbus.h"
#include "webstring.h"

//#define PLC


#define	kFirstInit		0xA5A9
#define kSamplingIOT			50			// 5 Second
#define kStringLongLength	32
#define kStringShortLength	16
#define kMaxCycDev			8
#define kMaxBufferSensor		10
#define kTotalAnalogRead	8


union uByteWord32Bit{
		uint8_t	dat8[4];
		uint16_t	dat16[2];
		uint32_t	dat32;
};

union uIOHybrid{
	struct stIOBit	Bit;
	uint16_t		Word[16];				// Maximum 256 I/O
	uint32_t		DWord[8];
};

union uStringLong{
	uint8_t			Char8[kStringLongLength<<1];
	uint16_t		Char16[kStringLongLength];
};

union uStringShort{
	uint8_t			Char8[kStringShortLength<<1];
	uint16_t		Char16[kStringShortLength];
};

union uMACAddr{
	uint8_t			MACAddr8[8];
	uint16_t		MACAddr16[4];
};

struct stCycLogging{
	unsigned int	FwdTime;
	unsigned int	RevTime;
	unsigned int	Cycle;	
};

struct stProjectProcess{
		uint32_t				CPUCycle;							// 40001
		uint32_t				CPUTick;							// 40003
		uint16_t				TCPCycle;							// 40005
		uint16_t				TickTCPModbus;						// 40006
		uint16_t				TickCache;							// 40007
		uint16_t				COMTick;							// 40008
		uint16_t				FirstInit;							// 40009
		uint16_t				SaveParameter;						// 40010
		uint16_t				Security;							// 40011
		uint16_t				Reserved0;							// 40012
		uint32_t				DBG[30];							// 40013
		union uMACAddr			MACAddr;							// 40613-16
		union uIOHybrid			Input;								// 40017-32
		union uIOHybrid			Output;								// 40033-48

};

extern struct tm 				tm;
extern float					AnalogLogging[kTotalAnalogRead];
extern float					AnalogLogging_[kTotalAnalogRead];
extern float					AnalogLoggingMin_[kTotalAnalogRead];
extern float					AnalogLoggingMin[kTotalAnalogRead];
extern float					AnalogLoggingMax_[kTotalAnalogRead];
extern float					AnalogLoggingMax[kTotalAnalogRead];
extern float					AnalogCallibration[kTotalAnalogRead];
extern struct stCycLogging		CycLogging[8];
extern union uByteWord32Bit	BufferSensor[kMaxBufferSensor];
extern unsigned char			privilige;
extern unsigned char			door;
extern int						VarTesting, VarTesting2;
extern char						VarString[kMaxString];
extern float					VarFloat;
	
void InitProjectProcess(void);
void ProjectProcess(void);
void PWMProc(void);

#endif
