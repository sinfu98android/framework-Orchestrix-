#include "System.h"
#include "Modbus.h"
#include "ModbusTCP.h"
#include <time.h>
#include <stdio.h>



struct stFlagsSystem 	FlagsSystem;
unsigned short			Scaler1mS;
unsigned short			Scaler10mS;
unsigned short			Scaler100mS;
unsigned short			Scaler200mS;
unsigned short			Scaler500mS;
unsigned short			Scaler1S;
unsigned char			TickSystem;
unsigned int			CPUCycle_, CPUCycle;
unsigned int			CPUTick=0;
unsigned int			RebootCount=0;
unsigned int			Scaler50uS, Scaler50uS_;
unsigned char			QuitSystem;
time_t 					t;
struct 					tm tm;
int						DebugVar;
unsigned char			PowerUp;
int						TickCache, TickCache_;
float					CPUTemp;
int						TickTCPModbus,TickTCPModbus_;


void InitSystem(void)
{
 Scaler10mS=kScaler10mS;
 Scaler100mS=kScaler100mS;
 Scaler200mS=kScaler200mS;
 Scaler500mS=kScaler500mS;
 Scaler1S=kScaler1S;
 QuitSystem=kFALSE;
 FlagsSystem.PowerUP=kFALSE;
 PowerUp=20;
}


void GetDateTime(void)
{
 t = time(NULL);
 tm = *localtime(&t); 	
}



long GetTickCPU(void)
{
 long temp;

 struct timespec t1;
 clock_gettime(CLOCK_MONOTONIC, &t1);
 temp=t1.tv_sec*1000+t1.tv_nsec/1000000;
 return(temp);
}

void SystemProcess(void)
{
 unsigned char n;
 struct timespec t1;
 long temp;
 static long temp1;

 FlagsSystem.TickPeriperal=kFALSE;
 FlagsSystem.Tick1mS=kFALSE;
 FlagsSystem.Tick10mS=kFALSE;
 FlagsSystem.Tick100mS=kFALSE;
 FlagsSystem.Tick200mS=kFALSE;
 FlagsSystem.Tick500mS=kFALSE;
 FlagsSystem.Tick1S=kFALSE;

 clock_gettime(CLOCK_MONOTONIC, &t1);

 temp=GetTickCPU();
 if ((temp-temp1)>=1)
 	{	
	 TickSystem=kTRUE;
 	 temp1=temp;	 
 	}
 
 if (TickSystem)
 	{
 	 TickSystem=kFALSE;
 	 FlagsSystem.Tick1mS=kTRUE;
 	 FlagsSystem.Cycle1mS=~FlagsSystem.Cycle1mS;
	 Scaler10mS--;
	 if (Scaler10mS==0)
			{
			 Scaler10mS=kScaler10mS;
			 FlagsSystem.Tick10mS=kTRUE;
			 FlagsSystem.Cycle10mS=~FlagsSystem.Cycle10mS;
			 Scaler100mS--;
			 if (Scaler100mS==0)
					{
					 Scaler100mS=kScaler100mS;
					 FlagsSystem.Tick100mS=kTRUE;
					 FlagsSystem.Cycle100mS=~FlagsSystem.Cycle100mS;
					 Scaler200mS--;
					 if (Scaler200mS==0)
							{
							 Scaler200mS=kScaler200mS;
							 FlagsSystem.Tick200mS=kTRUE;
							 FlagsSystem.Cycle200mS=~FlagsSystem.Cycle200mS;
							} 
					 Scaler500mS--;
					 Scaler1S--;
					 if (Scaler500mS==0)
							{
							 Scaler500mS=kScaler500mS;
							 FlagsSystem.Tick500mS=kTRUE;
							 FlagsSystem.Cycle500mS=~FlagsSystem.Cycle500mS;
							}
					 if (Scaler1S==0)
							{
							 Scaler1S=kScaler1S;
							 FlagsSystem.Tick1S=kTRUE;
							 FlagsSystem.Cycle1S=~FlagsSystem.Cycle1S;
							 CPUTick++;
							}
					}
	 		}
 	}
	
 CPUCycle_++;
 if (FlagsSystem.Tick1S)
 	{
 	 CPUCycle=CPUCycle_;
 	 CPUCycle_=0;
 	 Scaler50uS=CPUCycle/100000;
 	 COMTick=COMTick_;
 	 COMTick_=0;
	 for (n=0; n<kMax_UARTChan; n++)
	 	{
		 TickCOM[n]=TickCOM_[n];
		 TickCOM_[n]=0;
	 	}
	 TickTCP=TickTCP_;
	 TickTCP_=0;
	 TickCache=TickCache_;
	 TickCache_=0;
	 TickTCPModbus=TickTCPModbus_;
	 TickTCPModbus_=0;
 	}
 Scaler50uS_++;
 if (Scaler50uS_>= Scaler50uS)
 	{
 	 Scaler50uS_=0;
 	 FlagsSystem.TickPeriperal=kTRUE;
 	 FlagsSystem.CyclePeriperal=~FlagsSystem.CyclePeriperal;
 	}
 
 if (FlagsSystem.Tick500mS)
 	 {
 	  GetDateTime();
 	}
 
 if (FlagsSystem.PowerUP==kFALSE)
 	{
	 if (FlagsSystem.Tick100mS)
	 	{
	 	 if (PowerUp) PowerUp--;
		 else
		 	{
		 	 FlagsSystem.PowerUP=kTRUE;
		 	}
	 	}
 	}
}

