#ifndef SYSTEM_H
#define SYSTEM_H
#include <stdio.h>
#include <stdlib.h>
#include "PLCProtocol.h"
#include <time.h>

#define kFALSE	0
#define kTRUE	1

#define kScaler10mS			10
#define kScaler100mS		10
#define kScaler200mS		2
#define kScaler1S			10
#define kScaler500mS		5


struct stFlagsSystem{
	unsigned int	TickPeriperal	:1;
	unsigned int	Tick1mS			:1;
	unsigned int	Tick10mS		:1;
	unsigned int	Tick100mS		:1;
	unsigned int	Tick200mS		:1;
	unsigned int	Tick500mS		:1;
	unsigned int	Tick1S			:1;
	unsigned int	CyclePeriperal	:1;	
	unsigned int	Cycle1mS		:1;
	unsigned int	Cycle10mS		:1;
	unsigned int	Cycle100mS		:1;
	unsigned int	Cycle200mS		:1;
	unsigned int	Cycle1S			:1;
	unsigned int	Cycle500mS		:1;
	unsigned int	UpdatePeriperal	:1;
	unsigned int	PowerUP			:1;
};


union uGlobal32bitDataFormat{
	int				Int32;
	unsigned int	UInt32;
	unsigned char	UInt8[4];
};



extern unsigned char			TickSystem;
extern struct stFlagsSystem 	FlagsSystem;
extern unsigned int				CPUCycle;
extern unsigned char			QuitSystem;
extern struct 	tm				tm;
extern int						DebugVar;
extern unsigned int				CPUTick;
extern int						TickCache, TickCache_;
extern float					CPUTemp;
extern int						TickTCPModbus,TickTCPModbus_;
extern unsigned int				RebootCount;

long GetTickCPU(void);
void InitSystem(void);
void SystemProcess(void);
#endif
