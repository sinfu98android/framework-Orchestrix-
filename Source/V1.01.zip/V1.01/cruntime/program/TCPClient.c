#include "TCPClient.h"
#include <pthread.h>
#include "MiscDataConv.h"
#include "WEBClient.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include "TCPModbus.h"

//#define 	DEBUG_TCP_CLIENT
//const char *kStrWEB = "POST /test.php HTTP/1.1\r\nHost: iot-server-izimura.000webhostapp.com\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 16\r\n\r\nclient=dispen001\r\n\r\n";

#define DEBUGVAR
struct protoent *protoent;

//int				ClientIdx;
//int 				TickTest;
//struct timeval	TimeOut;
//unsigned int		ClientTimeOut[10];
//int 				Counting;
//int				ptrRXTCP;

//#define PORT    80
//#define MAXMSG  8192


//char 				*hostname = "iot-server-izimura.000webhostapp.com";
//char					buff[32768*10];
//int					timeoutRecv;
//int					timeoutRepeat;
struct stTCPClient		TblTCPCLient[kMaxTCPClient];
int						IdxTCPClient=0;
int						DBG[kMaxTCPClient][kDBG_MAX_ITEM];
//enum eErrorMsg		ErrorMsg;
pthread_mutex_t 		tcpclientlock;


void *ClientProcess(void* args);



void InitTCPClient(int (*FuncProcessTX)(int),
				     void (*FuncProcessRX)(int, int),
				     char * hostname,
				     int	Port,
				     enum eTypeTCPClient Type,
				     int	IdxVar,				     
				     int TimeoutRecv,
				     int TimeoutRepeat,
				     unsigned char	*pBuffTX,
				     unsigned char   *pBuffRX,
				     int	MaxBuff)
{
 int 			ret;
 pthread_t 	id;
// int n;

 printf("Init TCP Client !!!!  %s   %d\r\n", (char*)hostname, Port);
 pthread_mutex_lock(&tcpclientlock);
 TblTCPCLient[IdxTCPClient].FuncProcessTX=(void*)FuncProcessTX;
 TblTCPCLient[IdxTCPClient].FuncProcessRX=(void*)FuncProcessRX;
 TblTCPCLient[IdxTCPClient].Hostname=hostname;
 TblTCPCLient[IdxTCPClient].Port=Port;
 TblTCPCLient[IdxTCPClient].IdxClient=IdxTCPClient;
 TblTCPCLient[IdxTCPClient].Type=Type;
 TblTCPCLient[IdxTCPClient].TimeoutRecv=TimeoutRecv;
 TblTCPCLient[IdxTCPClient].TimeoutRepeat=TimeoutRepeat;
 TblTCPCLient[IdxTCPClient].pBuffTX=pBuffTX;
 TblTCPCLient[IdxTCPClient].pBuffRX=pBuffRX;
 TblTCPCLient[IdxTCPClient].MaxBuff=MaxBuff;
 TblTCPCLient[IdxTCPClient].cyc=0;
 TblTCPCLient[IdxTCPClient].IdxVar=IdxVar;

 ret=pthread_create(&id,NULL,&ClientProcess,NULL);
 TblTCPCLient[IdxTCPClient].TCP_Id=id; 
 if(ret==0) printf("TCP Client  created successfully...  %lu !!!!\r\n", id);
 else
 	{
     printf("USER Thread not created.\n");
     return; /*return from main*/
    }
 if (IdxTCPClient>=kMaxTCPClient) return;						// Over TCP Client
 
// (*TblTCPCLient[IdxTCPClient].FuncProcessRX)(pBuffRX);
// for (n=0; n<kMaxTCPClient; n++) DBG[n]
 memset(DBG,0, sizeof(DBG));
 IdxTCPClient++;
 pthread_mutex_unlock(&tcpclientlock);
}



int hostname_to_ip(char * hostname , char* ip)
{
struct hostent *he;
struct in_addr **addr_list;
int i;
		
if ( (he = gethostbyname( hostname ) ) == NULL) 
	{
		//gethostbyname failed
		herror("gethostbyname");
		return 1;
	}
	
	//Cast the h_addr_list to in_addr , since h_addr_list also has the ip address in long format only
addr_list = (struct in_addr **) he->h_addr_list;
	
for(i = 0; addr_list[i] != NULL; i++) 
	{
		//Return the first one;
		strcpy(ip , inet_ntoa(*addr_list[i]) );
	}
return 0;
}



void CloseSocket(int fd)
{
 shutdown(fd, SHUT_RDWR);
 close(fd);
}


void *ClientProcess(void* args)
{
const struct addrinfo hints = {        .ai_family = AF_INET,        .ai_socktype = SOCK_STREAM,    };
int 				sockfd;
struct pollfd 		fd;
int 				ret;
struct sockaddr_in  their_addr;
int 				temp, n;
pthread_t 		    self;
unsigned char 		ServerStatus;
int					ID, IDVar;
char 				intstr[10];
struct addrinfo 	*res;



ServerStatus=kFALSE;

//while(1)
//	{
	 pthread_mutex_lock(&tcpclientlock); 
	 self = pthread_self();
	 for (n=0; n<IdxTCPClient; n++)
		{
		 if (TblTCPCLient[n].TCP_Id==self )
		 	{
			 ID=n;
		 	 break;
		 	}
		}
	 pthread_mutex_unlock(&tcpclientlock);
//	 usleep(100);
//	 if (ID<32) break;
//	}
printf(">>>> Type: %d  , TCP Client Thread :  %lu   ID:%d!!!!\r\n", TblTCPCLient[ID].Type , self, ID);

while(1)
	{
	sleep(1);
	printf("Starting TCP ...\r\n");
	IDVar=TblTCPCLient[ID].IdxVar;
	DBG[ID][kDBG_ITEM0]++;								// DEBGUG ITEM 0
	if (DBG[ID][kDBG_ITEM0]>=100) exit(0);			// 
	while(1)
		{
		  DBG[ID][kDBG_ITEM1]++;								// DEBGUG ITEM 1
		  while(1)
		 	{
		 	 memset(intstr, 0, sizeof(intstr));
			 printf("Get Hostname ....\r\n");
		 	 DBG[ID][kDBG_ITEM2]++;								// DEBGUG ITEM 2
			 my_itoa(TblTCPCLient[ID].Port, intstr);
			 int err = getaddrinfo(TblTCPCLient[ID].Hostname, (char*)&intstr, &hints, &res);
			 if(err != 0 || res == NULL)
			 	{
			 	 printf("Error Get Hostname!!!!\r\n");
				 sleep(1);
			 	}
			  else
				 	{
	//			 	 struct in_addr *addr;
	//				 addr = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
	//				 printf("IP: %s\r\n", inet_ntoa(*addr));
					 usleep(100000);
					 break;
				 	}	
		 	}

		  sockfd = socket(res->ai_family, res->ai_socktype, 0);
		  if (sockfd < 0) 
			{
			 printf("Unable to create socket: errno %d\r\n", errno);
			 DBG[ID][kDBG_ITEM3]++;								// DEBGUG ITEM 3
			 ServerStatus=kFALSE;
			 sleep(2);
		 	 break;
			}
		
		  memset(&(their_addr.sin_zero), '\0', 8);
		  int err = connect(sockfd, res->ai_addr, res->ai_addrlen);
		  if (err != 0)
			 {
			  ServerStatus=kFALSE;
			  printf("Cannot Connect !!!\r\n");
			  CloseSocket(sockfd);
			  DBG[ID][kDBG_ITEM4]++;								// DEBGUG ITEM 4
			  break;
			 }
		  else ServerStatus=kTRUE;

		  if (TblTCPCLient[ID].Type==kWEBMemcacheType)
			 {
			  printf("Start WEB Memcache !!! Cycle: %d\r\n", TblTCPCLient[ID].cyc);
			 }
		  TblTCPCLient[ID].cyc=0;
		  while(ServerStatus)
			 	{
				 temp=(*TblTCPCLient[ID].FuncProcessTX)(ID, IDVar);
				 if (temp)
				 	{
				 	 #ifdef DEBUG_TCP_CLIENT
					 	 unsigned short j;
						 printf("Sending: %d bytes  ", temp);
						 for (j=0; j<temp; j++) printf("%d, ", TblTCPCLient[ID].pBuffTX[j]);
						 printf("\r\n");		
					 #endif
					 SendTCP(sockfd, TblTCPCLient[ID].pBuffTX, temp);
					 fd.fd = sockfd; 						// your socket handler 
					 fd.events = POLLIN;
					 ret = poll(&fd, 1, TblTCPCLient[ID].TimeoutRecv); // 1 second for timeout
#if 0
					 if (ret==-1)
						{
						 close(sockfd);
						 #ifdef DEBUG_TCP_CLIENT
						 	printf("Server Error\n");
						 #endif
						 ServerStatus=kFALSE;
						}
					 else if (ret==0)
						{
						 // Timeout 
						 close(sockfd);
						 #ifdef DEBUG_TCP_CLIENT
						 	printf("Server Error !!!\n");
						 #endif
						 ServerStatus=kFALSE;
						}
#endif					 
					 if (ret<=0)
						{
						 CloseSocket(sockfd);	// close(sockfd);
						 #ifdef DEBUG_TCP_CLIENT
						 	printf("Server Error\n");
						 #endif
						 DBG[ID][kDBG_ITEM5]++;								// DEBGUG ITEM 5
						 ServerStatus=kFALSE;
						}
					 else
						{
						 if (TblTCPCLient[ID].Type==kWEBMemcacheType)
						 	{
							 memset(TblTCPCLient[ID].pBuffRX,0, kMaxBuffWEB);
						 	}
						 else if (TblTCPCLient[ID].Type==kTCPModbusType)
						 	{
						 	 memset(TblTCPCLient[ID].pBuffRX,0, kMaxBuffTCPModbus);
						 	}
						 temp=recv(sockfd, TblTCPCLient[ID].pBuffRX, TblTCPCLient[ID].MaxBuff, 0); // get your data
						 if (temp>0) 
						 	{
							 #ifdef DEBUG_TCP_CLIENT				 	
						 	 if (TblTCPCLient[ID].Type==kTCPModbusType)
						 	 	{
						 	 	 unsigned short j;
								 printf("Received: %d bytes  ", temp);
								 for (j=0; j<temp; j++) printf("%d, ", TblTCPCLient[ID].pBuffRX[j]);
								 printf("\r\n");				 	 	
						 	 	}
							 #endif
						 	 (*TblTCPCLient[ID].FuncProcessRX)(TblTCPCLient[ID].IdxClient, IDVar, temp);
							 if (TblTCPCLient[ID].Type==kWEBMemcacheType)
							 	{
								 usleep(TblTCPCLient[ID].TimeoutRepeat);
								 TblTCPCLient[ID].cyc++;
							 	}
							 else if (TblTCPCLient[ID].Type==kTCPModbusType)
							 	{
							 	 usleep(TblTCPCLient[ID].TimeoutRepeat);
								 TblTCPCLient[ID].cyc++;
							 	}
						 	}
						 else
						 	{
							 ServerStatus=kFALSE;
							 printf("Server Error !!!   ID:%d\r\n", ID);
						 	 CloseSocket(sockfd);		// close(sockfd);
							 shutdown(sockfd, SHUT_RDWR);
							 #ifdef DEBUG_TCP_CLIENT
							 	printf("Server Error !!!\r\n");
							 #endif
							 DBG[ID][kDBG_ITEM6]++;								// DEBGUG ITEM 6
						 	}
						}
				 	}
				 //usleep(TblTCPCLient[ID].TimeoutRepeat);
				 DBG[ID][kDBG_ITEM7]++;								// DEBGUG ITEM 7
			 	}
		 	 usleep(100);
			}
	}
return(0);
}



void SendTCP(int sd, unsigned char *pBuff, unsigned int size)
{
 send(sd , pBuff , size, 0 );
}



