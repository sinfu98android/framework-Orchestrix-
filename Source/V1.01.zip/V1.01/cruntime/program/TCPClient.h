#ifndef TCPCLIENT_H
#define TCPCLIENT_H
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <time.h>
#include "System.h"
#include<netdb.h>	//hostent
#include <sys/poll.h>


#define kMaxTCPClient	16

enum eTypeTCPClient{
	kNoTypeTCP,
	kWEBMemcacheType,
	kWEBParserType,
	kTCPModbusType,
};


enum eDBGItem{
	kDBG_ITEM0,
	kDBG_ITEM1,	
	kDBG_ITEM2,
	kDBG_ITEM3,
	kDBG_ITEM4,
	kDBG_ITEM5,
	kDBG_ITEM6,
	kDBG_ITEM7,
	kDBG_ITEM8,
	kDBG_ITEM9,
	kDBG_MAX_ITEM
};

struct stTCPClient{
	pthread_t				TCP_Id;
	int					(*FuncProcessTX)(int, int);
	void					(*FuncProcessRX)(int, int, int);
	char					*Hostname;
	int					Port;
	int					IdxClient;
	int					IdxVar;
	enum eTypeTCPClient	Type;
	unsigned char			*pBuffTX;
	unsigned char			*pBuffRX;
	int					TimeoutRecv;
	int					TimeoutRepeat;
	int					MaxBuff;
	unsigned short		cyc;
};

extern struct stTCPClient		TblTCPCLient[kMaxTCPClient];
extern int						DBG[kMaxTCPClient][kDBG_MAX_ITEM];

void InitTCPClient(int (*FuncProcessTX)(int),
				     void (*FuncProcessRX)(int, int),
				     char * hostname,
				     int	Port,
				     enum eTypeTCPClient Type,
				     int	IdxVar,				     
				     int TimeoutRecv,
				     int TimeoutRepeat,
				     unsigned char	*pBuffTX,
				     unsigned char   *pBuffRX,
				     int	MaxBuff);
void SendTCP(int sd, unsigned char *pBuff, unsigned int size);
#endif
