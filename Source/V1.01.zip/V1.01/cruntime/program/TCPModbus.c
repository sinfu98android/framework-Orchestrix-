#include "TCPModbus.h"
#include "TCPClient.h"
#include "MiscDataConv.h"
#include "System.h"
#include "PLCProtocol.h"


//char 	*ServerModbus = "127.0.0.1";
char				pBuffTXModbus[kMaxTCPDevice][kMaxBuffTCPModbus];
char				pBuffRXModbus[kMaxTCPDevice][kMaxBuffTCPModbus];
short				Count;
union uDataPLCType 	BuffTCPModbus[kMaxTCPDevice];	//[kMaxMemTCPDevice];
union uDataPLCType 	BuffTCPModbusTX[kMaxTCPDevice];	//[kMaxMemTCPDevice];
unsigned char		WRStatus[kMaxTCPDevice][kMaxBuffTCPModbus];
int					IdxTCPModbusClient=0;
int					Addr[kMaxTCPDevice];
unsigned char 		FirstScan[kMaxTCPDevice];


int InitTCPModbus(char *server, int port)
{
  unsigned char i;
  int			n;
  printf("Init TCP Modbus !!!!\r\n");

  if (IdxTCPModbusClient>=kMaxTCPDevice) return(0);
  for (i=0; i<kMaxTCPDevice; i++)
  	{
  	 BuffTCPModbus[IdxTCPModbusClient].DataShort[i]=0;
	 Addr[i]=0;
	 FirstScan[i]=kFALSE;
	 for (n=0; n<kMaxBuffDEV; n++) WRStatus[i][n]=kFALSE;
  	}
  
  InitTCPClient((void*)&ModbusTCP_TX,		//
  			   (void*) &ModbusTCP_RX,		//
  			   (char*)server,						//ServerModbus,				//
  			   port,						// kPortTCPModbus,			//  8000
  			   kTCPModbusType,			//
  			   IdxTCPModbusClient,		// TCP Modbus Buffer Idx			// This auto increment
  			   50000,						// 10000mS
  			   50000,						// 1000000uS
  			   (unsigned char*)&pBuffTXModbus[IdxTCPModbusClient][0],
  			   (unsigned char*)&pBuffRXModbus[IdxTCPModbusClient][0],
  			   kMaxBuffTCPModbus);
  IdxTCPModbusClient++;
  return(1);
}



int ModbusTCP_TX(int Idx, int IdxVar)
{
 short  len=0;
 short  n;
 unsigned char	WriteTCPModbus=kFALSE;
 //printf("TCP Modbus !!!! Count:%d\r\n", counting);
// PLCParamTCP[Idx].DataParam[PLCParamTCP[Idx].Queue].Addr
//  PLCParamTCP[Idx].DataParam[PLCParamTCP[Idx].Queue].Size
// printf("Id: %d  IDVAr: %d\r\n", Idx, IdxVar);
 memset(TblTCPCLient[Idx].pBuffTX,0, kMaxBuffTCPModbus);
 if (PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].DataType==kNULL_DataType) return(0);
 if (PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].DataType==kReg_HoldingReg)
 	{
 	 WriteTCPModbus=kFALSE;
 	 for (n=0; n<kMaxBuffDEV; n++)
 	 	{
 	 	 if (WRStatus[IdxVar][n])
 	 	 	{
 	 	 	 Addr[IdxVar]=n;
			 WriteTCPModbus=kTRUE;
 	 	 	 break;
 	 	 	}
 	 	}
 	 if (WriteTCPModbus==kFALSE)
 	 	{
		 TblTCPCLient[Idx].pBuffTX[len++]=counting>>8;
		 TblTCPCLient[Idx].pBuffTX[len++]=counting & 0xFF;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=6;							// Total Data Protocol
		 TblTCPCLient[Idx].pBuffTX[len++]=kSlaveAddressTCP; 			// Slave Addr
		 TblTCPCLient[Idx].pBuffTX[len++]=kReadHoldingReg;	//kReadHoldingReg;				// Function Code
		 TblTCPCLient[Idx].pBuffTX[len++]=PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].Addr>>8;			// kOffAddr>>8;					// OffSet Addr MSB
		 TblTCPCLient[Idx].pBuffTX[len++]=PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].Addr & 0xFF;		//kOffAddr & 0xFF;				// OffSet Addr LSB
		 TblTCPCLient[Idx].pBuffTX[len++]=PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].Size>>8;			// kTotalRead>>8;				// Total Data MSB
		 TblTCPCLient[Idx].pBuffTX[len++]=PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].Size & 0xFF;		// kTotalRead & 0xFF;			// Total Data LSB
		 TblTCPCLient[Idx].pBuffTX[5]=len-6;
//		 len=12;
 	 	}
	 else
	 	{
		 TblTCPCLient[Idx].pBuffTX[len++]=counting>>8;
		 TblTCPCLient[Idx].pBuffTX[len++]=counting & 0xFF;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=6;							// Total Data Protocol
		 TblTCPCLient[Idx].pBuffTX[len++]=kSlaveAddressTCP; 			// Slave Addr
		 TblTCPCLient[Idx].pBuffTX[len++]=kWriteContinousData;			//kReadHoldingReg;				// Function Code
		 TblTCPCLient[Idx].pBuffTX[len++]=Addr[IdxVar]>>8; 						// kOffAddr>>8; 				// OffSet Addr MSB
		 TblTCPCLient[Idx].pBuffTX[len++]=Addr[IdxVar] & 0xFF; 					//kOffAddr & 0xFF;				// OffSet Addr LSB
		 TblTCPCLient[Idx].pBuffTX[len++]=0;
		 TblTCPCLient[Idx].pBuffTX[len++]=1;
		 TblTCPCLient[Idx].pBuffTX[len++]=2;
		 TblTCPCLient[Idx].pBuffTX[len++]=BuffTCPModbusTX[IdxVar].DataShort[Addr[IdxVar]]>>8;
		 TblTCPCLient[Idx].pBuffTX[len++]=BuffTCPModbusTX[IdxVar].DataShort[Addr[IdxVar]]&0xFF;
		 TblTCPCLient[Idx].pBuffTX[5]=len-6;
		 printf("-------> Addr:%d  Value:%d\r\n", Addr[IdxVar], BuffTCPModbusTX[IdxVar].DataShort[Addr[IdxVar]]);
	 	}
 	}
 counting++;
 return(len);
}



void ModbusTCP_RX(int Idx, int IdxVar, int TotalReceived)
{
 int 	n;
 int	temp;
 int	total;

#if 0
 unsigned short j;
 printf("Received: %d bytes  ", TotalReceived);
 for (j=0; j<TotalReceived; j++) printf("%d, ", TblTCPCLient[Idx].pBuffRX[j]);
 printf("\r\n");						
#endif

  total=TblTCPCLient[Idx].pBuffRX[8]>>1;
  if ((TblTCPCLient[Idx].pBuffRX[2]==0)&&
      (TblTCPCLient[Idx].pBuffRX[3]==0)&&
      (TblTCPCLient[Idx].pBuffRX[4]==0)&&
      (TblTCPCLient[Idx].pBuffRX[6]==kSlaveAddressTCP))
  		{
	     if (TblTCPCLient[Idx].pBuffRX[7]==kReadHoldingReg)
	 		{
	 		 TickTCPModbus_++;
			 //printf("Received TCP: %d %d \r\n", pBuffRXModbus[Idx][9], pBuffRXModbus[Idx][10]);
	 		 for (n=0; n<total; n++)
	 		 	{
	 		 	 temp= TblTCPCLient[Idx].pBuffRX[9+(n<<1)];
				 temp=temp<<8;
				 temp|= TblTCPCLient[Idx].pBuffRX[10+(n<<1)];
		 	 	 BuffTCPModbus[IdxVar].DataWord[PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].Addr+n]=temp;
	 		 	}
			 PLCParamTCP[IdxVar].Queue++;
			 if (PLCParamTCP[IdxVar].DataParam[PLCParamTCP[IdxVar].Queue].DataType==kNULL_DataType)
			 	{
			 	 PLCParamTCP[IdxVar].Queue=0;
				 if (FirstScan[IdxVar]==kFALSE)
				 	{
					 for (n=0; n<kMaxBuffDEV; n++)
					 	{
					 	 BuffTCPModbusTX[IdxVar].DataShort[n]=BuffTCPModbus[IdxVar].DataShort[n];
					 	}
				 	 printf(">>>>>>> First Scan !!!!! \r\n");					 
				 	 FirstScan[IdxVar]=kTRUE;					 
				 	}
			 	}
	     	}
		 else if (TblTCPCLient[Idx].pBuffRX[7]==kWriteContinousData)
		 	{
		 	 WRStatus[IdxVar][Addr[IdxVar]]=kFALSE;
		 	}
 		}
// for (n=0; n<20; n++) printf("%d, ", BuffTCPModbus[Idx][n]);
// printf("\r\n");						
}

