#ifndef TCPMODBUS_H
#define TCPMODBUS_H
#include "PLCProtocol.h"


#define kOffAddr				0
#define kTotalRead				32


#define kPortTCPModbus		502
#define kMaxTCPDevice		16
#define kMaxMemTCPDevice	4096
#define kMaxBuffTCPModbus	kMaxTCPDevice*kMaxMemTCPDevice*4
#define kSlaveAddressTCP	1

#define kReadHoldingReg		0x03
#define kWriteContinousData	0x10


extern int	 IdxTCPModbusClient;
extern short Count;
extern union uDataPLCType 	BuffTCPModbus[kMaxTCPDevice];
extern union uDataPLCType 	BuffTCPModbusTX[kMaxTCPDevice];
extern unsigned char		WRStatus[kMaxTCPDevice][kMaxBuffTCPModbus];
//extern char  *ServerModbus;

int InitTCPModbus(char *server, int port);
int ModbusTCP_TX(int Idx, int IdxVar);
void ModbusTCP_RX(int Idx, int IdxVar, int TotalReceived);

#endif
