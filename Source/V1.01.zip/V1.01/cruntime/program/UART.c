#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include "UART.h"
#include <sys/signal.h>
#include "Modbus.h"
#include "System.h"
#include <pthread.h>
//#include "UARTHandler.h"
#include "PLCProtocol.h"


const char  *kTblModemName[]={
	UART_MODEM_tty0,
	UART_MODEM_tty1,
	UART_MODEM_tty2,
	UART_MODEM_tty3,
	UART_MODEM_USB0,
	UART_MODEM_USB1,
	UART_MODEM_USB2,
	UART_MODEM_USB3,
	UART_MODEM_USB4,
	UART_MODEM_USB5,
	UART_MODEM_USB6,
	UART_MODEM_USB7,
	UART_MODEM_USB8,	
	UART_MODEM_USB9,
};
#define kMax_MODEM_SCAN		(sizeof(kTblModemName) / sizeof(kTblModemName[0]))


//#define kMax_MODEM_SCAN		14		//10

//int fd;/*File Descriptor*/
unsigned char BuffRX[kMax_UARTChan][kMaxBuffUART];
unsigned short ptrRX[kMax_UARTChan], ptrRX_[kMax_UARTChan];
unsigned char ReceiveComplete[kMax_UARTChan];
short 		  RXTimeout[kMax_UARTChan];
unsigned char UARTRdy[kMax_UARTChan], UART_RESPONE[kMax_UARTChan];
short		TrialRespone[kMax_UARTChan];
unsigned char UARTUsed[kMax_UARTChan];
unsigned char UARTListStat[kMax_MODEM_SCAN];
//struct termios SerialPortSettings;	/* Create the structure                          */
//struct sigaction saio;
unsigned char UART_Channel[kMax_UARTChan];
struct termios tio[kMax_UARTChan];
struct termios stdio[kMax_UARTChan];
struct termios old_stdio[kMax_UARTChan];
int tty_fd[kMax_UARTChan], flags[kMax_UARTChan];
signed char	IdxModem=0;
signed char	DetectModem=-1;
unsigned int	Debug=0;
short		TotalReceive[kMax_UARTChan];
unsigned int	cntUART;



void signal_handler_IO (int status);   /* definition of signal handler */


void FirstInitUART(void)
{
 unsigned char n;

 for (n=0; n<kMax_MODEM_SCAN; n++) UARTListStat[n]=kFALSE;
 for (n=0; n<kMax_UARTChan; n++) UARTUsed[n]=0xFF;
}


void InitFixedUART(unsigned char idx, unsigned char ttyIdx, int Baudrate, enum eParity Parity, enum eBitSize Bitsize, enum eStopBit StopBit)
{
 tcflag_t 	temptcflag_t;
 	
 UARTRdy[idx]=kFALSE;
 UART_RESPONE[idx]=kFALSE;
 ReceiveComplete[idx]=kFALSE;
 //StatePLC[idx]=kIdleState_PLC;
 ptrRX[idx]=0;
 memset(&BuffRX[idx][0], 0, kMaxBuffUART);
 tcgetattr(STDOUT_FILENO,&old_stdio[idx]);
// printf("Please start with %s /dev/ttyS1 (for example)\n",argv[0]);
 memset(&stdio,0,sizeof(stdio[idx]));
 stdio[idx].c_iflag=0;
 stdio[idx].c_oflag=0;
 stdio[idx].c_cflag=0;
 stdio[idx].c_lflag=0;
 stdio[idx].c_cc[VMIN]=0;	// 1;
 stdio[idx].c_cc[VTIME]=1;	//	0;
 tcsetattr(STDOUT_FILENO,TCSANOW,&stdio[idx]);
 tcsetattr(STDOUT_FILENO,TCSAFLUSH,&stdio[idx]);
 fcntl(STDIN_FILENO, F_SETFL, O_NONBLOCK);       // make the reads non-blocking
 memset(&tio[idx],0,sizeof(tio[idx]));
 tio[idx].c_iflag=0;
 tio[idx].c_oflag=0;
 //tio.c_cflag=CS8|CREAD|CLOCAL;           // 8n1, see termios.h for more information
 temptcflag_t=CREAD|CLOCAL;
 if (Bitsize==k8_BIT) temptcflag_t|=CS8;
 else if (Bitsize==k7_BIT) temptcflag_t|=CS7;
 if (Parity==kODD_PARITY) temptcflag_t|=PARENB|PARODD;
 else if (Parity==kEVEN_PARITY) temptcflag_t|=PARENB;
 if (StopBit==k2_STOP) temptcflag_t|=CSTOPB;
 tio[idx].c_cflag=temptcflag_t;	//CS7|PARENB|CREAD|CLOCAL;           // 8n2, see termios.h for more information
 tio[idx].c_lflag=0;
 tio[idx].c_cc[VMIN]=0;		// 0: No block
 tio[idx].c_cc[VTIME]=1;	// 200mS Timeout	///1;//10;//5;	//5;

printf("Start Detect Modem.... %d\r\n", ttyIdx);

if((tty_fd[idx]= open(kTblModemName[ttyIdx] , O_RDWR|O_NOCTTY | O_SYNC)) == -1)
	{
	  printf("Error while opening\r\n"); // Just if you want user interface error control
	  return;// -1;
	}
 else
	 {
	   DevNum[idx]=1;	//SlaveAddr;
	   UARTUsed[idx]=IdxModem;
	   UARTListStat[UARTUsed[idx]]=kTRUE;
	   UARTRdy[idx]=kTRUE;
	   TrialRespone[idx]=0;
	    printf("COM:  %s   UARTRdy%d: %d\r\n", kTblModemName[IdxModem] , idx, UARTRdy[idx]);
	 }
 tcflush(tty_fd[idx], TCIFLUSH);
 
 cfsetospeed(&tio[idx],Baudrate); 
 cfsetispeed(&tio[idx],Baudrate);         // baudrate is declarated above
 tcsetattr(tty_fd[idx],TCSANOW,&tio[idx]);
 ptrRX[idx]=0;
}
 
void InitUART(unsigned char idx, unsigned char SlaveAddr, int Baudrate, enum eParity Parity, enum eBitSize Bitsize, enum eStopBit StopBit)
{
 tcflag_t 	temptcflag_t;
 unsigned char stat;
 	
 UARTRdy[idx]=kFALSE;
 UART_RESPONE[idx]=kFALSE;
 ReceiveComplete[idx]=kFALSE;
// StatePLC[idx]=kIdleState_PLC;
 ptrRX[idx]=0;
 memset(&BuffRX[idx][0], 0, kMaxBuffUART);
 tcgetattr(STDOUT_FILENO,&old_stdio[idx]);
// printf("Please start with %s /dev/ttyS1 (for example)\n",argv[0]);
 memset(&stdio,0,sizeof(stdio[idx]));
 stdio[idx].c_iflag=0;
 stdio[idx].c_oflag=0;
 stdio[idx].c_cflag=0;
 stdio[idx].c_lflag=0;
 stdio[idx].c_cc[VMIN]=0;	// 1;
 stdio[idx].c_cc[VTIME]=1;	//	0;
 tcsetattr(STDOUT_FILENO,TCSANOW,&stdio[idx]);
 tcsetattr(STDOUT_FILENO,TCSAFLUSH,&stdio[idx]);
 fcntl(STDIN_FILENO, F_SETFL, O_NONBLOCK);       // make the reads non-blocking
 memset(&tio[idx],0,sizeof(tio[idx]));
 tio[idx].c_iflag=0;
 tio[idx].c_oflag=0;
 //tio.c_cflag=CS8|CREAD|CLOCAL;           // 8n1, see termios.h for more information
 temptcflag_t=CREAD|CLOCAL;
 if (Bitsize==k8_BIT) temptcflag_t|=CS8;
 else if (Bitsize==k7_BIT) temptcflag_t|=CS7;
 if (Parity==kODD_PARITY) temptcflag_t|=PARENB|PARODD;
 else if (Parity==kEVEN_PARITY) temptcflag_t|=PARENB;
 if (StopBit==k2_STOP) temptcflag_t|=CSTOPB;
 tio[idx].c_cflag=temptcflag_t;	//CS7|PARENB|CREAD|CLOCAL;           // 8n2, see termios.h for more information
 tio[idx].c_lflag=0;
 tio[idx].c_cc[VMIN]=0;		// 0: No block
 tio[idx].c_cc[VTIME]=1;	// 200mS Timeout	///1;//10;//5;	//5;

printf("Detect Modem %d\r\n", IdxModem);

while(UARTRdy[idx]==kFALSE)
	{
	 stat=kTRUE;
	 while(stat)
	 	{
		 IdxModem++;
		 if ((IdxModem>=kMax_MODEM_SCAN)||(IdxModem<0)) IdxModem=0;
		 if (UARTListStat[IdxModem]==kFALSE) stat=kFALSE;
	 	}

	 while(UARTRdy[idx]==kFALSE)
			{
			 if((tty_fd[idx]= open(kTblModemName[IdxModem] , O_RDWR|O_NOCTTY | O_SYNC)) == -1)
				{
				  printf("Error while opening\r\n"); // Just if you want user interface error control
				  return;// -1;
				}
			 else
				 {
				   DevNum[idx]=SlaveAddr;
				   UARTUsed[idx]=IdxModem;
				   UARTListStat[UARTUsed[idx]]=kTRUE;
				   UARTRdy[idx]=kTRUE;
				   TrialRespone[idx]=0;
				    printf("COM:  %s   UARTRdy%d: %d\r\n", kTblModemName[IdxModem] , idx, UARTRdy[idx]);
				   
				 }
			}
	}
 tcflush(tty_fd[idx], TCIFLUSH);
 
 cfsetospeed(&tio[idx],Baudrate); 
 cfsetispeed(&tio[idx],Baudrate);         // baudrate is declarated above
 tcsetattr(tty_fd[idx],TCSANOW,&tio[idx]);
 ptrRX[idx]=0;
}


void SendUART(unsigned char idx, unsigned short size)
{
 if (UARTRdy[idx])
 	{
// 	  cntUART++;
	  if (write(tty_fd[idx],&BuffRX[idx][0], size)<0)
		{
		  UARTRdy[idx]=kFALSE;
		  UART_RESPONE[idx]=kFALSE;
		  CloseUART(idx);
		  printf("UART Failed !!!!!!!!\r\n");			 
		}
	  else 
	  	{
	  	  cntUART++;
//		  printf("Idx:%d  UART Rdy: %d, %02x, %02x,%02x,%02x \r\n", idx, UARTRdy[idx], BuffRX[idx][0], BuffRX[idx][1], BuffRX[idx][2], BuffRX[idx][3]);		  
	  	}
 	}
}


unsigned short  ReadUART(unsigned char idx)
{
///  struct serial_data recv_data;
  int recvbytes = 0;
  int maxfd = tty_fd[idx] + 1;  
   /* set the timeout as 1 sec for each read */
  struct timeval timeout = {0, 100};
  fd_set readSet;
  unsigned char Buff[2048];

 
  FD_ZERO(&readSet);
  FD_SET(tty_fd[idx], &readSet);
  if(select(maxfd, &readSet, NULL, NULL, &timeout) > 0)
        {
            if (FD_ISSET(tty_fd[idx], &readSet))
	  	{
	                recvbytes = read(tty_fd[idx], &Buff, 2048);
	                if(recvbytes>0)
	                	{
#if 0
						 int n;
						 printf("%d bytes  ---> ", recvbytes);
						 for (n=0; n<recvbytes; n++)
						 	{
						 	 printf("%d, ", Buff[n]);	 
						 	}
						 printf("\r\n");
#endif						 
						 if (ptrRX[idx]<(kMaxBuffUART-recvbytes))
						 	{
						 	 if (ptrRX[idx]==0) memset(&BuffRX[idx][0], 0, kMaxBuffUART);
							 memcpy(&BuffRX[idx][ptrRX[idx]], &Buff[0],recvbytes);
							 ptrRX[idx]+= recvbytes;
							 RXTimeout[idx]=25;		//5;	//15;
						 	}	                    	 
	                	}
	                else
	                	{
		                    /* handle error */
	                	}
		}
	}
  return(recvbytes);
}


void FlushUARTBuff(unsigned char idx)
{
  tcflush(tty_fd[idx], TCIFLUSH);
}


void CloseUART(unsigned char idx)
{
 if (UARTUsed[idx]<kMax_MODEM_SCAN) UARTListStat[UARTUsed[idx]]=kFALSE;
 tcflush(tty_fd[idx], TCIFLUSH); 
 tcsetattr(STDOUT_FILENO,TCSANOW,&old_stdio[idx]);
 close(tty_fd[idx]);
}


void StartReceiveUART(unsigned char idx)
{
 ptrRX[idx]=0;
 ptrRX_[idx]=0;
 ReceiveComplete[idx]=kFALSE;
 RXTimeout[idx]=7;
}



void *ReceiveUART(void* args)
{
 unsigned char n;
 
 printf("Check UART... \r\n");
 while(1)
	{
//s	 Debug++;
	 for (n=0; n<kMax_UARTChan; n++)
	 	{
		  if (UARTRdy[n]) ReadUART(n);
	 	}
	 usleep(10000);
	}
}


void CheckUART(unsigned char idx)
{
 if (FlagsSystem.Tick1mS)
	{
	  if (ptrRX[idx])	
	 	{
		  if (RXTimeout[idx]) RXTimeout[idx]--;
		  else
			{
			 ReceiveComplete[idx]=kTRUE;
			 TotalReceive[idx]=ptrRX[idx];
			}
	 	}
	} 
}
