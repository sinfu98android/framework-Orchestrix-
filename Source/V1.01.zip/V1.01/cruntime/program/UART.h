#ifndef UART_H
#define UART_H
//#include "UARTHandler.h"


#define kMaxBuffUART		2048




#define UART_MODEM_USB20 "/dev/ttyUSB20"			// just to speed up detetction !!!
#define UART_MODEM_USB0 "/dev/ttyUSB0"
#define UART_MODEM_USB1 "/dev/ttyUSB1"
#define UART_MODEM_USB2 "/dev/ttyUSB2"
#define UART_MODEM_USB3 "/dev/ttyUSB3"
#define UART_MODEM_USB4 "/dev/ttyUSB4"
#define UART_MODEM_USB5 "/dev/ttyUSB5"
#define UART_MODEM_USB6 "/dev/ttyUSB6"
#define UART_MODEM_USB7 "/dev/ttyUSB7"
#define UART_MODEM_USB8 "/dev/ttyUSB8"
#define UART_MODEM_USB9 "/dev/ttyUSB9"


#define UART_MODEM_tty0 "/dev/ttyS0"
#define UART_MODEM_tty1 "/dev/ttyS1"
#define UART_MODEM_tty2 "/dev/ttyS2"
#define UART_MODEM_tty3 "/dev/ttyS3"

#define kMax_UARTChan		10


enum eParity{
	kNO_PARITY,
	kODD_PARITY,
	kEVEN_PARITY,
};

enum eBitSize{
	kNo_BIT,
	k7_BIT,
	k8_BIT,
};

enum eStopBit{
	kNo_STOP,
	k1_STOP,
	k2_STOP,
};
	
extern unsigned char 		BuffRX[kMax_UARTChan][kMaxBuffUART];
extern unsigned short 		ptrRX[kMax_UARTChan];
extern unsigned char 		ReceiveComplete[kMax_UARTChan];
extern unsigned char 		UARTRdy[kMax_UARTChan], UART_RESPONE[kMax_UARTChan];
extern short				TrialRespone[kMax_UARTChan];
extern unsigned int	   		Debug;
extern signed char 			DetectModem, IdxModem;
extern short 		  		RXTimeout[kMax_UARTChan];
extern short				TotalReceive[kMax_UARTChan];
extern unsigned int			cntUART;
extern unsigned char 		UARTUsed[kMax_UARTChan];
extern unsigned char 		UARTListStat[kMax_MODEM_SCAN];
extern const char  			*kTblModemName[];
extern unsigned char 		UART_Channel[kMax_UARTChan];


void FirstInitUART(void);
void InitUART(unsigned char idx, unsigned char SlaveAddr, int Baudrate, enum eParity Parity, enum eBitSize Bitsize, enum eStopBit StopBit);
void InitFixedUART(unsigned char idx, unsigned char ttyIdx, int Baudrate, enum eParity Parity, enum eBitSize Bitsize, enum eStopBit StopBit);
void SendUART(unsigned char idx, unsigned short size);
unsigned short ReadUART(unsigned char idx );
void FlushUARTBuff(unsigned char idx);
void CloseUART(unsigned char idx);
void StartReceiveUART(unsigned char idx);
void *ReceiveUART(void* args);
void CheckUART(unsigned char idx);
#endif
