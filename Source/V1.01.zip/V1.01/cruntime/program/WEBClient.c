#include "WEBClient.h"
#include "TCPClient.h"
#include "MiscDataConv.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "rfid.h"
#include "Project.h"
#include "System.h"
#include "ADS1256.h"
#include "IOProcess.h"
#include "CheckMACAddr.h"
#include "Control.h"
#include "Modbus.h"
#include "PLCProtocol.h"
#include "cache.h"
#ifdef PLC  
#include "PLC.h"
#endif


const struct stDataMemCache kTblCacheWR[]=
{
  {"macaddr", 	  	kString,	kWRITE,		 			(int*)&mac_addressstr, 					0, 										kSYSTEM_Target, 0,	0},			// 0
  {"ipaddr",		kString, 	kWRITE,					(int*)&ip_address, 						0, 										kSYSTEM_Target, 0,	0},			// 1
  {"cputemp",		kInteger, 	kWRITE,					(int*)&CPUtemp, 						0, 										kSYSTEM_Target, 0,	0},			// 2
  {"cpumem",		kInteger, 	kWRITE,					(int*)&CPUMem, 						0, 										kSYSTEM_Target, 0,	0},			// 3
  {"cpuload",		kInteger, 	kWRITE,					(int*)&CPULoad, 						0, 										kSYSTEM_Target, 0,	0},			// 4
//  {"reboot",		kInteger,	kWRITE|kREAD|kINIT,		(int*)&RebootCount, 					(int*)&RebootCount, 					kSYSTEM_Target, 0,	0},			// 5  
//  {"tick",			kInteger,	kWRITE|kREAD|kINIT, 	(int*)&CPUTick, 						(int*)&CPUTick,							kSYSTEM_Target, 0,	0},			// 6
//  {"input",			kInteger, 	kWRITE|kREAD,			(int*)&IOdatVir.Input.InputDat[0], 		(int*)&IOdatVir.Input.InputDat[0], 		kSYSTEM_Target, 0,	0},			// 7
//  {"output",		kInteger,	kWRITE|kREAD,			(int*)&IOdatVir.Output.OutputDat[0], 	(int*)&IOdatVir.Output.OutputDat[0], 	kSYSTEM_Target, 0,	0},			// 8
//  {"varfloat",		kFloat,		kWRITE|kREAD,			(int*)&VarFloat, 						(int*)&VarFloat, 						kSYSTEM_Target, 0,	0},			// 9  
};
#if 0
 var0, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 0
 var1, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 1
 var2, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 2
 var3, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 3
 var4, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 4
 var5, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 5
 var6, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 6
 var7, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 7
 var8, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 8
 var9, kUShort,	kWRITE|kREAD, TCPMODCLIENT, 0, 9
 var10, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 10
 var11, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 11
 var12, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 12
 var13, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 13
 var14, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 14
 var15, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 15
 var16, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 16
 var17, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 17
 var18, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 18
 var19, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 19
 var20, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 20
 var21, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 21
 var22, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 22
 var23, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 23
 var24, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 24
 var25, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 25
 var26, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 26
 var27, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 27
 var28, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 28
 var29, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 29
 var30, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 30
 var31, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 31
 var32, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 32
 var33, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 33
 var34, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 34
 var35, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 35
 var36, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 36
 var37, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 37
 var38, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 38
 var39, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 39
 var40, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 40
 var41, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 41
 var42, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 42
 var43, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 43
 var44, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 44
 var45, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 45
 var46, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 46
 var47, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 47
 var48, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 48
 var49, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 49
 var50, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 50
 var51, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 51
 var52, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 52
 var53, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 53
 var54, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 54
 var55, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 55
 var56, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 56
 var57, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 57
 var58, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 58
 var59, kUShort, kWRITE|kREAD, TCPMODCLIENT, 0, 59
 
 
#if PLC  
  {"run",			kInteger,	kWRITE|kREAD,			(int*)&PLCRUN},
#endif
  {"varfloat",		kFloat,		kWRITE|kREAD,			(int*)&VarFloat},
#endif


#if 0
const char kTblTypeVar[kMaxTypeVar][kMaxLenCacheId]=
{
 {"kBoolean"},
 {"kShort"},
 {"kUShort"},
 {"kInteger"},
 {"kFloat"},
 {"kString"},
 {"kIntegerRev"},
 {"kFloatRev"}, 
};

const char kTblModeVar[kMaxMode][kMaxLenCacheId]=
{
 {"kNONE"},					// 0x00
 {"kREAD"},					// 0x01
 {"kWRITE"},				// 0x02
 {"kINIT"},					// 0x04
};

const char kTblTargetVar[kMax_Target][kMaxLenCacheId]=
{
 {"TCPMODCLIENT"},			// 0
 {"TCPMODSERVER"},			// 1
 {"COM"},					// 2
 {"SYSTEM"},				// 3
};

#endif


//char					CacheConfig[]="/var/www/html/program/cache.txt";
char 					*hostname = "127.0.0.1";
unsigned char			pBuffTX[kMaxWEBClient][kMaxBuffWEB];
unsigned char			pBuffRX[kMaxWEBClient][kMaxBuffWEB];
int						IdxWEBTCPClient=0;
//int						tickWEBClient=0;
//struct stDataMemCache 	TblCacheWR[kMaxCacheVar];
//struct stDataMemCache 	TblCacheRD[kMaxCacheVar];
//unsigned char			FirstRunMemcache=kTRUE;
//enum eStateCache		RDStat[kMaxCacheVar];
unsigned char			FirstBoot=kFALSE;
//struct stDataMemCache 	VarCache[kMaxCacheVar];
//int						totcache=0;


/*
int GetSizeVarCache(void)
{
 int n, count=0;

 for (n=0; n<kMaxCacheVar; n++)
 	{
 	 if (VarCache[n].pStr[0]==0) break;
	 count++;
 	}
 return(count);
}
*/


#if 0
void OpenCache(void)
{
 FILE *fptr;
 int n, i, k, count;
 struct stSplit BuffParse;
 struct stSplit BuffSplit;
 struct stSplit BuffSplitMode;
 int totline=0;
 int totsplit=0;
 int totMode=0;
 unsigned char stat=kFALSE;
 char tStr[kMaxLenCacheId];
 enum eTypeVar	tTypeVar;
 unsigned short tMode;
 unsigned short tIdx;
 int 			tAddr;
 int			*tTarget;
 int			*tTargetWR;


 MakeSureFileExist((char*)&CacheConfig);
 printf("Open Cache Config:\r\n");
 int res = findSize((char*)&CacheConfig);
 if (res<=0) return;
 char myString[res+10];
 memset(myString, 0, sizeof(myString));
 for (n=0; n<kMaxString; n++) memset(BuffParse.str[n], 0, sizeof(BuffParse.str[n]));
 for (n=0; n<kMaxString; n++) memset(BuffSplit.str[n], 0, sizeof(BuffSplit.str[n])); 
 
 fptr = fopen((char*)&CacheConfig, "r");
 fread(myString, sizeof(myString), 1, fptr);
 fclose(fptr); 
 totline=SplitLine((char*)myString, (struct stSplit*)&BuffParse);
 printf("Total Line: %d \r\n", totline);
// for (n=0; n<totline; n++) printf("%s\r\n", (char*)&BuffParse.str[n]);
 
 for (n=0; n<totline; n++)
 	{
// 	 printf("%s\r\n", (char*)&BuffParse.str[n]);
	 memset((char*)&BuffSplit, 0, sizeof(BuffSplit));
	 totsplit=SplitString((char*)&BuffParse.str[n], (struct stSplit*)&BuffSplit, ',');
	 if (totsplit>=6)
	 	{
	     printf("%d ", n);
	 	 stat=kTRUE;
		 memset(tStr, 0, sizeof(tStr));
		 /********************** Get Id name *********************/
		 strcat((char*)&tStr, (char*)&BuffSplit.str[0]);
 		 /********************** Get Type Var *********************/
		 count=0;
		 for (i=0; i<kMaxTypeVar; i++)
		 	{
		 	 if (CmpStr((char*)&BuffSplit.str[1], (char*)&kTblTypeVar[i]))
		 	 	{
		 	 	 tTypeVar=i;
// 	 		 	 printf("%s --- %s",(char*)&BuffSplit.str[1], (char*)(char*)&kTblTypeVar[i]);
//	 			 printf("  same ..\r\n");
		 	 	 break;
		 	 	}
			 count++;
			 if (count>=kMaxTypeVar) stat=kFALSE;
		 	}
 		 /********************** Get Mode *********************/
//		 printf("%s, %s ---> ", (char*)&BuffSplit.str[0], (char*)&BuffSplit.str[2]);
		 tMode=0;
		 memset((char*)&BuffSplitMode, 0, sizeof(BuffSplitMode));
		 totMode=SplitString((char*)&BuffSplit.str[2], (struct stSplit*)&BuffSplitMode, '|');
		 for (i=0; i<totMode; i++)
		 	{
		 	 //printf("%s,", (char*)&BuffSplitMode.str[i]);
		 	 count=0;
			 for (k=0; k<kMaxMode; k++)
			 	{
			 	 if (CmpStr((char*)&BuffSplitMode.str[i], (char*)&kTblModeVar[k]))
			 	 	{
			 	 	 if (k==1) tMode|=0x0001;
					 if (k==2) tMode|=0x0002;
					 if (k==3) tMode|=0x0004;
					 break;
			 	 	}
				 count++;
				 if (count>=kMaxMode) stat=kFALSE;
			 	}
		 	}
		/********************** Get Index *********************/
		tIdx=atoi((char*)&BuffSplit.str[4]);
		/********************** Get Address *******************/
		tAddr=atoi((char*)&BuffSplit.str[5]);	
		printf("%d, %d ", tIdx, tAddr);		
		/********************** Get Target *********************/
		printf("%s ", (char*)&BuffSplit.str[3]);
		count=0;
		for (k=0; k<kMax_Target; k++)
			{
			 if (CmpStr((char*)&BuffSplit.str[3], (char*)&kTblTargetVar[k]))
			 	{
			 	 if (k==kTCPCLIENT_Target)
			 	 	{
					 tTarget=(int*)&BuffTCPModbus[tIdx].DataWord[tAddr];
					 tTargetWR=(int*)&BuffTCPModbusTX[tIdx].DataWord[tAddr];
			 	 	}
				 else if (k==kTCPSERVER_Target)
				 	{
				 	 tTarget=(int*)&VarModbus.DataModbus[tAddr];
					 tTargetWR=(int*)&VarModbus.DataModbus[tAddr];
				 	}
				 else if (k==kCOM_Target)
				 	{
				 	 tTarget=(int*)&DataPLC_RX[tIdx].DataWord[tAddr];
					 tTargetWR=(int*)&DataPLC_TX[tIdx].DataWord[tAddr];
				 	}
				 break;
			 	}
			 count++;
			 if (count>=kMax_Target) stat=kFALSE; 
			}
	
	 	 if (stat)
	 	 	{
		 	 strcat((char*)&VarCache[totcache].pStr, (char*)&tStr);
			 VarCache[totcache].TypeVar=tTypeVar;
			 VarCache[totcache].Mode=tMode;
			 VarCache[totcache].pInt=tTarget;
			 VarCache[totcache].pIntTarget=tTargetWR;
			 VarCache[totcache].VarTarget=k;
			 VarCache[totcache].Idx=tIdx;
			 VarCache[totcache].Addr=tAddr;
			 totcache++;
	 	 	}
//		 printf("	tot:%d --> ", totsplit);
//		 for (i=0; i<totsplit; i++) printf("%s;", (char*)&BuffSplit.str[i]);
//		 printf("  %s\r\n", tStr);
	 	}
	 printf("\r\n");
 	}
}
#endif

int InitWEBClient(void)
{
 int	n;

 memset(VarCache,0, sizeof(VarCache));
 for (n=0; n<kTotalWriteMemCache; n++) VarCache[n]=kTblCacheWR[n];
 totcache=GetSizeVarCache();
 OpenCache();
 for (n=0; n<totcache; n++) printf("%s, %d, %d, %ld\r\n", (char*)&VarCache[n].pStr, VarCache[n].TypeVar, VarCache[n].Mode, (long int)VarCache[n].pInt);
// exit(0);
 
 if (IdxWEBTCPClient>=kMaxWEBClient) return(0);
 for (n=0; n<kMaxCacheVar; n++) RDStat[n]=kCacheInit;		// preset value null
 InitTCPClient((void*)&WEBClientProcessTX,
  			   (void*)&WEBClientProcessRX,
  			   hostname,
  			   kPortWEB,						// Port 80
 			   kWEBMemcacheType,
 			   IdxWEBTCPClient,				// TCP WEB Buffer Idx			// This auto increment
  			   100000,						// 25000uS
  			   100000,						// 25000uS
  			   (unsigned char*)&pBuffTX[IdxWEBTCPClient][0],
  			   (unsigned char*)&pBuffRX[IdxWEBTCPClient][0],
  			   kMaxBuffWEB);
 IdxWEBTCPClient++;
 return(kTRUE);
}


int WEBMemcacheTX(int Idx, int IdxVar)
{
 int 				len;
 int				n;
 char				intstr[12];
 int				i, datalenPos;
// char				buffwr[128][64];
 char				buffwr[kMaxString]; 
 int				totWriteCache=0, totReadCache=0;
 union uVarGlobal	var, var_;
 short				*pShort;
 unsigned short   	*pUShort;
 unsigned char		stat;
 
 
 for (n=0; n<totcache; n++)
 	{
 	 if (VarCache[n].Mode & kWRITE) totWriteCache++;
	 if (VarCache[n].Mode & kREAD) totReadCache++;
//	 if (RDStat[n]<=kCacheGetInitValue) stat=kFALSE;
 	}
 if (RDStat[kREBOOT_id]==kCacheUpdate)			// Reboot ID
 	{
 	 //printf("Reboot Counting >>>>>>>>>>>>>>>>>>>>>>>\r\n");
 	 if (FirstBoot==kFALSE)
 	 	{
 	 	 FirstBoot=kTRUE;
		 RebootCount++;
 	 	}
 	}
// printf("Rd:%d Wr:%d\r\n", totWriteCache, totReadCache);

 memset(TblTCPCLient[Idx].pBuffTX,0, kMaxBuffWEB);
 LoadString((char *)kStrPOS, (char*)TblTCPCLient[Idx].pBuffTX);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)TblTCPCLient[Idx].Hostname);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)kStrPOS_);
 datalenPos=strlen((char*)TblTCPCLient[Idx].pBuffTX);
 
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrrdwrmulti);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrTag);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kResponeServer);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);

 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrTotalWR);
 my_itoa(totWriteCache, intstr);
	
 strcat((char*)TblTCPCLient[Idx].pBuffTX, intstr);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);

 i=0;
 for (n=0; n<totcache; n++)
	{	 
	 stat=kTRUE;
	 if (VarCache[n].Mode & kREAD)
		{
		 if ((RDStat[n]==kCacheInit)||(RDStat[n]==kCachePreset)) stat=kFALSE;
		}
	 
	 if (VarCache[n].Mode & kWRITE)
	 	{
	 	 if ((VarCache[n].Mode & kINIT)&&(RDStat[n]==kCacheGetInitValue)) stat=kFALSE;
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStridw); 		// "d"
		 my_itoa(i, intstr);
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, intstr);					// "x"
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrEqual);		// "="
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)&VarCache[n].pStr[0]);
 		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAddress);
  		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)mac_addressstr);

		 //mac_address[];
 		 if (stat==kFALSE)
 		 	{
		 	 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrWRSign);
 		 	}
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrvalw);		// "valw"
		 my_itoa(i++, intstr);
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, intstr);					// "x"
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrEqual);		// "="
		 memset(buffwr,0, sizeof(buffwr));
		 if (stat)
		 	{
			 if (VarCache[n].TypeVar==kUShort)
				{
				 pUShort=(unsigned short*)VarCache[n].pInt;
				 my_itoa(*pUShort, (char*)&buffwr[0]);
				}
			 else if (VarCache[n].TypeVar==kShort)
				{
				 pShort=(short*)VarCache[n].pInt;
				 my_itoa(*pShort, (char*)&buffwr[0]);
			 	}
			 else if (VarCache[n].TypeVar==kInteger)
				{
				 my_itoa(*VarCache[n].pInt, (char*)&buffwr[0]);
				}
			 else if (VarCache[n].TypeVar==kIntegerRev)
				{
				 var_.vInt=*VarCache[n].pInt;
			     var.vBuffUShort[0]=var_.vBuffUShort[1];
				 var.vBuffUShort[1]=var_.vBuffUShort[0];
				 my_itoa(var.vInt, (char*)&buffwr[0]);
				}			 
			 else if (VarCache[n].TypeVar==kFloat)
			 	{
			     var.vInt=*VarCache[n].pInt;
			 	 FloatToStr(var.vFloat, (char*)&buffwr[0], 3);
			 	}
			 else if (VarCache[n].TypeVar==kFloatRev)
			 	{
			 	 var_.vInt=*VarCache[n].pInt;
			     var.vBuffUShort[0]=var_.vBuffUShort[1];
				 var.vBuffUShort[1]=var_.vBuffUShort[0];
				 //printf("%f\n", var.vFloat);
			 	 FloatToStr(var.vFloat, (char*)&buffwr[0], 3);
			 	}			 
			 else if (VarCache[n].TypeVar==kString)
				{
				 strcat((char*)&buffwr[0], (char *)VarCache[n].pInt);
				}
			 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)&buffwr[0]);				// "value"			 
		 	}
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);
	 	}
 	}

 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrTotalRD);
 my_itoa(totReadCache, intstr);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, intstr);
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);
 
 i=0;
 for (n=0; n<totcache; n++)
	{
	 if (VarCache[n].Mode & kREAD)
	 	{
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStridr); 		// "d"
		 my_itoa(i++, intstr);
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, intstr);					// "x"
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrEqual);		// "="
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)&VarCache[n].pStr[0]);
 		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAddress);
  		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)mac_addressstr);		 
 		 if (VarCache[n].Mode & kWRITE)
 		 	{
 		 	 if (RDStat[n]!=kCacheGetInitValue)
 		 	 	{
				 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrWRSign);		// "_"
 		 	 	}
			 else 
			 	{
//			 	 printf("READ CACHE>>>> %s\r\n", (char*)TblTCPCLient[Idx].pBuffTX);
			 	}
 		 	}
		 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char *)kStrAND);
	 	}
	}

 i=strlen((char*)TblTCPCLient[Idx].pBuffTX);
 i=i-datalenPos;
 my_itoa(i,intstr);
 for (n=0; n<strlen(intstr); n++) TblTCPCLient[Idx].pBuffTX[datalenPos-(strlen(intstr)+4)+n]=intstr[n];
 strcat((char*)TblTCPCLient[Idx].pBuffTX, (char*)kStrDBLEnter);
 
 len=strlen((char*)TblTCPCLient[Idx].pBuffTX);
 //printf("%s\r\n", (char*)TblTCPCLient[Idx].pBuffTX);
 return(len);
}



void WEBMemcacheRX(int Idx, int IdxVar, int TotBuffRecv)
{
 int 				pos=0;
 char 				tStr[kMaxString];
 char* 				pBuff_;
 int				temp;
 union  uVarGlobal	var, var_;
 int 				n;
 unsigned short		*pUShort;
 short				*pShort;
	
 pos=strpos( "HTTP/1.1 200 OK", (char*)TblTCPCLient[Idx].pBuffRX);
 if (pos>=0)
	{
	 //printf("%s\r\n", (char*)TblTCPCLient[Idx].pBuffRX);
	 pBuff_=(char*)TblTCPCLient[Idx].pBuffRX;
	 pos=strpos((char*)kResponeServer, (char*)TblTCPCLient[Idx].pBuffRX);
	 if (pos>0)
		{
		 pBuff_+=(pos+strlen(kResponeServer));
		 pBuff_++;
//		 printf("%s\r\n", (char*)pBuff_);
		 n=0;
//		 printf("Starting...\r\n");
		 while(1)
			{
			 memset(tStr,0, sizeof(tStr));
			 strcpyPos(pBuff_, (char *)&tStr, 0, ',');
			 while(1)
			 	{
//			 	 printf("here1...%s  length:%d, %d  %s\r\n", (char*)pBuff_, temp, n, (char*)tStr);
			 	 if (VarCache[n].Mode & kREAD)
			 	 	{
			 	 	 temp=strlen(tStr);
					 if (VarCache[n].Mode & kWRITE)
						{
						 if (RDStat[n]==kCacheInit)
						 	{
						 	 if (VarCache[n].Mode & kINIT)
						 	 	{
						 	 	 RDStat[n]=kCacheGetInitValue;
						 	 	}
							 else
							 	{
								 if (temp==0) RDStat[n]=kCacheUpdate;
							 	}
						 	}
						 else if (RDStat[n]==kCacheGetInitValue)
						 	{
						 	 RDStat[n]=kCacheUpdate;
						 	}
						 else if (RDStat[n]==kCachePreset)
						 	{
						 	  RDStat[n]=kCacheUpdate;
							  //printf("Update >>>>>\r\n");  
							}
						}
					 else RDStat[n]=kCacheUpdate;
					 
				 	 if (temp)
				 		{
						 if (VarCache[n].TypeVar==kUShort)
						 	{
						 	 temp=atoi(tStr);
							 var.vUShort=(unsigned short)temp;
							 pUShort=(unsigned short*)VarCache[n].pIntTarget;
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *pUShort=var.vUShort;
							 	}
							 else
							 	{
								 *pUShort=var.vUShort;
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target) WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
								 else if (VarCache[n].VarTarget==kCOM_Target) WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
	 							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *pUShort);
							 	}							 
						 	 //printf(">>>>> UShort...\r\n");
						 	}
						 else if (VarCache[n].TypeVar==kShort)
						 	{
						 	 temp=atoi(tStr);
							 var.vShort=(short)temp;
							 pShort=(short*)VarCache[n].pIntTarget;
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *pShort=var.vShort;
							 	}
							 else
							 	{
								 *pShort=var.vShort;								 
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target) WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
								 else if (VarCache[n].VarTarget==kCOM_Target) WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
	 							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *pShort);
							 	}							 
						 	 //printf(">>>>> Short...\r\n");
						 	}
					 	 else if (VarCache[n].TypeVar==kInteger)
							{
							 //printf(">>>>> here3...\r\n");
							 temp=atoi(tStr);
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *VarCache[n].pIntTarget=temp;
							 	}
							 else
							 	{
								 *VarCache[n].pIntTarget=temp;
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target)
								 	{
								 	 WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatus[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 else if (VarCache[n].VarTarget==kCOM_Target)
								 	{
								 	 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
	 							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *VarCache[n].pIntTarget);
							 	}
							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *VarCache[n].pIntTarget);
							 //*VarCache[n].pInt=temp;
							}
					 	 else if (VarCache[n].TypeVar==kIntegerRev)
							{
							 //printf(">>>>> here3...\r\n");
							 var_.vInt=atoi(tStr);
							 var.vBuffUShort[0]=var_.vBuffUShort[1];
							 var.vBuffUShort[1]=var_.vBuffUShort[0];
							 temp=var.vInt;
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *VarCache[n].pIntTarget=temp;
							 	}
							 else
							 	{
								 *VarCache[n].pIntTarget=temp;
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target)
								 	{
								 	 WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatus[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 else if (VarCache[n].VarTarget==kCOM_Target)
								 	{
								 	 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
	 							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *VarCache[n].pIntTarget);
							 	}
							 //printf(">>>>> Here ... %d,  %d\r\n", VarCache[n].VarTarget, *VarCache[n].pIntTarget);
							 //*VarCache[n].pInt=temp;
							}
						 
						 else if (VarCache[n].TypeVar==kFloat)
						 	{
						 	 var.vFloat=atof(tStr);
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *VarCache[n].pIntTarget=var.vInt;
							 	}
							 else
							 	{
								 *VarCache[n].pIntTarget=var.vInt;
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target)
								 	{
								 	 WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatus[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 else if (VarCache[n].VarTarget==kCOM_Target)
								 	{
								 	 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 //*VarCache[n].pInt=var.vInt;
							 	}							 
						 	}
						 else if (VarCache[n].TypeVar==kFloatRev)
						 	{
						 	 var_.vFloat=atof(tStr);
							 var.vBuffUShort[0]=var_.vBuffUShort[1];
							 var.vBuffUShort[1]=var_.vBuffUShort[0];
							 if (VarCache[n].VarTarget==kSYSTEM_Target)
							 	{
							 	 if (VarCache[n].pIntTarget) *VarCache[n].pIntTarget=var.vInt;
							 	}
							 else
							 	{
								 *VarCache[n].pIntTarget=var.vInt;
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target)
								 	{
								 	 WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatus[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 else if (VarCache[n].VarTarget==kCOM_Target)
								 	{
								 	 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
									 WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr+1]=kTRUE;
								 	}
								 //*VarCache[n].pInt=var.vInt;
							 	}							 
						 	}
						 else if (VarCache[n].TypeVar==kString)
						 	{
						 	 if (VarCache[n].VarTarget==kSYSTEM_Target)
						 	 	{
						 	 	 if (VarCache[n].pIntTarget) strcpy((char*)VarCache[n].pIntTarget, (char*)tStr);
						 	 	}
							 else
						 	 	{
								 strcpy((char*)VarCache[n].pIntTarget, (char*)tStr);
								 if (VarCache[n].VarTarget==kTCPCLIENT_Target) WRStatus[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;
								 else if (VarCache[n].VarTarget==kCOM_Target) WRStatusCOM[VarCache[n].Idx][VarCache[n].Addr]=kTRUE;								 
								 //strcpy((char*)VarCache[n].pInt, (char*)tStr);
						 	 	}
						 	}

						 if (RDStat[n]==kCacheUpdate)
							{
//							 printf("update cache !!!!  %d\r\n", n);
							 if (VarCache[n].Mode & kWRITE)
							 	{
							 	 RDStat[n]=kCachePreset;
///								 printf("update cache !!!!  %d\r\n", n);
							 	}
							}					 						 
				 	 	}
					 n++;
					 break;					 
			 	 	}
				 n++;
				 if (n>=totcache) break;
			 	}
			 pBuff_+=strlen(tStr);
			 if (strlen(pBuff_)<=0)
			 	{
//			 	 FirstRunMemcache=kTRUE;
//				 printf("Quit !!!!\r\n");
			 	 break;
			 	}
			 pBuff_++;					// remove delimiter
			}
		 TickCache_++;
		 //printf("%d, %d, %d, %d, %d, %d, %d, %d\r\n", DataPLC_TX[0].DataWord[1], DataPLC_TX[0].DataWord[2], DataPLC_TX[0].DataWord[3], DataPLC_TX[0].DataWord[4], DataPLC_TX[0].DataWord[5], DataPLC_TX[0].DataWord[6], DataPLC_TX[0].DataWord[7], DataPLC_TX[0].DataWord[8]);
		}
//	 printf("\r\n");
//	 printf("\r\n");	 
	}
}


int WEBClientProcessTX(int Idx, int IDVar)
{
 int val=0;
 
 if (TblTCPCLient[Idx].Type==kWEBMemcacheType) val=WEBMemcacheTX(Idx, IDVar);

 return(val);
}


void WEBClientProcessRX(int Idx, int IDVar, int TotBuffRecv)
{
 if (TblTCPCLient[Idx].Type==kWEBMemcacheType) WEBMemcacheRX(Idx, IDVar, TotBuffRecv);
}

