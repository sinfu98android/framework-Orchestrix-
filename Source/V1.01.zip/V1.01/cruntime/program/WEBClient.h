#ifndef WEBCLIENT_H
#define WEBCLIENT_H
#include "webstring.h"
#include "cache.h"

#define kMaxBuffWEB		1024*1024
#define kPortWEB			80
#define kMaxWEBClient	8
//#define kMaxCacheVar	16384
//#define kMaxLenCacheId	32

#if 0
#define kNONE			0
#define kREAD			1
#define kWRITE			2
#define kINIT			4


#define kMACAddr_id		0
#define kIPADD_id		1
#define kCPUTEMP_id		2
#define kCPUMEM_id		3
#define kCPULOAD_id		4
#define kREBOOT_id		5
#define kCPUTICK_id		6
#define kINPUT_id		7
#define kOUTPUT_id		8
#endif

#if 0

{"macaddr", 	  kString,	  kWRITE,				  (int*)&mac_addressstr},					  // 0
{"ipaddr",		  kString,	  kWRITE,				  (int*)&ip_address},						  // 1
{"cputemp", 	  kInteger,   kWRITE,				  (int*)&CPUtemp},							  // 2
{"cpumem",		  kInteger,   kWRITE,				  (int*)&CPUMem},						  // 3
{"cpuload", 	  kInteger,   kWRITE,				  (int*)&CPULoad},							  // 4
{"reboot",		  kInteger,   kWRITE|kREAD|kINIT,	  (int*)&RebootCount},						  // 5	
{"tick",		  kInteger,   kWRITE|kREAD|kINIT,	  (int*)&CPUTick},							  // 6
{"input",		  kInteger,   kWRITE|kREAD, 		  (int*)&IOdatVir.Input.InputDat[0]},		  // 7
{"output",		  kInteger,   kWRITE|kREAD, 		  (int*)&IOdatVir.Output.OutputDat[0]}, 	  // 8
#endif

#if 0
enum eTypeVar{
	kBoolean,
	kShort,
	kUShort,
	kInteger,
	kFloat,
	kString,
	kIntegerRev,
	kFloatRev,
	kMaxTypeVar,
};


enum eModeVar{
	kNONE_MODE,
	kREAD_NONE,
	kWRITE_NONE,
	kINIT_MODE,
	kMaxMode,
};


enum eVarTarget{
	kTCPCLIENT_Target,
	kTCPSERVER_Target,
	kCOM_Target,
	kSYSTEM_Target,
	kMax_Target,
};

enum eStateCache{
	kCacheInit,
	kCacheGetInitValue,
	kCachePreset,
	kCacheUpdate,
	
};

#endif

union uVarMemCache{
	int				IntegerVar;
	float			FloatVar;
	char			BuffStr[kMaxString];
};


/*
union uVarGlobal{
	unsigned char	vChar;
	int				vInt;
	float			vFloat;
	unsigned short	vUShort;
	short			vShort;
	unsigned short	vBuffUShort[2];
};
*/

/*
struct stDataMemCache{
	char 				pStr[kMaxLenCacheId];
	enum eTypeVar		TypeVar;
	unsigned short		Mode;
	int 				*pInt;
	int					*pIntTarget;
	enum eVarTarget		VarTarget;
	int					Idx;
	int					Addr;
};
*/

extern const struct stDataMemCache 	kTblCacheWR[];
extern int							IdxTCPModbusClient;
#define kTotalWriteMemCache			(sizeof(kTblCacheWR)/sizeof(struct stDataMemCache))
//extern enum eStateCache				RDStat[];

int InitWEBClient(void);
int WEBMemcacheTX(int Idx, int IdxVar);
void WEBMemcacheRX(int Idx, int IdxVar, int TotBuffRecv);
int WEBClientProcessTX(int Idx, int IDVar);
void WEBClientProcessRX(int Idx, int IDVar, int TotBuffRecv);
#endif
