#ifndef CACHE_H
#define CACHE_H

#define kMaxCacheVar	16384
#define kMaxLenCacheId	32

#define kNONE			0x00
#define kREAD			0x01
#define kWRITE			0x02
#define kINIT			0x04
#define kID				0x08
#define kGPS_CACHE		0x10


#define kMACAddr_id		0
#define kIPADD_id		1
#define kCPUTEMP_id		2
#define kCPUMEM_id		3
#define kCPULOAD_id		4
#define kREBOOT_id		5
#define kCPUTICK_id		6
#define kINPUT_id		7
#define kOUTPUT_id		8


enum eTypeVar{
	kBoolean,
	kShort,
	kUShort,
	kInteger,
	kFloat,
	kString,
	kIntegerRev,
	kFloatRev,
	kMaxTypeVar,
};


enum eModeVar{
	kNONE_MODE,
	kREAD_NONE,
	kWRITE_NONE,
	kINIT_MODE,
	kMaxMode,
};

enum eVarTarget{
	kTCPCLIENT_Target,
	kTCPSERVER_Target,
	kCOM_Target,
	kSYSTEM_Target,
	kMax_Target,
};

enum eStateCache{
	kCacheInit,
	kCacheGetInitValue,
	kCachePreset,
	kCacheUpdate,
	
};


struct stDataMemCache{
	char 				pStr[kMaxLenCacheId];
	enum eTypeVar		TypeVar;
	unsigned short		Mode;
	int 				*pInt;
	int					*pIntTarget;
	enum eVarTarget		VarTarget;
	int					Idx;
	int					Addr;
};

union uVarGlobal{
	unsigned char	vChar;
	int				vInt;
	float			vFloat;
	unsigned short	vUShort;
	short			vShort;
	unsigned short	vBuffUShort[2];
};



extern char					CacheConfig[];
extern struct stDataMemCache 	VarCache[kMaxCacheVar];
#define kTotalWrMemCache		(sizeof(kTblCacheW)/sizeof(struct stDataMemCache))
extern int						totcache;
extern const char kTblTypeVar[kMaxTypeVar][kMaxLenCacheId];
extern const char kTblModeVar[kMaxMode][kMaxLenCacheId];
extern const char kTblTargetVar[kMax_Target][kMaxLenCacheId];
extern enum eStateCache				RDStat[];


void InitCache(void);
int GetSizeVarCache(void);
void OpenCache(void);
void StopCache(void);



#endif
