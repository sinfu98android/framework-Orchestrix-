#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gps.h"
#include "System.h"
#include "UART.h"
#include "webstring.h"


#define kGPRMC_TIME				1
#define kGPRMC_VALID			2
#define kGPRMC_LATITUDE			3
#define kGPRMC_LATITUDE_DIR		4
#define kGPRMC_LONGITUDE		5
#define kGPRMC_LONGITUDE_DIR	6
#define kGPRMC_SPEED			7
#define kGPRMC_DATE				9

#define kGPGGA_ALTITUDE			9
#define kGPGGA_ALTITUDE_UNIT	10



const char kGPRMC[]="$GPRMC";
const char kGPGGA[]="$GPGGA";

char	TimeStr[kStrGPS];
char 	LatitudeStr[kStrGPS];
char 	LongitudeStr[kStrGPS];
char 	AltitudeStr[kStrGPS];
char 	SpeedStr[kStrGPS];
//float  	Latitude, Longitude, Altitude,Speed;

void InitGPS(unsigned char idx)
{
 memset((char*)&TimeStr, 0, sizeof(TimeStr));
 memset((char*)&LatitudeStr, 0, sizeof(LatitudeStr));
 memset((char*)&LongitudeStr, 0, sizeof(LongitudeStr));
 memset((char*)&AltitudeStr, 0, sizeof(AltitudeStr));
 memset((char*)&SpeedStr, 0, sizeof(SpeedStr)); 
}

void GPSProcess(unsigned char idx)
{
 short totlinegps=0;
 //short totsplitgps=0;
 struct stSplit BuffParse;
 struct stSplit BuffSplit;
 short i;
 
 if (UARTRdy[idx])
    {
	 if (ReceiveComplete[idx])
	    {
	 	 UART_RESPONE[idx]=kTRUE;
		 TrialRespone[idx]=0;
		 ReceiveComplete[idx]=kFALSE;
		 memset((char*)&BuffParse, 0, sizeof(BuffParse));
		 totlinegps=SplitLine((char*)BuffRX[idx], (struct stSplit*)&BuffParse);
		 for (i=0; i<totlinegps; i++)
		 	{
		 	 //printf("%s\r\n", (char*)BuffParse.str[i]);
			 memset((char*)&BuffSplit, 0, sizeof(BuffSplit));
			 SplitString((char*)&BuffParse.str[i], (struct stSplit*)&BuffSplit, ',');
		 	 if (CmpStr((char*)kGPRMC, (char*)BuffSplit.str[0]))
		 	 	{
		 	 	 memset((char*)&TimeStr, 0, sizeof(TimeStr));
				 memset((char*)&LatitudeStr, 0, sizeof(LatitudeStr));
				 memset((char*)&LongitudeStr, 0, sizeof(LongitudeStr));
				 memset((char*)&SpeedStr, 0, sizeof(SpeedStr));
				 
				 strcat((char*)TimeStr, (char *)BuffSplit.str[kGPRMC_TIME]);
				 strcat((char*)LatitudeStr, (char *)BuffSplit.str[kGPRMC_LATITUDE]);
				 strcat((char*)LatitudeStr, (char *)BuffSplit.str[kGPRMC_LATITUDE_DIR]);
				 strcat((char*)LongitudeStr, (char *)BuffSplit.str[kGPRMC_LONGITUDE]);
				 strcat((char*)LongitudeStr, (char *)BuffSplit.str[kGPRMC_LONGITUDE_DIR]);
				 strcat((char*)SpeedStr, (char *)BuffSplit.str[kGPRMC_SPEED]);			 
		 	 	}
		 	 if (CmpStr((char*)kGPGGA, (char*)BuffSplit.str[0]))
		 	 	{
				 memset((char*)&AltitudeStr, 0, sizeof(AltitudeStr));
				 strcat((char*)AltitudeStr, (char *)BuffSplit.str[kGPGGA_ALTITUDE]);
				 strcat((char*)AltitudeStr, (char *)BuffSplit.str[kGPGGA_ALTITUDE_UNIT]);
		 	 	}			 
		 	}
#if 0
		 printf("TIME NOW: %s\r\n", (char*)TimeStr);
		 printf("LATITUDE: %s\r\n", (char*)LatitudeStr);
		 printf("LONGITUDE: %s\r\n", (char*)LongitudeStr);
		 printf("ALTITUDE: %s\r\n", (char*)AltitudeStr);		 
		 printf("Speed: %s\r\n", (char*)SpeedStr);		 
		 printf("\r\n");
#endif		 
		 TickCOM_[idx]++;
		 ptrRX[idx]=0;
		 TrialRespone[idx]=0;
		}
	if (FlagsSystem.Tick100mS)
	   {
	    //printf("TrialRespone GPS: %d\r\n", TrialRespone[idx]);
		TrialRespone[idx]++;
		if (TrialRespone[idx]>20)
		   {
		    printf("Closing GPS UART %d\r\n", idx);
			UARTRdy[idx]=kFALSE;
			UART_RESPONE[idx]=kFALSE;
			CloseUART(idx);
		   }
	   }
   }
}


