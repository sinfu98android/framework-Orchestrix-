#ifndef GPS_H
#define GPS_H
#define kStrGPS		64


extern char	TimeStr[kStrGPS];
extern char	LatitudeStr[kStrGPS];
extern char	LongitudeStr[kStrGPS];
extern char	AltitudeStr[kStrGPS];
extern char	SpeedStr[kStrGPS];


void InitGPS(unsigned char idx);
void GPSProcess(unsigned char idx);

#endif
