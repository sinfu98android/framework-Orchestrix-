#include "logfile.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "webstring.h"

#define BUFF_DBG_SIZE	4096

char BuffDBG[BUFF_DBG_SIZE];
char Logfile[]="/var/www/html/program/log.log";


// MakeSureFileExist((char*)&CacheConfig);
void PrintLog(char* str)
{
 MakeSureFileExist((char*)Logfile);

 FILE *fp = fopen((char*)Logfile, "a");  // Open file for writing
 if (fp == NULL)
 	{
	 perror("Error opening file");
	 return;
	}
fprintf(fp, str);
fclose(fp);
}


void debugPrintf(const char *fmt, ...)
{
 return;
 
 va_list args;
 va_start(args, fmt);

 memset(BuffDBG, 0, sizeof(BuffDBG));
 while (*fmt != '\0')
	{
	 if (*fmt=='%')
	 	{
	 	 fmt++;
	   	 if (*fmt == 'd')
			{
	       	 int i = va_arg(args, int);
			 snprintf(BuffDBG, sizeof(BuffDBG), "%d", i);
		    }
		 else if (*fmt == 's') 
		 	{
		   	 char* strx = va_arg(args, char*);
			 snprintf(BuffDBG, sizeof(BuffDBG), "%s", strx);
	       	} 
		else if (*fmt == 'f')
			{
			 double d = va_arg(args, double);
		 	 snprintf(BuffDBG, sizeof(BuffDBG), "%f", d);
        	}
		 }
	else
		{
		 BuffDBG[0]=*fmt;
		}
    fmt++;
   }
 printf("---------->  %s\r\n", (char*)BuffDBG);
// PrintLog((char*)BuffDBG); 
 va_end(args);
}


