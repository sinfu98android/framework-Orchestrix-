#ifndef LOGFILE_H
#define LOGFILE_H


void PrintLog(char* str);
void debugPrintf(const char *fmt, ...);



#endif
