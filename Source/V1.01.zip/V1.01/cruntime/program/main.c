#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include "timer.h"
#include <signal.h>
#include "System.h"
#include "IOProcess.h"
#include <fcntl.h>   /* File Control Definitions           */
#include <termios.h> /* POSIX Terminal Control Definitions */
#include <errno.h>   /* ERROR Number Definitions           */
#include "UART.h"
//#include "UART2.h"
#include "Modbus.h"
#include <pthread.h>
#include "ModbusTCP.h"
#include <time.h>
#include "Control.h"
#include "PLCProtocol.h"
#include "Handling.h"
#include "Printer.h"
#include "CheckMACAddr.h"
#include "Email.h"
#include "MySQLClient.h"
#include "TCPClient.h"
#include "WEBClient.h"
#include "TCPModbus.h"
#include "rfid.h"
#include "Project.h"
#include "ADS1256.h"
#include "ParalelLPT.h" 
#include "cache.h"



char				LoggingConfig[]="/var/www/html/program/logging.txt";


unsigned char 		Quit;
pthread_t 			id, id2, id3, id4, id5, id6, id7, id8, id9;
int					test;
int 				TimeoutCOM;
unsigned char		DetectSensor=kTRUE;




void CreateTaskModbusServer(void);
void KillTaskModbusServer(void);


void timer_handler(void)
{
// TickSystem=kTRUE;
}


void CheckNewFileLog(void)
{
 //return;

 FILE *fptr;
 struct stSplit BuffParse;
// struct stSplit BuffSplit;
 int res;
 int totline=0;
 short n;

 MakeSureFileExist((char*)&LoggingConfig); 
 res=findSize(LoggingConfig);
 if (res<=0) return;
 char myString[res+10];
// char myString[1000];
 memset(myString, 0, sizeof(myString));
 for (n=0; n<kMaxString; n++) memset(BuffParse.str[n], 0, sizeof(BuffParse.str[n]));

 fptr = fopen(LoggingConfig, "r");
 fread(myString, sizeof(myString), 1, fptr);
 fclose(fptr); 
 //for (n=0; n<res; n++) printf("%02x, ", myString[n]);
 //printf("\r\n");
 totline=SplitLine((char*)myString, (struct stSplit*)&BuffParse);
 printf("Size: %d, Total Line: %d\r\n", res, totline);
 for (n=0; n<totline; n++)
 	{
 	 printf("Line: %d ---> %s\r\n", n, (char*)&BuffParse.str[n]);
     MakeSureFileExist((char*)&BuffParse.str[n]); 
 	}
}



double get_mem(void)
{
 const int BUFFER_SIZE = 2048;
 char data[BUFFER_SIZE];
 FILE *finput;
 struct stSplit BuffSplit;
 int n, i;
	
 double cpumem=0, memtot=0, active=0;
	 
 finput = fopen("/proc/meminfo","r");		// finput = fopen("cat /proc/meminfo","r");
 if (finput != NULL)
 	{
 	 memset(data,0,BUFFER_SIZE);
 	 fread(data,BUFFER_SIZE,1,finput);
 	 fclose(finput);
	 memset((char*)BuffSplit.str,0, sizeof(BuffSplit));
	 n=SplitString((char*)data, (struct stSplit*)&BuffSplit, ' ');
//	 printf("%s, %s, %s, %s, %s, %s,\r\n", (char*)BuffSplit.str[0], (char*)BuffSplit.str[1], (char*)BuffSplit.str[2], (char*)BuffSplit.str[3], (char*)BuffSplit.str[4], (char*)BuffSplit.str[5]);
	 if (n>9)
	 	{
	 	 i=GetIdxSplitStr((char*)kStrMemTot, (struct stSplit*)&BuffSplit);
		 if (strlen(BuffSplit.str[i+1])>0)
		 	{
		 	 memtot=atoi(BuffSplit.str[i+1]);
		 	}
		 i=GetIdxSplitStr((char*)kStrMemActive, (struct stSplit*)&BuffSplit);
//		 printf("Location: %d\r\n", i);
		 if (strlen(BuffSplit.str[i+1])>0)
		 	{
		 	 //memfree=atoi(BuffSplit.str[i+1]);
		 	 active=atoi(BuffSplit.str[i+1]);
		 	}
//		 printf("Memory: %f  %f\r\n", memfree, memtot);
//		 cpumem=memtot-memfree;
		 cpumem=(active*100)/memtot;
	 	}
 	}
 return cpumem;
}



typedef struct {
    unsigned long long user, nice, system, idle, iowait, irq, softirq, steal;
} CPUStats;

CPUStats get_cpu_stats() {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    CPUStats stats = {0};
    fscanf(fp, "cpu  %llu %llu %llu %llu %llu %llu %llu %llu",
           &stats.user, &stats.nice, &stats.system, &stats.idle,
           &stats.iowait, &stats.irq, &stats.softirq, &stats.steal);

    fclose(fp);
    return stats;
}

double get_cpu() {
    CPUStats s1 = get_cpu_stats();
    sleep(1);  // measure over 1 second
    CPUStats s2 = get_cpu_stats();

    unsigned long long idle1 = s1.idle + s1.iowait;
    unsigned long long idle2 = s2.idle + s2.iowait;

    unsigned long long non_idle1 = s1.user + s1.nice + s1.system +
                                   s1.irq + s1.softirq + s1.steal;
    unsigned long long non_idle2 = s2.user + s2.nice + s2.system +
                                   s2.irq + s2.softirq + s2.steal;

    unsigned long long total1 = idle1 + non_idle1;
    unsigned long long total2 = idle2 + non_idle2;

    unsigned long long total_diff = total2 - total1;
    unsigned long long idle_diff = idle2 - idle1;

    double cpu_percentage = (double)(total_diff - idle_diff) / total_diff * 100.0;

    printf("CPU Usage: %.2f%%\n", cpu_percentage);

    return 0;
}

/*
double get_cpu(void)
{
 const int BUFFER_SIZE = 2048;
 char data[BUFFER_SIZE];
 FILE *finput;
 struct stSplit	BuffSplit;
 int n, i;
 double totalcpu=0, cpuval=0;
 static double BuffVal[6];
 static double BuffValLast[6];
 
  //	"/proc/meminfo"
  //	"/proc/uptime"
  
 finput = fopen("/proc/stat","r");		// finput = fopen("cat /proc/stat","r");
 if (finput != NULL) {
   memset(data,0,BUFFER_SIZE);
   fread(data,BUFFER_SIZE,1,finput);
   fclose(finput);
   memset((char*)BuffSplit.str,0, sizeof(BuffSplit));
   //printf("%s", (char*)data);
   n=SplitString((char*)data, (struct stSplit*)&BuffSplit, ' ');
   if (n>8)
   	  {
	   i=GetIdxSplitStr((char*)kStrCPU, (struct stSplit*)&BuffSplit);
	   i++;
	   if ((strlen(BuffSplit.str[i])>0)&&(strlen(BuffSplit.str[i+1])>0)&&
	   	   (strlen(BuffSplit.str[i+2])>0)&&(strlen(BuffSplit.str[i+3])>0)&&
	   	   (strlen(BuffSplit.str[i+4])>0)&&(strlen(BuffSplit.str[i+5])>0)&&
	   	   (strlen(BuffSplit.str[i+6])>0))
	   	     {
	   	      totalcpu=0;
	   	      for (n=0; n<6; n++)
	   	      	{
		   	     BuffVal[n]=atoi(BuffSplit.str[i+n]);
				 totalcpu+=BuffVal[n]-BuffValLast[n];
				 if (n==3) cpuval=BuffVal[n]-BuffValLast[n];
				 BuffValLast[n]=BuffVal[n];
	   	      	}
			  cpuval/=totalcpu;
			  cpuval=100-(cpuval*100);
			  //printf("%f, %f, %f, %f, %f, %f\r\n", BuffCPU[0], BuffCPU[1], BuffCPU[2], BuffCPU[3], BuffCPU[4], BuffCPU[5]);
	   	  	 }
   	  }
  }
 return cpuval;
}
*/

double get_temp(void)
{
 const int BUFFER_SIZE = 100;
 char data[BUFFER_SIZE];
 FILE *finput;

 double temp;
  
 finput = fopen("/sys/class/thermal/thermal_zone0/temp","r");	// finput = fopen("cat /sys/class/thermal/thermal_zone0/temp","r");
 if (finput != NULL) {
   memset(data,0,BUFFER_SIZE);
   fread(data,BUFFER_SIZE,1,finput);
   temp = atoi(data);
   temp /= 1000;
   fclose(finput);
  }
  return temp;
}



void* threadFunction(void* args)
{
	 TimeoutCOM=0;
		while(1)
		{
#if 0    
			CPUtemp=(int)get_temp();
			CPULoad=(int)get_cpu();
			CPUMem=(int)get_mem();
#endif		
//			printf("CPU Load: %d   Mem:%d,	Temp:%d\r\n", CPULoad, CPUMem, CPUtemp);

//			MakeSureFileExist((char*)&LoggingConfig);
//			CheckNewFileLog();
			//QuitSystem=kTRUE;
			sleep(5);
		}
 return 0;
}



void InitThread(void)
{
// pthread_t id, id2, id3, id4;
 int ret;
   
    /*creating thread*/
 ret=pthread_create(&id,NULL,&threadFunction,NULL);
 if(ret==0) printf("USER created successfully.\r\n");
 else
 	{
     printf("USER Thread not created.\n");
     return; /*return from main*/
    }

#if 1
 ret=pthread_create(&id2,NULL,&ControlProcess,NULL);
 if(ret==0) printf("Control created successfully.\r\n");
 else
 	{
     printf("Control Thread not created.\n");
     return; /*return from main*/
    }
#endif

#ifdef ORANGEPI
 ret=pthread_create(&id4,NULL,&ADS1256Task,NULL);
 if(ret==0) printf("ADS1256 created successfully.\r\n");
 else
 	{
     printf("ADS1256 Thread not created.\n");
     return; /*return from main*/
    } 
#endif


#if 0
 ret=pthread_create(&id5,NULL,&ReceiveUART,NULL);
 if(ret==0) printf("RX UART created successfully.\r\n");
 else
 	{
     printf("RX UART Thread not created.\n");
     return; /*return from main*/
    } 
 #endif

#if 0 
 ret=pthread_create(&id6,NULL,&ModbusServer,NULL);
 if(ret==0) printf("Modbus TCP created successfully.\r\n");
 else
 	{
     printf("Modbus TCP Thread not created.\n");
     return; /*return from main*/
    } 
#endif
 
#if 0
 ret=pthread_create(&id7,NULL,&MySQLTask,NULL);
 if(ret==0) printf("MySQLTask created successfully.\r\n");
 else
 	{
     printf("MySQLTask Thread not created.\n");
     return; /*return from main*/
    } 
#endif

#if 0
 ret=pthread_create(&id8,NULL,&Printer,NULL);
 if(ret==0) printf("Printer Service created successfully.\r\n");
 else
 	{
     printf("Printer Service Thread not created.\n");
     return; /*return from main*/
    } 
#endif

#if 0
  ret=pthread_create(&id4,NULL,&HandlingTask,NULL);
  if(ret==0) printf("HandlingTask successfully.\r\n");
  else
	 {
	  printf("HandlingTask not created.\n");
	  return; /*return from main*/
	 } 
#endif  
}



void KillAllThread(void)
{
 pthread_exit(&id);
 pthread_exit(&id2);
 pthread_exit(&id3);
 pthread_exit(&id4);
 pthread_exit(&id5);
 pthread_exit(&id6);
 pthread_exit(&id7);
 pthread_exit(&id8);
 pthread_exit(&id9);
 printf("All Threads Termintaed \r\n"); 
}

#if 0
int findSize(char file_name[]) 
{ 
    // opening the file in read mode 
    FILE* fp = fopen(file_name, "r"); 
  
    // checking if the file exist or not 
    if (fp == NULL) { 
        printf("File Not Found!\n"); 
        return -1; 
    } 
  
    fseek(fp, 0L, SEEK_END); 
  
    // calculating the size of the file 
    long int res = ftell(fp); 
  
    // closing the file 
    fclose(fp); 
  
    return res; 
} 
#endif

#if 0
void OpenConfig(void)
{
 FILE *fptr;
 int res = findSize("/var/www/html/program/code1.txt");
 char myString[res+1];
 
 memset(myString, 0, sizeof(myString));
 
 fptr = fopen("/var/www/html/program/code1.txt", "r");
 fread(myString, sizeof(myString), 1, fptr);
 printf("%s\r\n", myString);
 fclose(fptr);
 printf("\r\n");
}
#endif


void WaitMACAddress(void)
{
 int retries = 0;
 const int max_retries = 30; // e.g., 20 seconds total if sleep 100ms
	
 while (1)
	{
	 CheckMACAddr(); // fills mac_address and ethName

	 if (mac_addressstr[0] != 0)
		{ // we got a MAC
		 printf("MAC ready: %s\n", mac_addressstr);
		 break;
		}
	 sleep(1); // 0.1s
	 retries++;
	 if (retries >= max_retries)
		{
		 fprintf(stderr, "Failed to get MAC after %d retries\n", retries);
		 exit(1);
		}
	}  
}


int main()
{
// OpenConfig();
 CheckNewFileLog();
 InitSystem();
 WaitMACAddress();
 FirstInitUART();
 InitPLCProtocol();
// InitWEBClient();
// InitThreadModbusTCP();
 InitIO();
// InitRFID();
// InitMySQL();

 InitCache();
// if (start_timer(10000, &timer_handler)) exit(1);
 InitThread();
 test=0;
 while (1) 
	{
	 sleep(2);
	 if (QuitSystem) break;
 	}
 printf("Quit System....\r\n");
 KillAllThread(); 
 stop_timer();
 exit(0);
}

