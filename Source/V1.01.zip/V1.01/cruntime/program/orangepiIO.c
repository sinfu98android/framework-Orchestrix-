#include "orangepiIO.h"
#include "IOProcess.h"
#ifdef ORANGEPI
	#include <armbianio.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#include <sys/io.h>
#include <sys/types.h>
#include <fcntl.h>
#include "IOProcess.h"
#include "Control.h"
#include <time.h>
#include "MiscDataConv.h"
#include "PLCProtocol.h"
#include <sys/types.h>

#ifdef ORANGEPI
void SetCLK_HI(void)
{
 AIOWriteGPIO(kCLK, 1);
}

void SetCLK_LO(void)
{
 AIOWriteGPIO(kCLK, 0);
}

void SetLACTH_HI(void)
{
 AIOWriteGPIO(kLATCH, 1);
}

void SetLACTH_LO(void)
{
  AIOWriteGPIO(kLATCH, 0);
}

void SetDAT_HI(void)
{
 AIOWriteGPIO(kMOSI, 1);
}

void SetDAT_LO(void)
{
  AIOWriteGPIO(kMOSI, 0);
}


void InitOrangepiIO(void)
{
 int rc;
 const char *szBoardName;
	 
 rc = AIOInit();
 if (rc == 0)
	{
		printf("Problem initializing ArmbianIO library\r\n");
		return;
	}
szBoardName = AIOGetBoardName();
printf("Running on a %s\r\n", szBoardName);
	
AIOAddGPIO(kCLK, GPIO_OUT);
AIOAddGPIO(kMOSI, GPIO_OUT);
AIOAddGPIO(kLATCH, GPIO_OUT);
AIOAddGPIO(kMISO, GPIO_IN);
//AIOAddGPIO(kGETINPUT, GPIO_IN);
}


void UpdateSerIO(void)
{
 unsigned int n;//, i;
 unsigned char temp;
 signed char idx;
// unsigned char counthi, countlo;
// unsigned char tempbit, count;

 SetLACTH_LO(); 
 for (idx=1; idx>=0; idx--)
	{
	 temp=IOdat.Output.OutByte[idx];
	 for (n=0; n<8; n++)
		{
		 if (temp & 0x80) SetDAT_LO();
		 else SetDAT_HI();
		 SetCLK_HI();
		 SetCLK_LO();
		 temp=temp<<1;
		}
	}
 SetLACTH_HI();
 SetLACTH_HI();
 SetLACTH_HI();
 SetLACTH_HI();
 SetLACTH_LO();
 SetLACTH_LO();
 
// for (idx=0; idx<kMaxInput; idx++)
 for (idx=0; idx<2; idx++)
 	{
 	 temp=0;
 	 for (n=0; n<8; n++)
		{
		 temp=temp<<1;
		 if (AIOReadGPIO(kMISO)) temp|=0x01;
		 SetCLK_HI();
		 SetCLK_LO();
 	 	}
	 temp=~temp;
	 IOdat.Input.InByte[idx]|=temp;
 	}
// printf("tick: %d, logic: %02x, %02x, %02x, %02x, %02x, %02x, %02x, %02x, %02x, %02x,\r\n", tickIO++, IOdat.Input.InByte[0], IOdat.Input.InByte[1], IOdat.Input.InByte[2], IOdat.Input.InByte[3], IOdat.Input.InByte[4], IOdat.Input.InByte[5], IOdat.Input.InByte[6], IOdat.Input.InByte[7], IOdat.Input.InByte[8], IOdat.Input.InByte[9]);
}
#endif
