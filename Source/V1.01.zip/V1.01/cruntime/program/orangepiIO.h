#ifndef ORANGEPIIO_H
#define ORANGEPIIO_H

#define ORANGEPI4LTS

#ifdef ORANGEPI4LTS
	#define kCLK		23	//14	//6
	#define kMOSI		19
	#define kMISO		21		//21
	#define kLATCH		8
#endif

void InitOrangepiIO(void);
void UpdateSerIO(void);

#endif
