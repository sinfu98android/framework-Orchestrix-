#include "rfid.h"
#ifdef ORANGEPI
#include <armbianio.h>
#endif
#include <pthread.h>
#include "System.h"
#include <unistd.h>
#include <stdint.h>
#include <string.h>


#define kRFID_STAT		26
#define kRFID_CS			10		//29
#define kRFID_CLK		7		//31
#define kRFID_MOSI		5		//33
#define kRFID_MISO		3		//35
#define kRFID_RST		8


#define DISP_COMMANDLINE()	printf("RC522>")
pthread_t 			rfid_handle;
long long int  			IDcard, IDcard_;
unsigned char 		timeout;
int					Counting;
enum eRFIDState 		RFIDState=kIdleRFID;
enum eRFIDState 		RFIDState_r=kIdleRFID;


void MFRC522_HAL_Delay(int delay)
{
 usleep(delay*1000);
}

void SetRFID_RST_HI(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_RST, 1);
#endif
}


void SetRFID_RST_LO(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_RST, 0);
#endif
}


void SetRFID_MOSI_HI(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_MOSI, 1);
#endif
}


void SetRFID_MOSI_LO(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_MOSI, 0);
#endif
}


void SetRFID_CLK_HI(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_CLK, 1);
#endif
}

void SetRFID_CLK_LO(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_CLK, 0);
#endif
}


void SetRFID_CS_HI(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_CS, 1);
#endif
}

void SetRFID_CS_LO(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_CS, 0);
#endif
}

void SetRFID_STAT_HI(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_STAT, 1);
#endif
}

void SetRFID_STAT_LO(void)
{
#ifdef ORANGEPI
 AIOWriteGPIO(kRFID_STAT, 0);
#endif
}

void InitRFID(void)
{
 int ret;

#ifdef ORANGEPI
 AIOAddGPIO(kRFID_CLK, GPIO_OUT);
 AIOAddGPIO(kRFID_MOSI, GPIO_OUT);
 AIOAddGPIO(kRFID_CS, GPIO_OUT); 
 AIOAddGPIO(kRFID_MISO, GPIO_IN);
 AIOAddGPIO(kRFID_RST, GPIO_OUT);
 AIOAddGPIO(kRFID_STAT, GPIO_OUT);
#endif 
 printf("Init RFID OK...\r\n");
 SetRFID_CS_HI();
 SetRFID_CLK_LO();
 SetRFID_RST_LO();
 SetRFID_STAT_LO();

 ret=pthread_create(&rfid_handle,NULL,&RFIDProcess,NULL);
 if(ret==0) printf("RFID created successfully.\r\n");
 else
 	{
     printf("RFID Thread not created.\n");
     return; /*return from main*/
    } 
}


unsigned char ReadWriteByte(unsigned char dataWR)		// MSB first
{
 unsigned char dataRD, temp;
 unsigned char n;

 dataRD=0;
 temp=dataWR;
 for (n=0; n<8; n++)
 	{
 	 if (temp & 0x80) SetRFID_MOSI_HI();
	 else SetRFID_MOSI_LO();
	 temp=temp<<1;
	 SetRFID_CLK_HI();
	 dataRD=dataRD<<1;
	 #ifdef ORANGEPI
		 if (AIOReadGPIO(kRFID_MISO)) dataRD|=0x01;
	 #endif
	 SetRFID_CLK_LO();
 	}
 return(dataRD);
}


void WriteSPI_RFID(unsigned char addr, unsigned char val)
{
 char _dummytx[2];
// static char _devnull[2];
 unsigned char n,  totaldat;
 
 _dummytx[0] = (addr << 1) & 0x7E;
 _dummytx[1] = val;

 totaldat=2;
 SetRFID_CS_LO();
 for (n=0; n<totaldat; n++)
 	{
	 ReadWriteByte(_dummytx[n]);
 	}
 SetRFID_CS_HI(); 
}


unsigned char ReadSPI_RFID(unsigned char addr)
{
 char _dummytx[2];
 char _rxbuf[2];
 unsigned char n,  totaldat;
 
 _dummytx[0] = ((addr << 1) & 0x7E)|0x80;
 _dummytx[1] = 0x00;

 totaldat=2;
 SetRFID_CS_LO();
 for (n=0; n<totaldat; n++)
 	{
	 _rxbuf[n]=ReadWriteByte(_dummytx[n]);
 	}
 SetRFID_CS_HI(); 
 return(_rxbuf[1]);
}


static int Checking_Card = 0;
int MFRC522_Setup(char Type){
	MFRC522_Reset();
	sleep(1);
//	MFRC522_HAL_Delay(200);

	MFRC522_WriteRegister(MFRC522_REG_T_PRESCALER, 0x3E);
#ifndef NOTEST
	{
		/* test read and write reg functions */
		volatile char test;
		test = MFRC522_ReadRegister(MFRC522_REG_T_PRESCALER);
		if (test != 0x3E) {
			return -1;
		}
	}
#endif
	MFRC522_WriteRegister(MFRC522_REG_T_MODE, 0x8D);
	MFRC522_WriteRegister(MFRC522_REG_T_RELOAD_L, 30);
	MFRC522_WriteRegister(MFRC522_REG_T_RELOAD_H, 0);
	MFRC522_WriteRegister(MFRC522_REG_TX_AUTO, 0x40);
	MFRC522_WriteRegister(MFRC522_REG_MODE, 0x3D);
	if (Type == 'A') {
		MFRC522_ClearBitMask(MFRC522_REG_STATUS2, 0x08);
		MFRC522_WriteRegister(MFRC522_REG_MODE, 0x3D);
		MFRC522_WriteRegister(MFRC522_REG_RX_SELL, 0x86);
		MFRC522_WriteRegister(MFRC522_REG_RF_CFG, 0x7F);
		MFRC522_WriteRegister(MFRC522_REG_T_RELOAD_L, 30);
		MFRC522_WriteRegister(MFRC522_REG_T_RELOAD_H, 0);
		MFRC522_WriteRegister(MFRC522_REG_T_MODE, 0x8D);
		MFRC522_WriteRegister(MFRC522_REG_T_PRESCALER, 0x3E);
	}
	MFRC522_AntennaOn();		//Open the antenna
	return 0;
}


int MFRC522_Init(char Type) {

//	MFRC522_HAL_init();

	return MFRC522_Setup(Type);
}

MFRC522_Status_t MFRC522_Check(uint8_t* id) {
	MFRC522_Status_t status;
	/* Must Clear Bit MFCrypto1On in Status2 reg in order to return to the card detect mode*/
	MFRC522_ClearBitMask(MFRC522_REG_STATUS2,(1<<3));
	Checking_Card = 1;
	//Find cards, return card type
	status = MFRC522_Request(PICC_CMD_WUPA, id);
	Checking_Card = 0;
	if (status == MI_OK) {
		//Card detected
		//Anti-collision, return card serial number 4 bytes
		status = MFRC522_Anticoll(id);
	}
	return status;
}

MFRC522_Status_t MFRC522_Compare(uint8_t* CardID, uint8_t* CompareID) {
	uint8_t i;
	for (i = 0; i < 5; i++) {
		if (CardID[i] != CompareID[i]) {
			return MI_ERR;
		}
	}
	return MI_OK;
}

void MFRC522_WriteRegister(uint8_t addr, uint8_t val) {
	WriteSPI_RFID(addr, val);
}

uint8_t MFRC522_ReadRegister(uint8_t addr) {
	return ReadSPI_RFID(addr);
}

void MFRC522_SetBitMask(uint8_t reg, uint8_t mask) {
	MFRC522_WriteRegister(reg, MFRC522_ReadRegister(reg) | mask);
}

void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask) {
	MFRC522_WriteRegister(reg, MFRC522_ReadRegister(reg) & (~mask));
}

void MFRC522_AntennaOn(void) {
	uint8_t temp;

	temp = MFRC522_ReadRegister(MFRC522_REG_TX_CONTROL);
	if (!(temp & 0x03)) {
		MFRC522_SetBitMask(MFRC522_REG_TX_CONTROL, 0x03);
	}
}

void MFRC522_AntennaOff(void) {
	MFRC522_ClearBitMask(MFRC522_REG_TX_CONTROL, 0x03);
}

void MFRC522_Reset(void) {
	MFRC522_WriteRegister(MFRC522_REG_COMMAND, PCD_RESETPHASE);
}

MFRC522_Status_t MFRC522_Request(uint8_t reqMode, uint8_t* TagType) {
	MFRC522_Status_t status;
	uint16_t backBits;			//The received data bits

	MFRC522_WriteRegister(MFRC522_REG_BIT_FRAMING, 0x07);//TxLastBists = BitFramingReg[2..0]	???

	TagType[0] = reqMode;
	status = MFRC522_ToCard(PCD_TRANSCEIVE, TagType, 1, TagType, &backBits);

	if ((status != MI_OK)) {
		return status;
	}
	if (backBits != 0x10) {
		return MI_ERR;
	}
	return MI_OK;
}

MFRC522_Status_t MFRC522_ToCard(uint8_t command, uint8_t* sendData,
		uint8_t sendLen, uint8_t* backData, uint16_t* backLen) {
	MFRC522_Status_t status = MI_ERR;
	uint8_t irqEn = 0x00;
	uint8_t waitIRq = 0x00;
	uint8_t lastBits;
	uint8_t n;
	uint16_t i;

	switch (command) {
	case PCD_AUTHENT: {
		irqEn = 0x12;
		waitIRq = 0x10;
		break;
	}
	case PCD_TRANSCEIVE: {
		irqEn = 0x77;
		waitIRq = 0x30;
		break;
	}
	default:
		break;
	}

	MFRC522_WriteRegister(MFRC522_REG_COMM_IE_N, irqEn | 0x80);
	MFRC522_ClearBitMask(MFRC522_REG_COMM_IRQ, 0x80);
	MFRC522_SetBitMask(MFRC522_REG_FIFO_LEVEL, 0x80);

	MFRC522_WriteRegister(MFRC522_REG_COMMAND, PCD_IDLE);

	//Writing data to the FIFO
	for (i = 0; i < sendLen; i++) {
		MFRC522_WriteRegister(MFRC522_REG_FIFO_DATA, sendData[i]);
	}

	//Execute the command
	MFRC522_WriteRegister(MFRC522_REG_COMMAND, command);
	if (command == PCD_TRANSCEIVE) {
		MFRC522_SetBitMask(MFRC522_REG_BIT_FRAMING, 0x80);//StartSend=1,transmission of data starts
	}

	//Waiting to receive data to complete
	i = 2000;//i according to the clock frequency adjustment, the operator M1 card maximum waiting time 25ms???
	do {
		//CommIrqReg[7..0]
		//Set1 TxIRq RxIRq IdleIRq HiAlerIRq LoAlertIRq ErrIRq TimerIRq
		if (Checking_Card) {
			MFRC522_HAL_Delay(16);
		} else {
			MFRC522_HAL_Delay(2);
		}
		n = MFRC522_ReadRegister(MFRC522_REG_COMM_IRQ);
		i--;
	} while ((i != 0) && !(n & 0x01) && !(n & waitIRq));

	MFRC522_ClearBitMask(MFRC522_REG_BIT_FRAMING, 0x80);		//StartSend=0

	if (i != 0) {
		if (!(MFRC522_ReadRegister(MFRC522_REG_ERROR) & 0x1B)) {

			if (n & irqEn & 0x01) {
				status = MI_NOTAGERR;
			} else {
				status = MI_OK;
			}

			if (command == PCD_TRANSCEIVE) {
				n = MFRC522_ReadRegister(MFRC522_REG_FIFO_LEVEL);
				lastBits = MFRC522_ReadRegister(MFRC522_REG_CONTROL) & 0x07;
				if (lastBits) {
					*backLen = (n - 1) * 8 + lastBits;
				} else {
					*backLen = n * 8;
				}

				if (n == 0) {
					n = 1;
				}
				if (n > MFRC522_MAX_LEN) {
					n = MFRC522_MAX_LEN;
				}

				//Reading the received data in FIFO
				for (i = 0; i < n; i++) {
					backData[i] = MFRC522_ReadRegister(MFRC522_REG_FIFO_DATA);
				}
			}
		} else {
			status = MI_ERR;
		}
	}

	return status;
}

MFRC522_Status_t MFRC522_Anticoll(uint8_t* serNum) {
	MFRC522_Status_t status;
	uint8_t i;
	uint8_t serNumCheck = 0;
	uint16_t unLen;

	MFRC522_WriteRegister(MFRC522_REG_BIT_FRAMING, 0x00);//TxLastBists = BitFramingReg[2..0]

	serNum[0] = PICC_ANTICOLL;
	serNum[1] = 0x20;
	status = MFRC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen);

	if (status == MI_OK) {
		//Check card serial number
		for (i = 0; i < 4; i++) {
			serNumCheck ^= serNum[i];
		}
		/* check sum with last byte*/
		if (serNumCheck != serNum[i]) {
			status = MI_ERR;
		}
	}
	return status;
}

void MFRC522_CalculateCRC(uint8_t* pIndata, uint8_t len, uint8_t* pOutData) {
	uint8_t i, n;

	MFRC522_ClearBitMask(MFRC522_REG_DIV_IRQ, 0x04);			//CRCIrq = 0
	MFRC522_SetBitMask(MFRC522_REG_FIFO_LEVEL, 0x80);	//Clear the FIFO pointer
	//Write_MFRC522(CommandReg, PCD_IDLE);

	//Writing data to the FIFO	
	for (i = 0; i < len; i++) {
		MFRC522_WriteRegister(MFRC522_REG_FIFO_DATA, *(pIndata + i));
	}
	MFRC522_WriteRegister(MFRC522_REG_COMMAND, PCD_CALCCRC);

	//Wait CRC calculation is complete
	i = 0xFF;
	do {
		n = MFRC522_ReadRegister(MFRC522_REG_DIV_IRQ);
		i--;
	} while ((i != 0) && !(n & 0x04));			//CRCIrq = 1

	//Read CRC calculation result
	pOutData[0] = MFRC522_ReadRegister(MFRC522_REG_CRC_RESULT_L);
	pOutData[1] = MFRC522_ReadRegister(MFRC522_REG_CRC_RESULT_M);
}

uint8_t MFRC522_SelectTag(uint8_t* serNum) {
	uint8_t i;
	MFRC522_Status_t status;
	uint8_t size;
	uint16_t recvBits;
	uint8_t buffer[32] = "";

	buffer[0] = PICC_SElECTTAG;
	buffer[1] = 0x70;
	for (i = 0; i < 5; i++) {
		buffer[i + 2] = *(serNum + i);
	}
	MFRC522_CalculateCRC(buffer, 7, &buffer[7]);	//Fill [7:8] with 2byte CRC
	status = MFRC522_ToCard(PCD_TRANSCEIVE, buffer, 9, buffer, &recvBits);

	if ((status == MI_OK) && (recvBits == 0x18)) {
		size = buffer[0];
	} else {
		size = 0;
	}

	return size;
}

MFRC522_Status_t MFRC522_Auth(uint8_t authMode, uint8_t BlockAddr,
		uint8_t* Sectorkey, uint8_t* serNum) {
	MFRC522_Status_t status;
	uint16_t recvBits;
	uint8_t i;
	uint8_t buff[12];

	//Verify the command block address + sector + password + card serial number
	buff[0] = authMode;
	buff[1] = BlockAddr;
	for (i = 0; i < 6; i++) {
		buff[i + 2] = *(Sectorkey + i);
	}
	for (i = 0; i < 4; i++) {
		buff[i + 8] = *(serNum + i);
	}
	status = MFRC522_ToCard(PCD_AUTHENT, buff, 12, buff, &recvBits);

	if ((status != MI_OK)
			|| (!(MFRC522_ReadRegister(MFRC522_REG_STATUS2) & 0x08))) {
		status = MI_ERR;
	}

	return status;
}

MFRC522_Status_t MFRC522_Read(uint8_t blockAddr, uint8_t* recvData) {
	MFRC522_Status_t status;
	uint16_t unLen;

	recvData[0] = PICC_READ;
	recvData[1] = blockAddr;
	MFRC522_CalculateCRC(recvData, 2, &recvData[2]);
	status = MFRC522_ToCard(PCD_TRANSCEIVE, recvData, 4, recvData, &unLen);

	if ((status != MI_OK) || (unLen != 0x90)) {
		return MI_ERR;
	}

	return unLen;
}

MFRC522_Status_t MFRC522_Write(uint8_t blockAddr, uint8_t* writeData) {
	MFRC522_Status_t status;
	uint16_t recvBits;
	uint8_t i;
	uint8_t buff[18];

	buff[0] = PICC_WRITE;
	buff[1] = blockAddr;
	MFRC522_CalculateCRC(buff, 2, &buff[2]);
	status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff, &recvBits);

	if ((status != MI_OK) || (recvBits != 4) || ((buff[0] & 0x0F) != 0x0A)) {
		goto ERROR;
	}

	if (status == MI_OK) {
		//Data to the FIFO write 16Byte
		for (i = 0; i < 16; i++) {
			buff[i] = *(writeData + i);
		}
		MFRC522_CalculateCRC(buff, 16, &buff[16]);
		status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 18, buff, &recvBits);

		if ((status != MI_OK) || (recvBits != 4)
				|| ((buff[0] & 0x0F) != 0x0A)) {
				goto ERROR;

		}
	}
	return MI_OK;

	ERROR:
	if (recvBits == 4) {
		status = buff[0] & 0x0F;
	} else {
		status = MI_ERR;
	}
	return status;
}

void MFRC522_Halt(void) {
	uint16_t unLen;
	uint8_t buff[4];

	buff[0] = PICC_HALT;
	buff[1] = 0;
	MFRC522_CalculateCRC(buff, 2, &buff[2]);

	MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff, &unLen);

}
void MFRC522_WakeUp(void){
	uint16_t unLen;
	uint8_t buff[4];

	buff[0] = PICC_HALT;
	buff[1] = 0;
	MFRC522_CalculateCRC(buff, 2, &buff[2]);

	MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff, &unLen);
}
char *PICC_TYPE_STRING[] = { "PICC_TYPE_NOT_COMPLETE", "PICC_TYPE_MIFARE_MINI",
		"PICC_TYPE_MIFARE_1K", "PICC_TYPE_MIFARE_4K", "PICC_TYPE_MIFARE_UL",
		"PICC_TYPE_MIFARE_PLUS", "PICC_TYPE_TNP3XXX", "PICC_TYPE_ISO_14443_4",
		"PICC_TYPE_ISO_18092", "PICC_TYPE_UNKNOWN" };
char *MFRC522_TypeToString(PICC_TYPE_t type) {
	return PICC_TYPE_STRING[type];
}
int MFRC522_ParseType(uint8_t TagSelectRet) {
	if (TagSelectRet & 0x04) { // UID not complete
		return PICC_TYPE_NOT_COMPLETE;
	}

	switch (TagSelectRet) {
	case 0x09:
		return PICC_TYPE_MIFARE_MINI;
		break;
	case 0x08:
		return PICC_TYPE_MIFARE_1K;
		break;
	case 0x18:
		return PICC_TYPE_MIFARE_4K;
		break;
	case 0x00:
		return PICC_TYPE_MIFARE_UL;
		break;
	case 0x10:
	case 0x11:
		return PICC_TYPE_MIFARE_PLUS;
		break;
	case 0x01:
		return PICC_TYPE_TNP3XXX;
		break;
	default:
		break;
	}

	if (TagSelectRet & 0x20) {
		return PICC_TYPE_ISO_14443_4;
	}

	if (TagSelectRet & 0x40) {
		return PICC_TYPE_ISO_18092;
	}

	return PICC_TYPE_UNKNOWN;
}


int MFRC522_Debug_DumpSector(uint8_t *CardID, uint8_t block_addr) {
	int ret, i;
	uint8_t buffer[1024] = "";
	uint8_t SectorKeyA[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
	uint8_t *SectorKey;
	SectorKey = SectorKeyA;

	printf(
			"Auth Block (0x%02X) with key 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X ...",
			block_addr, SectorKey[0], SectorKey[1], SectorKey[2], SectorKey[3],
			SectorKey[4]);

	ret = MFRC522_Auth((uint8_t) PICC_AUTHENT1A, (uint8_t) block_addr,
			(uint8_t*) SectorKey, (uint8_t*) CardID);
	if (ret == MI_OK) {
		printf("OK\r\n");

		i = 0;
		for (i = 0; i < (4 - block_addr % 4); i++) {
			printf("Read block address 0x%02X ....", block_addr + i);
			ret = MFRC522_Read(block_addr + i, buffer + i * 16);
			if (ret <= 0) {
				printf("Failed\r\n");
				return -1;
			} else {
				printf("OK read %d bits\r\n", ret);
			}
		}

//		dump(buffer, i * 16);
		return 0;

	} else {
		printf("Failed\r\n");
		return -1;
	}

}
int MFRC522_Debug_Write(const char blockaddr, const char *Write_Data,
		const int len) {
	int ret;
	uint8_t buffer[16] = "";
	printf("Try to write block %d with %d byte data...", blockaddr, len);
	if (blockaddr == 0 || (blockaddr % 4) == 0x03) {
		puts("cannot write control block");
		return -1;
	}
	memcpy(buffer, Write_Data, len <= 16 ? len : 16);
	ret = MFRC522_Write(blockaddr, buffer);
	if (ret == MI_OK) {
		puts("OK");
		return 0;
	} else {
		printf("Failed, error 0x%02X\r\n", ret);
		return ret;
	}

}
int MFRC522_Debug_CardDump(uint8_t *CardID) {
	int ret_int = 0;

	{
		int i;
		for (i = 0x0; i < 0x40; i += 4) {
			ret_int |= MFRC522_Debug_DumpSector(CardID, i);
		}
	}
	return ret_int;
}
const char* __Reg_ToString[] = {
//Page 0: Command and Status
		"MFRC522_REG_RESERVED00",//0x00
		"MFRC522_REG_COMMAND",		//0x01
		"MFRC522_REG_COMM_IE_N",		//0x02
		"MFRC522_REG_DIV1_EN",		//0x03
		"MFRC522_REG_COMM_IRQ",		//0x04
		"MFRC522_REG_DIV_IRQ",		//0x05
		"MFRC522_REG_ERROR",		//0x06
		"MFRC522_REG_STATUS1",		//0x07
		"MFRC522_REG_STATUS2",		//0x08
		"MFRC522_REG_FIFO_DATA",		//0x09
		"MFRC522_REG_FIFO_LEVEL",		//0x0A
		"MFRC522_REG_WATER_LEVEL",		//0x0B
		"MFRC522_REG_CONTROL",		//0x0C
		"MFRC522_REG_BIT_FRAMING",		//0x0D
		"MFRC522_REG_COLL",		//0x0E
		"MFRC522_REG_RESERVED01",		//0x0F
//Page 1: Command
		"MFRC522_REG_RESERVED10",		//0x10
		"MFRC522_REG_MODE",		//0x11
		"MFRC522_REG_TX_MODE",		//0x12
		"MFRC522_REG_RX_MODE",		//0x13
		"MFRC522_REG_TX_CONTROL",		//0x14
		"MFRC522_REG_TX_AUTO",		//0x15
		"MFRC522_REG_TX_SELL",		//0x16
		"MFRC522_REG_RX_SELL",		//0x17
		"MFRC522_REG_RX_THRESHOLD",		//0x18
		"MFRC522_REG_DEMOD",		//0x19
		"MFRC522_REG_RESERVED11",		//0x1A
		"MFRC522_REG_RESERVED12",		//0x1B
		"MFRC522_REG_MIFARE",		//0x1C
		"MFRC522_REG_RESERVED13",		//0x1D
		"MFRC522_REG_RESERVED14",		//0x1E
		"MFRC522_REG_SERIALSPEED",		//0x1F
//Page 2: CFG
		"MFRC522_REG_RESERVED20",		//0x20
		"MFRC522_REG_CRC_RESULT_M",		//0x21
		"MFRC522_REG_CRC_RESULT_L",		//0x22
		"MFRC522_REG_RESERVED21",		//0x23
		"MFRC522_REG_MOD_WIDTH",		//0x24
		"MFRC522_REG_RESERVED22",		//0x25
		"MFRC522_REG_RF_CFG",		//0x26
		"MFRC522_REG_GS_N",		//0x27
		"MFRC522_REG_CWGS_PREG",		//0x28
		"MFRC522_REG__MODGS_PREG",		//0x29
		"MFRC522_REG_T_MODE",		//0x2A
		"MFRC522_REG_T_PRESCALER",		//0x2B
		"MFRC522_REG_T_RELOAD_H",		//0x2C
		"MFRC522_REG_T_RELOAD_L",		//0x2D
		"MFRC522_REG_T_COUNTER_VALUE_H",		//0x2E
		"MFRC522_REG_T_COUNTER_VALUE_L",		//0x2F
//Page 3:TestRegister
		"MFRC522_REG_RESERVED30",		//0x30
		"MFRC522_REG_TEST_SEL1",		//0x31
		"MFRC522_REG_TEST_SEL2",		//0x32
		"MFRC522_REG_TEST_PIN_EN",		//0x33
		"MFRC522_REG_TEST_PIN_VALUE",		//0x34
		"MFRC522_REG_TEST_BUS",		//0x35
		"MFRC522_REG_AUTO_TEST",		//0x36
		"MFRC522_REG_VERSION",		//0x37
		"MFRC522_REG_ANALOG_TEST",		//0x38
		"MFRC522_REG_TEST_ADC1",		//0x39
		"MFRC522_REG_TEST_ADC2",		//0x3A
		"MFRC522_REG_TEST_ADC0",		//0x3B
		"MFRC522_REG_RESERVED31",		//0x3C
		"MFRC522_REG_RESERVED32",		//0x3D
		"MFRC522_REG_RESERVED33",		//0x3E
		"MFRC522_REG_RESERVED34"		//0x3F
		};
void MFRC522_Debug_RegDump(uint8_t Reg_Addr) {
	printf("Reg:%sAddr:0x%02X,Value:0x%02X\r\n", __Reg_ToString[Reg_Addr],
			Reg_Addr, MFRC522_ReadRegister(Reg_Addr));
}


int scan_loop(uint8_t *CardID)
 {
 while (1)
 	{
	 char input[32];
	 int block_start;
	 DISP_COMMANDLINE();
	 printf("%02X%02X%02X%02X>", CardID[0], CardID[1], CardID[2], CardID[3]);
	 scanf("%s", input);
	 puts((char*)input);
	 if (strcmp(input, "halt") == 0)
	 	{
		 return 1;
		}
	 else if (strcmp(input, "dump") == 0)
	 	{
		 if (MFRC522_Debug_CardDump(CardID) < 0)
		return -1;
		}
	 else if (strcmp(input, "read") == 0)
	 	{
		 scanf("%d", &block_start);
		 if (MFRC522_Debug_DumpSector(CardID, block_start) < 0)
		 	{
		 	 return -1;
			}
		}
	 else if (strcmp(input, "writestr") == 0)
	 	{
		 char write_buffer[256], c;
		 size_t len = 0;
		 scanf("%d", &block_start);
		 while ((c = getchar()) != '\n' && c != EOF);
		 printf(">");
		 if (len >= 0)
		 	{
			 if (MFRC522_Debug_Write(block_start, write_buffer, strlen(write_buffer)) < 0)
			 	{
				 return -1;
				}
			}
		}
	 else
	 	{
		 printf("Usage:\r\n" "\tread <blockstart>\r\n" "\tdump\r\n" "\twritestr <blockaddr>\r\n");
		return 0;
		}
	}
 return 0;
}


int tag_select(uint8_t *CardID)
{
 int ret_int;

 printf("\r\n");
 printf("Card detected    0x%02X 0x%02X 0x%02X 0x%02X, Check Sum = 0x%02X\r\n", CardID[0], CardID[1], CardID[2], CardID[3], CardID[4]);
 ret_int = MFRC522_SelectTag(CardID);
 if (ret_int == 0)
 	{
	 printf("Card Select Failed\r\n");
	 return -1;
	}
 else
 	{
	 printf("Card Selected, Type:%s\r\n",
	 MFRC522_TypeToString(MFRC522_ParseType(ret_int)));
	}
ret_int = 0;
return ret_int;
}


void *RFIDProcess(void* args)
{
 MFRC522_Status_t ret;
 //Recognized card ID
 uint8_t CardID[5] = { 0x00, };
long long int	temp=0, temp1=0;
unsigned char tick;
// static char command_buffer[1024];
Counting=0;

while(1)
	{
	 tick=0;
	 while(1)
	 	{
		 tick++;
		 if (tick & 0x01)  SetRFID_STAT_LO();
		 else  SetRFID_STAT_HI();
	 	 usleep(250000);
		 SetRFID_RST_LO();
	 	 usleep(250000);
		 SetRFID_RST_HI();
		 usleep(100000);

		  ret = MFRC522_Init('A');
		  if (ret < 0)
		 	{
			 perror("Failed to initialize\r\n");
			 usleep(250000);
			}
		  else break;
	 	} 
	  printf("User Space RC522 Application\r\n");
	  
	 SetRFID_STAT_LO();
	 while (1)
	 	{
		 ret = MFRC522_Check(CardID);
		 if (ret== MI_OK)
		 	{
			 temp=CardID[4];
			 temp=temp<<32;
			 temp1=CardID[3];
			 temp1=temp1<<24;
			 temp|=temp1;
			 temp|=CardID[2]<<16;
			 temp|=CardID[1]<<8;
			 temp|=CardID[0];
			 if (RFIDState==kIdleRFID)
			 	{
				 IDcard=temp & 0xFFFFFFFF;
			 	 SetRFID_STAT_HI();
			 	 printf("Counting: %d Card ID: Format: %lld\r\n", Counting++, IDcard);
				 RFIDState=kNewRFID;
				 RFIDState_r=kNewRFID;
				 timeout=5;
			 	}
		 	}
//		 printf("turn here....%d    state: %d\r\n", timeout, RFIDState);
	 	 if (timeout) timeout--;
		 else
		 	{
		 	 if (RFIDState==kNewRFID) RFIDState=kIdleRFID;		// if no respone discharged old rfid value and waiting the new one
		 	}
	 	 if (RFIDState_r==kAckRFID)
	 	 	{
		 	 RFIDState=kIdleRFID;
			 RFIDState_r=kEndRFID;
	 	 	}

	  	 usleep(50000);
		 SetRFID_STAT_LO();
	 	}
	  printf("Restarting RFID .............\r\n");
	} 
 printf("Quit RFID !!!!!!!!!\r\n");
 return 0;
}

