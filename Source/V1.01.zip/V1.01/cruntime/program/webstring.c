#include "webstring.h"
#include "System.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "MiscDataConv.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>




const char *kStrPOS="POST /memcache.php HTTP/1.1\r\nHost: \0";
const char *kStrPOS_="\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 00000\r\n\r\n";
const char *kStrDBLEnter="\r\n\r\n";
const char *kStrAND="&";
const char *kStrrdwrmulti="rdwrmulti=1";
const char *kResponeServer="linux";
const char *kStrTag="tag=";
const char *kStrTotalWR="totalw=";
const char *kStrTotalRD="totalr=";
const char *kStridw="idw";
const char *kStrvalw="valw";
const char *kStridr="idr";
const char *kStrEqual="=";
const char *kStrWRSign="_";
const char *kStrSpace=" ";
const char *kStrCPU="cpu";
const char *kStrMemTot="MemTotal:";
const char *kStrMemActive="Active:";
const char *kStrMemAvail="MemAvailable:";
const char *kStrNULL="-";
const char *kStrAddress="@";

int SplitString(char *strSrc, struct stSplit *pSplitDesc, char separator)
{
 int n, i=0;
 int idx=0;
 unsigned char NewStr=kFALSE;

 if (strlen(strSrc)<=0) return(0);
// for (n=0; n<strlen(strSrc); n++) strSrc[n]=toupper(strSrc[n]);		// Upper case
 for (n=0; n<strlen(strSrc); n++)

 	{
 	 if ((strSrc[n]==separator)||
  	  	 (strSrc[n]==0x0D)||(strSrc[n]==0x0A)||(strSrc[n]==0x09))
	 	    {
	 	  	 if (NewStr)
	 	  	 	{
	 	  	 	 idx++;
				 i=0;
				 NewStr=kFALSE;
	 	  	 	}
 	 		}
	 else
	 	{
	 	 if (strSrc[n]!=' ')
	 	 	{
		 	 pSplitDesc->str[idx][i++]=strSrc[n];
	 	 	}
		 NewStr=kTRUE;
	 	}
	 }
 idx++;
 return(idx);
}



int SplitLine(char *strSrc, struct stSplit *pSplitDesc)
{
 int n, i=0;
 int idx=0;

 if (strlen(strSrc)<=0) return(0);
// for (n=0; n<strlen(strSrc); n++) strSrc[n]=toupper(strSrc[n]);		// Upper case
 for (n=0; n<strlen(strSrc); n++)
 	{
 	 if ((strSrc[n]==0x0D)||(strSrc[n]==0x0A))
 	    {
 	     if (strSrc[n]==0x0D)
 	     	{
 	     	 if (strSrc[n+1]==0x0A) n++;
 	     	}
  	 	 idx++;
		 i=0;
 		}
//	 else if (strSrc[n]==0x0D);
/*	 else if (((strSrc[n]>='A')&&(strSrc[n]<='Z'))||
	 		  ((strSrc[n]>='a')&&(strSrc[n]<='z'))||
	 		  ((strSrc[n]>='0')&&(strSrc[n]<='9'))||
	 		  (strSrc[n]>='_')||
	 		  (strSrc[n]>='.')
	 		 )
*/
	else
	 	{
	 	 pSplitDesc->str[idx][i++]=strSrc[n];
	 	}
	 }
 idx++;
 return(idx);
}


int GetIdxSplitStr(char *pStr, struct stSplit *pSplit)
{
 int n=0;

 while(1)
 	{
 	 if (pSplit->str[n][0]==0) return(-1);
	 if (CmpStr((char*)pSplit->str[n], (char*)pStr)) break;
	 n++;
 	}
 return(n);
}


int findSize(char file_name[])
{ 
    // opening the file in read mode 
 FILE* fp = fopen(file_name, "r"); 
  
    // checking if the file exist or not 
 if (fp == NULL)
 	{ 
     printf("File Not Found!\n"); 
     return -1; 
    } 
  
 fseek(fp, 0L, SEEK_END); 
  
    // calculating the size of the file 
 long int res = ftell(fp); 
  
    // closing the file 
 fclose(fp); 
  
 return res; 
} 


void MakeSureFileExist(char * filename)
{
 FILE *fptr;
 char mode[] = "0777";
 int i;

 if (access(filename, F_OK) != 0)
   {
	printf("File NOT Exist, Create it now !!!\r\n ");  // file doesn't exist
	fptr = fopen(filename, "w");
//	fprintf(fptr, "# PARAM CONFIG\r\n");
	fclose(fptr);
   }
 if (access(filename, F_OK) == 0)
	 {
	  i = strtol(mode, 0, 8);
	  chmod (filename,i);
	 }
}

