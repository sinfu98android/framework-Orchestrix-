#ifndef WEBSTRING_H
#define WEBSTRING_H

#define kMaxString		2048	//16384
#define kMaxWordLength	128

struct stSplit{
	char	str[kMaxString][kMaxWordLength];
};

extern const char *kStrPOS;
extern const char *kStrPOS_;
extern const char *kStrDBLEnter;
extern const char *kStrAND;
extern const char *kStrrdwrmulti;
extern const char *kResponeServer;
extern const char *kStrTag;
extern const char *kStrTotalWR;
extern const char *kStrTotalRD;
extern const char *kStridw;
extern const char *kStrvalw;
extern const char *kStridr;
extern const char *kStrEqual;
extern const char *kStrWRSign;
extern const char *kStrSpace;
extern const char *kStrCPU;
extern const char *kStrMemTot;
extern const char *kStrMemAvail;
extern const char *kStrMemActive;
extern const char *kStrNULL;
extern const char *kStrAddress;

int SplitLine(char *strSrc, struct stSplit *pSplitDesc);
int SplitString(char *strSrc, struct stSplit *pSplitDesc, char separator);
int SplitString1(char *strSrc, struct stSplit *pSplitDesc, char separator);
int GetIdxSplitStr(char *pStr, struct stSplit *pSplit);
int findSize(char file_name[]);
void MakeSureFileExist(char * filename);


#endif
