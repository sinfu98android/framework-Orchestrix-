<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>
 
<body style="background-color:#202020;">

</body>
</html>


<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>
<script src="js/aes.js"></script>

<script type="text/javascript">


window.onload = function () 
       {
        Init();
       }
setInterval(Process, kTimeBase);

function Init()
{
 var str=CryptoJS.AES.encrypt("Hello Yudi", "Secret Passphrase");
 console.log(str.toString());
 console.log(CryptoJS.AES.decrypt(str.toString(), "Secret Passphrase").toString(CryptoJS.enc.Utf8));

 InitHMI();
 if (resX>resY)         // Landscape
        {

        }
 else                   // Portrait
        {

        }
 InitProject();
}


function main()
      {

      }

</script>