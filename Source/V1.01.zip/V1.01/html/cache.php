<!DOCTYPE html>
<html>
    <head>
        <title>Read and Display Text File</title>
    </head>
    <body style="background-color:#202020;">
<!--        <textarea id="freeform" name="freeform" rows="40" cols="150"  style="text-transform:uppercase"></textarea>        -->
        <textarea id="freeform" name="freeform" rows="40" cols="150"></textarea>
    </body>
</html>


<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>
<script>

 const kFilename='/var/www/html/program/cache.txt';
   //const kFilename='/home/yudi/Program/code.txt';

 let loadfile=false;
 let data=null;
 let save=null;
 let saving=false;

let textfile="";   //=new Array();
let n=0; m=0;
let stat=false;
let varparse=null;
let stringval='';

const textarea = document.querySelector('textarea')

textarea.addEventListener('keydown', (e) => {
  if (e.keyCode === 9) {
    e.preventDefault()

    textarea.setRangeText(
      '    ',
      textarea.selectionStart,
      textarea.selectionStart,
      'end'
    )
  }
 else if (e.keyCode=='a') e.keyCode='A';
})

window.onload = function () 
       {
        Init();
       }
setInterval(Process, 100);


function Init()
{
 var n, i;

 InitHMI();

 if (resX>resY)
        {
         CreateButtonNew("bt_save", 90, 0, 8, 10,
                        'image/green_on.png', 'image/green_off.png',
                        "Save", "Save", 4,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'fixed');
        }
 else
        {

        }
 InitProject();
 CreateVarRDObj('mainstate', null, false);
}


 function main()
 {
  var n=GetID('bt_save');
  if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         if (loadfile==true)
            {
             if (saving==false) saving=true;
            }
        }
    }
  LoadFile();
  SavingFile();
}


function LoadFile()
     {
      if (loadfile==false)
         {
          data=openfile(kFilename);
          //data=openfile('../program/code.txt');
          if (data)
            {
             document.getElementById("freeform").value=data;
             //console.log(data);
             loadfile=true;
            }
        }
    }

function SavingFile()
{
 if (saving==true)
     {
      save=savefile(kFilename, document.getElementById("freeform").value);
      if (save)
         {
          saving=false;
         }
     }
}


</script>