<?php
$servername 		= "127.0.0.1";
$username 			= "remote";
$password 			= "remote";
$dbname	  			= "db_drawer"; //"db_DRAWERV2";



$con = mysqli_connect($servername, $username, $password);
if (!$con)
	{
     die('Could not connect: ' . mysql_error());
	}
else
	{
      $sql = "CREATE DATABASE IF NOT EXISTS ".$dbname;
      $result = $con->query($sql);
      if ($result)
        {
         $con->close();
         $con = mysqli_connect($servername, $username, $password, $dbname);
         $result = $con->query($sql);
//         echo $result;
        }
      //echo nl2br("database ".$result."\n");
	}
?>