<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>
<style>
body {
  background-image: url('image/basket2.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
  background-color:#202020;
}
</style> 

</html>


<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>
<script src="js/aes.js"></script>

<script type="text/javascript">

const kDevExtA='483FDA639420';
const kDevExtB='807D3A134437';

var astart24f=0;
var astart14f=0;
var areset=0;
var bstart24f=0;
var bstart14f=0;
var breset=0;
var arun=0;

window.onload = function () 
       {
        Init();
       }
setInterval(Process, kTimeBase);

function Init()
{
 var str=CryptoJS.AES.encrypt("Hello Yudi", "Secret Passphrase");
 console.log(str.toString());
 console.log(CryptoJS.AES.decrypt(str.toString(), "Secret Passphrase").toString(CryptoJS.enc.Utf8));

 InitHMI();
 if (resX>resY)         // Landscape
        {
         CreateLabelNew('lheader', 0, 1, 100, 6, 6, "Arial", "EXTENSION 1", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('playera', 40, 44, 20, 9, 8.5, "Arial black", "0", "orange", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');                            
         CreateButtonNew("bt_back", 0.5, 0.5, 10, 8.5,
                        'image/green_on.png', 'image/green_off.png',
                        "Back", "Back", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
         CreateButtonNew("bt_atimer24", 30, 58, 10, 8.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "24s", "24s", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
         CreateButtonNew("bt_atimer14", 45, 58, 10, 8.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "14s", "14s", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                      
         CreateButtonNew("bt_areset", 60, 58, 10, 8.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "Reset", "Reset", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_apause", 45, 73, 10, 8.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "Pause", "Pause", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
         CreateLabelNew('lrun', 60, 76, 10, 3, 3, "Arial", "", "red", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
        }
 else                   // Portrait
        {

        }
 InitProject();
 CreateVarRDObj('timeattack@'+kDevExtA);
 CreateVarRDObj('timeattack@'+kDevExtB);
 CreateVarRDObj('start24@'+kDevExtA);
 CreateVarRDObj('start14@'+kDevExtA);
 CreateVarRDObj('resetattack@'+kDevExtA);
 CreateVarRDObj('start24@'+kDevExtB);
 CreateVarRDObj('start14@'+kDevExtB); 
 CreateVarRDObj('resetattack@'+kDevExtB);
 CreateVarRDObj('run@'+kDevExtA);
 CreateVarRDObj('run@'+kDevExtB); 
}


function main()
{
 var n;

 n=GetID('bt_back');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE) submitlink("index.php");
    }
 n=GetID('bt_atimer24');
 if (n>=0)
    {
     if (hmiobj[n].PRESS)
         {
          if (GetValVarRDObj('start24@'+kDevExtA==0)) astart24f=10;
         }
     else
         {
          if (GetValVarRDObj('start24@'+kDevExtA==1)) if (astart24f==0)
             {
              SetValVarWRObj('start24@'+kDevExtA, 0);
              SetValVarWRObj('start24@'+kDevExtB, 0);
             }
         }
    }
 n=GetID('bt_atimer14');
 if (n>=0)
    {
     if (hmiobj[n].PRESS)
         {
          if (GetValVarRDObj('start14@'+kDevExtA==0)) astart14f=10;
         }
     else
         {
          if (GetValVarRDObj('start14@'+kDevExtA==1)) if (astart14f==0)
             {
              SetValVarWRObj('start14@'+kDevExtA, 0);
              SetValVarWRObj('start14@'+kDevExtB, 0);
             }
         }
    }
 n=GetID('bt_areset');
 if (n>=0)
    {
     if (hmiobj[n].PRESS)
         {
          if (GetValVarRDObj('resetattack@'+kDevExtA==0)) areset=10;
         }
     else
         {
          if (GetValVarRDObj('resetattack@'+kDevExtA==1)) if (areset==0)
              {
               SetValVarWRObj('resetattack@'+kDevExtA, 0);
               SetValVarWRObj('resetattack@'+kDevExtB, 0);
              }
         }
    }
 n=GetID('bt_apause');
 if (n>=0)
     {
      if (hmiobj[n].EDGERELEASE)
         {
          if (GetValVarRDObj('run@'+kDevExtA)==0)
            {
             SetValVarWRObj('run@'+kDevExtA, 1);
             SetValVarWRObj('run@'+kDevExtB, 1);  
            }
          else
            {
             SetValVarWRObj('run@'+kDevExtA, 0);
             SetValVarWRObj('run@'+kDevExtB, 0);  
            }
         }
     }


 if (tick100mS)
    {
     n=GetID('playera');
     if (n>=0)
        {
         if (GetValVarRDObj('timeattack@'+kDevExtA)) hmiobj[n].TEXT=(parseFloat(GetValVarRDObj('timeattack@'+kDevExtA)/10)).toFixed(1)+' s';
         else if (GetValVarRDObj('timeattack@'+kDevExtB)) hmiobj[n].TEXT=(parseFloat(GetValVarRDObj('timeattack@'+kDevExtB)/10)).toFixed(1)+' s';

        }
      if (astart24f) astart24f--;
      if (astart24f)
         {
          SetValVarWRObj('start24@'+kDevExtA, 1);
          SetValVarWRObj('start24@'+kDevExtB, 1);
          SetValVarWRObj('run@'+kDevExtA, 1);
          SetValVarWRObj('run@'+kDevExtB, 1);            
         }
      if (astart14f) astart14f--;
      if (astart14f)
         {
          SetValVarWRObj('start14@'+kDevExtA, 1);
          SetValVarWRObj('start14@'+kDevExtB, 1);
          SetValVarWRObj('run@'+kDevExtA, 1);
          SetValVarWRObj('run@'+kDevExtB, 1);            
         }
      if (areset) areset--;
      if (areset)
         {
          SetValVarWRObj('resetattack@'+kDevExtA, 1);
          SetValVarWRObj('resetattack@'+kDevExtB, 1);
         }
    }
 if (tick100mS)
   {
     n=GetID('lrun');
    if (n>=0)
       {
        if (GetValVarRDObj('run@'+kDevExtA)==0)
           {
            if (cycle500mS) hmiobj[n].TEXT="PAUSE";
            else hmiobj[n].TEXT="";
            }
        else hmiobj[n].TEXT="RUN";
        hmiobj[n].REFRESH=true;
       }
   }
}

</script>