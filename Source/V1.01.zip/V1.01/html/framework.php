<!DOCTYPE html>
<html>
<head>
  <title>HMI UI Builder</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }
    #palette {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 160px;
      background: #2e2e2e;
      color: white;
      padding: 10px;
    }
    #canvas {
      margin-left: 160px;
      position: relative;
      height: 100vh;
      background: #f0f0f0;
      overflow: hidden;
    }
    .widget {
      position: absolute;
      background: #c4d6f0;
      border: 1px solid #888;
      padding: 5px 10px;
      cursor: move;
      user-select: none;
    }
    #properties {
      position: fixed;
      right: 0;
      top: 0;
      bottom: 0;
      width: 220px;
      background: #ffffff;
      border-left: 1px solid #ccc;
      padding: 10px;
    }
    #properties input, #properties select {
      width: 100%;
      margin-bottom: 8px;
    }
    #export {
      margin-top: 20px;
      background: #0078d4;
      color: white;
      border: none;
      padding: 10px;
      width: 100%;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div id="palette">
    <h3>Widget Palette</h3>
    <button onclick="createWidget('Label')">Label</button>
    <button onclick="createWidget('Button')">Button</button>
  </div>

  <div id="canvas"></div>

  <div id="properties">
    <h3>Properties</h3>
    <input type="text" id="propText" placeholder="Text">
    <input type="number" id="propWidth" placeholder="Width (px)">
    <input type="number" id="propHeight" placeholder="Height (px)">
    <input type="color" id="propColor" placeholder="Color">
    <select id="propType">
      <option value="Label">Label</option>
      <option value="Button">Button</option>
    </select>
    <button id="export" onclick="exportLayout()">Export as JSON</button>
    <pre id="output"></pre>
  </div>

  <script>
    let currentWidget = null;
    let widgetId = 0;

    function createWidget(type) {
      const canvas = document.getElementById("canvas");
      const widget = document.createElement("div");
      widget.className = "widget";
      widget.innerText = type + " " + (++widgetId);
      widget.style.left = "200px";
      widget.style.top = "150px";
      widget.dataset.type = type;
      widget.draggable = false;

      widget.addEventListener("mousedown", startDrag);
      widget.addEventListener("click", () => selectWidget(widget));

      canvas.appendChild(widget);
    }

    function startDrag(e) {
      currentWidget = e.target;
      const offsetX = e.offsetX;
      const offsetY = e.offsetY;

      function onMouseMove(e) {
        currentWidget.style.left = (e.clientX - offsetX) + "px";
        currentWidget.style.top = (e.clientY - offsetY) + "px";
      }

      function onMouseUp() {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      }

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    }

    function selectWidget(widget) {
      currentWidget = widget;
      document.getElementById("propText").value = widget.innerText;
      document.getElementById("propWidth").value = widget.offsetWidth;
      document.getElementById("propHeight").value = widget.offsetHeight;
      document.getElementById("propColor").value = rgbToHex(widget.style.backgroundColor);
      document.getElementById("propType").value = widget.dataset.type;
    }

    function applyProperties() {
      if (!currentWidget) return;
      currentWidget.innerText = document.getElementById("propText").value;
      currentWidget.style.width = document.getElementById("propWidth").value + "px";
      currentWidget.style.height = document.getElementById("propHeight").value + "px";
      currentWidget.style.backgroundColor = document.getElementById("propColor").value;
      currentWidget.dataset.type = document.getElementById("propType").value;
    }

    ["propText", "propWidth", "propHeight", "propColor", "propType"].forEach(id =>
      document.getElementById(id).addEventListener("input", applyProperties)
    );

    function rgbToHex(rgb) {
      if (!rgb) return "#cccccc";
      const nums = rgb.match(/\d+/g).map(Number);
      return "#" + nums.map(x => x.toString(16).padStart(2, "0")).join("");
    }

    function exportLayout() {
      const layout = [...document.querySelectorAll(".widget")].map(el => ({
        type: el.dataset.type,
        text: el.innerText,
        left: el.style.left,
        top: el.style.top,
        width: el.offsetWidth,
        height: el.offsetHeight,
        color: rgbToHex(el.style.backgroundColor)
      }));
      document.getElementById("output").textContent = JSON.stringify(layout, null, 2);
    }
  </script>
</body>
</html>