<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>
 
<style>
body {
/*  background-image: url('image/basket1.png'); */
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
  background-color:#202020;
}
</style> 

</html>


<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>
<script src="js/aes.js"></script>
<script src="js/common.js"></script>

<script type="text/javascript">

var test=0;

window.onload = function () 
       {
        Init();
       }
setInterval(Process, kTimeBase);


function Init()
{
 var str=CryptoJS.AES.encrypt("Hello Yudi", "Secret Passphrase");
 console.log(str.toString());
 console.log(CryptoJS.AES.decrypt(str.toString(), "Secret Passphrase").toString(CryptoJS.enc.Utf8));

 InitHMI();
 if (resX>resY)         // Landscape
        {
         CreateLabelNew('lheader', 0, 1, 100, 5, 5, "Arial", "Demo WEB HMI", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lstatus', 0.5, 97.5, 90, 2, 2, "Arial", "test", "white", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo0', 15, 11, 10, 3.5, 3.5, "Arial black", "SILO 1", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo1', 45, 11, 10, 3.5, 3.5, "Arial black", "SILO 2", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo2', 75, 11, 10, 3.5, 3.5, "Arial black", "SILO 3", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo3', 15, 56, 10, 3.5, 3.5, "Arial black", "SILO 4", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo4', 45, 56, 10, 3.5, 3.5, "Arial black", "SILO 5", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilo5', 75, 56, 10, 3.5, 3.5, "Arial black", "SILO 6", "yellow", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         
         DrawImage("imgtank1", 10, 15, 20, 35, 'image/tank.png');
         DrawImage("imgtank2", 40, 15, 20, 35, 'image/tank.png');
         DrawImage("imgtank3", 70, 15, 20, 35, 'image/tank.png');
         DrawImage("imgtank4", 10, 60, 20, 35, 'image/tank.png');
         DrawImage("imgtank5", 40, 60, 20, 35, 'image/tank.png');
         DrawImage("imgtank6", 70, 60, 20, 35, 'image/tank.png');
         CreateProgressBar("lvladc0",  18.5, 18, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateProgressBar("lvladc1",  48.5, 18, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateProgressBar("lvladc2",  78.5, 18, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateProgressBar("lvladc3",  18.5, 63, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateProgressBar("lvladc4",  48.5, 63, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateProgressBar("lvladc5",  78.5, 63, 3, 30,  "Arial", 2, "red", "darkgray", 0, 1023, false);
         CreateLabelNew('lsilolvl0', 23, 30, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilolvl1', 53, 30, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilolvl2', 83, 30, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilolvl3', 23, 75, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilolvl4', 53, 75, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lsilolvl5', 83, 75, 7, 3, 3, "Arial black", "0%", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateImage('stat0', 25, 20, 2, 4, 'image/plgreen_OFF.png', 'absolute');
         CreateImage('stat1', 55, 20, 2, 4, 'image/plgreen_OFF.png', 'absolute');
         CreateImage('stat2', 85, 20, 2, 4, 'image/plgreen_OFF.png', 'absolute');
         CreateImage('stat3', 25, 65, 2, 4, 'image/plgreen_OFF.png', 'absolute');
         CreateImage('stat4', 55, 65, 2, 4, 'image/plgreen_OFF.png', 'absolute');
         CreateImage('stat5', 85, 65, 2, 4, 'image/plgreen_OFF.png', 'absolute');
        }
 else                   // Portrait
        {

        }
 InitProject(null);
 //InitProject("10D07A1AE534");
 //var fields=[];
 //fields.push({FIELD:'name', PARAM:'VarChar(16)'});        // key
 //fields.push({FIELD:'datetime', PARAM:'bigint(11)'});
 //CreateNewTable('sql313.infinityfree.com', 'if0_39311832', 'yudi1234567890', 'if0_39311832'+'_'+'db_main', 'tb_device', fields);   //(server, username, password, dbase, table, fields)
}


function main()
{
 var n;

 if (tick100mS)
    {
      n=GetID("lstatus");
      if (n>=0)
         {
          hmiobj[n].TEXT=macaddr+", "+ipaddr+"  tick:"+tick+",  cpu:"+cpucyc+",  com:"+comcyc;
         }
      n=GetID("lvladc0");
      if (n>=0)
         {
          hmiobj[n].VAL=adc0;
          hmiobj[n].REFRESH=true;
         }
      n=GetID("lvladc1");
      if (n>=0)
         {
          hmiobj[n].VAL=adc1;
          hmiobj[n].REFRESH=true;
         }
      n=GetID("lvladc2");
      if (n>=0)
         {
          hmiobj[n].VAL=adc2;
          hmiobj[n].REFRESH=true;
         }
      n=GetID("lvladc3");
      if (n>=0)
         {
          hmiobj[n].VAL=adc3;
          hmiobj[n].REFRESH=true;
         }
      n=GetID("lvladc4");
      if (n>=0)
         {
          hmiobj[n].VAL=adc4;
          hmiobj[n].REFRESH=true;
         }
      n=GetID("lvladc5");
      if (n>=0)
         {
          hmiobj[n].VAL=adc5;
          hmiobj[n].REFRESH=true;
         }
     n=GetID('stat0');
     if (n>=0)
        {
         if (digitalin & 0x01) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }
     n=GetID('stat1');
     if (n>=0)
        {
         if (digitalin & 0x02) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }
     n=GetID('stat2');
     if (n>=0)
        {
         if (digitalin & 0x04) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }
     n=GetID('stat3');
     if (n>=0)
        {
         if (digitalin & 0x08) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }
     n=GetID('stat4');
     if (n>=0)
        {
         if (digitalin & 0x10) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }
     n=GetID('stat5');
     if (n>=0)
        {
         if (digitalin & 0x20) hmiobj[n].SRC='image/plgreen_ON.png';
         else hmiobj[n].SRC='image/plgreen_OFF.png';
         hmiobj[n].REFRESH=true;
        }        
     n=GetID('lsilolvl0');
     if (n>=0) hmiobj[n].TEXT=((adc0*100)/1023).toFixed(1)+"%";
     n=GetID('lsilolvl1');
     if (n>=0) hmiobj[n].TEXT=((adc1*100)/1023).toFixed(1)+"%";
     n=GetID('lsilolvl2');
     if (n>=0) hmiobj[n].TEXT=((adc2*100)/1023).toFixed(1)+"%";
     n=GetID('lsilolvl3');
     if (n>=0) hmiobj[n].TEXT=((adc3*100)/1023).toFixed(1)+"%";
     n=GetID('lsilolvl4');
     if (n>=0) hmiobj[n].TEXT=((adc4*100)/1023).toFixed(1)+"%";
     n=GetID('lsilolvl5');
     if (n>=0) hmiobj[n].TEXT=((adc5*100)/1023).toFixed(1)+"%";
    }
}

</script>