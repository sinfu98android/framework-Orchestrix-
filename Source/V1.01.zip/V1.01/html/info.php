<?php 
echo phpinfo();
 ?>