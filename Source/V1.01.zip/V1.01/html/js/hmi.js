const kTimeBase=25;  //25;    ///25;
const kscalercache=3;
const kTimeOutServer=500;
const kMaxWaitServer=500;
const kscaler100mS=100/kTimeBase;
const kscaler200mS=2;
const kscaler500mS=5;
const kscaler1S=2;
const kscaler5S=5;


const kWRCACHEKEYIDLE=0;
const kWRCACHEKEYSTART=1;
const kWRCACHEKEYRUN=2;
const kWRDBASEKEYIDLE=0;
const kWRDBASEKEYSTART=1;
const kWRDBASEKEYRUN=2;


const kWRMemCacheIDLE=0
const kWRMemCacheSTART=1;
const kWRMemCachePRE=2;
const kWRMemCacheRUN=3;
const kWRMemCacheRESP=4;


const kRDMemCacheIDLE=0
const kRDMemCacheSTART=1;
const kRDMemCachePRE=2;
const kRDMemCacheRUN=3;
const kRDMemCacheRESP=4;

const kRDDBASEIDLE=0;
const kRDDBASESTART=1;
const kRDDBASEPRE=2;
const kRDDBASERUN=3;

const kWRDBASEIDLE=0;
const kWRDBASESTART=1;
const kWRDBASEPRE=2;
const kWRDBASERUN=3;

const kRDDBASESEQIDLE=0;
const kRDDBASESEQSTART=1;
const kRDDBASESEQSTARTCYC=2;
const kRDDBASESEQPRE=3;
const kRDDBASESEQRUN=4;
const kRDDBASESEQRESP=5;


const kWRDBASESEQIDLE=0;
const kWRDBASESEQSTART=1;
const kWRDBASESEQRUN=2;
const kWRDBASESEQSTARTALL=3;
const kWRDBASESEQPREALL=4;
const kWRDBASESEQRUNALL=5;

const kBOOT_FIRST=0;
const kBOOT_READ_CACHE=1;
const kBOOT_RDY=2;

const kBotttom=0
const kTop=1;

const kTimeOutMemcahce=0;   //3;   //5;      //10;
const kSCLAER_RDDBASE=1200;

const kVarNONE=0;
const kVarLOCAL=1;
const kVarCACHE=2;
const kVarDBASE=3;

const kParamDBASEServer=0;
const kParamDBASEName=1;
const kParamDBASETable=2;
const kParamDBASEUser=3;
const kParamDBASEPass=4;


const kSTART=1;
const kPROCESS=2;
const kSUCCESS=3;
const kEND=4;
const kFAIL=5;


let hmiobj = []; // empty array
let buff = [];
let bufftable = [];
let buffchart = [];
let buffcharttime=[];
let buffhisto = [];
let resX=0, rexY=0;
let UpdatevarWR=false;
let MouseX=0;
let MouseY=0;
let MouseDown=false;
let KeyCode=0;
let KeyChar='';
let KeyBoardPress=false;
let KeyBoard1stPress=false;
let KeyBoardEdgePress=false;
let KeyBoardEdgeRelease=false;

let WRCACHEKEYstate=kWRCACHEKEYIDLE;
let WRCACHEKEYID, WRCACHEKEYVAL;
let WRDBASEKEYstate=kWRDBASEKEYIDLE;


let WRMemcacheSEQ=kWRMemCacheIDLE;
let WRMemcacheSEQtmr=0;

let RDMemcacheSEQ=kRDMemCacheSTART;
let RDMemcacheSEQtmr=0;

let tick100mS=false, tick500mS=false, tick1S=false, tick200mS=false, tick5S=false;
let cycle100mS=false, cycle500mS=false, cycle1S=false, cycle200mS=false, cycle5S=false;
let scaler100mS=kscaler100mS;
let scaler200mS=kscaler200mS;
let scaler500mS=kscaler500mS;
let scaler1S=kscaler1S;
let scaler5S=kscaler5S;
let cycle=0;

let queryString;
let urlParams;
let CACHEmeasure;
let WRDBASEstate, WRDBASEtmr;
let RDDBASEstate, RDDBASEtmr;
let WRDBASESEQstate, WRDBASESEQidx, WRDBASESEQ_ID;
let RDDBASESEQstate=kRDDBASESEQSTART, RDDBASESEQidx;
let SCALER_RDDBASE=kSCLAER_RDDBASE;
let refresh=false;
let datetime;
let datetimes;
let BuffWRCACHE = [];
let cacheseq=0;
let varRDobj = [];
let varWRobj = [];
let focusid=null;
let focusid_=null;
let CacheRDY=true;
let wrcacheSeq=0;
let rdcacheSeq=0;
let rdcacheSeq_=0;
let firstStart=kBOOT_FIRST;
let tickCACHE=false;
let tickCACHEInit=false;
let tickSys_=0, tickSys=0;
let timestate=kIDLE;
let timeConnection=0;
let connection=true;
let tagid=parseInt(Math.random()*1000);
let scaleyStatic=1;
let KeyboardBuff='';

var tickdbase=0;
var HMICycle=0;
var scalercache=0;
var timestamp=0;
var datetimeint;
var datetimestr;
var cachewritetime=0;
var cachereadtime=0;
var flagTimeWriteCache=false;
var timestampWriteCache;
var flagTimereadCache=false;
var timestampreadCache;
var FastRefresh=false;
var CycleReadCache=3;


function Process()
{
 if (HMICycle>=40) main();
 SystemTick();
 VarProject();
 HMIServices();
 KeyBoardEdgePress=false;
}


function GetSyncTime()
{
 var names=[];
 var values=[];
 var buff=[];
 var i;
 const d = new Date();
 var tdatetime = {year:d.getFullYear(), month:d.getMonth()+1, day:d.getDate(), hour:d.getHours(), min:d.getMinutes(), sec:d.getSeconds(), date:0}; 
 
 datetimeint=ConvDatetimetoInt(tdatetime);
 datetimestr=tdatetime.year+'/'+zerolead((tdatetime.month+1),2)+'/'+zerolead((tdatetime.day+1),2)+' '+zerolead(tdatetime.hour,2)+':'+zerolead(tdatetime.min,2)+':'+zerolead(tdatetime.sec,2); 

 if (tick1S)
    {
     if  (timestate==kIDLE) timestate=kSTART;
    }

 if (timestate==kSTART)
    {
     timestate=kPROCESS;
     timetimeout=0;
    }
 else if (timestate==kPROCESS)
    { 
     //console.log('time');
     i=0;
     names[i]='tag';                    values[i++]='synctime'+tagid;
     names[i]='syncdatetime';           values[i++]=1;
     buff=getpostX("rtc.php", names, values);
     if (buff[0]==values[0])
        {
         tagid++;
         datetime=buff[1];
         datetimes=buff[2];
         //console.log(datetime);
         timestate=kIDLE;
         connection=true;
        }
     timetimeout++;
     if (timetimeout>=kTimeOutServer)
        {
         timestate=kIDLE;
         connection=false;
        }
    }
 if (tick1S)
    {
     if (connection) timeConnection++;
    }
}


//****************************************************************************************************//
//                                              System Tick                called every 100mS         //
//****************************************************************************************************//
function SystemTick()
{
 tick100mS=false;
 tick200mS=false;
 tick500mS=false;
 tick1S=false;
 tick5S=false;
 if (scaler100mS) scaler100mS--;
 if (scaler100mS==0)
    {
     scaler100mS=kscaler100mS;
     cycle100mS=~cycle100mS;
     tick100mS=true;
     if (scaler200mS) scaler200mS--;
     if (scaler200mS==0)
        {
         scaler200mS=kscaler200mS;
         tick200mS=true;
         cycle200mS=~cycle200mS;
        }

     if (scaler500mS) scaler500mS--;
     if (scaler500mS==0)
        {
         scaler500mS=kscaler500mS;
         cycle500mS=~cycle100mS;
         tick500mS=true;
         if (scaler1S) scaler1S--; 
         if (scaler1S==0) 
            {
//             console.log("Tick1S");
             scaler1S=kscaler1S;
             cycle1S=~cycle1S;
             tick1S=true;
             if (scaler5S) scaler5S--;
             if (scaler5S==0)
                {
                 tick5S=true;
                 cycle5S=~cycle5S;
                 scaler5S=kscaler5S;
                }
            }
        }
    }
 if (tick1S)
    {
     tickSys=tickSys_;
     tickSys_=0;        
    }    
 GetSyncTime();
}



//****************************************************************************************************//
//                                              Variable Handler                                      //
//****************************************************************************************************//
function GetVarRDID(id)
    {
     var n;

     if (varRDobj.length)
        {
         for (n=0; n<varRDobj.length; n++)
             {
              if (varRDobj[n].ID==id) return(n);
             }
        }
     return(-1);
    }

function GetVarWRID(id)
    {
     var n;

     if (varWRobj.length)
        {
         for (n=0; n<varWRobj.length; n++)
             {
              if (varWRobj[n].ID==id) return(n);
             }
        }
     return(-1);
    }


function CreateVarRDObj(id, value, local)
    {
     var n;

     if (GetVarRDID(id)==-1)
        {
         varRDobj.push({ ID:id, VALUE:value, LOCAL:local});
         varWRobj.push({ ID:id, VALUE:value, LOCAL:local});
         return(true);
        }
     return(false);
    }


function GetValVarRDObj(id)
{
 var n;
 if (varRDobj.length)
    {
     for (n=0; n<varRDobj.length; n++)
        {
          if (varRDobj[n].ID==id)
           {
            return(varRDobj[n].VALUE);
           }
        }
    }
 return(-1);
}


function SetValVarWRObj(id, value)
{
 var n, i;
 var newid=true;

 if (varWRobj.length)
    {
     n=GetVarWRID(id);
     if (n>=0)
        {
         //console.log('WRITE here2..', id, value);
         for (i=0; i<BuffWRCACHE.length; i++)
             {
              if (BuffWRCACHE[i].ID==id)
                 {
                  newid=false;  
                  break;
                 }
             }
         varWRobj[n].VALUE=value;
         if (newid) BuffWRCACHE.push({ID:id});
        }
    }
}


function ReadLocalStorage()
{
 var n;
 var temp;

 for (n=0; n<hmiobj.length; n++)
    {   
     if (hmiobj[n].VTYPE==kVarLOCAL)
         {
          if (hmiobj[n].OBJECT=='label')
             {
              temp=localStorage.getItem(hmiobj[n].ID);
              console.log('here!!!');
              hmiobj[n].TEXT=temp;
             }
        }
    }
}

function ReadMemCacheSeq()
  {
   var buff=new Array();
   var names=[];
   var values=[];
   var total;
   var tagid;
   var n, m;
   var i=0;
   var j=0;


   //console.log('RD memcache: '+varRDobj.length);
//   return;

   tickCACHE=false;
   if (CacheRDY==false) return;
   if (WRCACHEKEYstate>kWRCACHEKEYIDLE) return;
   if (WRMemcacheSEQ>kWRMemCacheIDLE) return;
   if (varRDobj.length==0) return;
   if (RDMemcacheSEQ==kRDMemCacheIDLE)
      {
       if (varRDobj.length) RDMemcacheSEQ=kRDMemCacheSTART;
      }

   if (RDMemcacheSEQ==kRDMemCacheSTART)
         {
           RDMemcacheSEQ=kRDMemCachePRE;
         }
   else if (RDMemcacheSEQ==kRDMemCachePRE)
         {
          RDMemcacheSEQtmr=CycleReadCache; //5;
          RDMemcacheSEQ=kRDMemCacheRUN;
         }
   else if (RDMemcacheSEQ==kRDMemCacheRUN)
         {
          if (flagTimereadCache==false)
             {
              flagTimereadCache=true;
              timestampreadCache=Date.now();
             }
          i=0;
          j=0;
          tagid='rdcache'+rdcacheSeq;
          names[i]='rdmulti';        values[i++]='1';
          names[i]='tag';            values[i++]=tagid;
          for (n=0; n<varRDobj.length; n++)
              {
                names[i]='id'+j++;     values[i++]=varRDobj[n].ID;             // 0    
              }
          names[i]='total';          values[i++]=j;
          buff=getpostX('memcache.php', names, values); 
          if (buff[0]==tagid)
               {
                flagTimereadCache=false;
                cachereadtime=Date.now()-timestampreadCache;
                //console.log("CacheRead: "+cachereadtime+", "+Date.now());
                rdcacheSeq++;
                for (n=0; n<varRDobj.length; n++) varRDobj[n].VALUE=buff[1+n];
                for (n=0; n<varRDobj.length; n++)
                    {
                     m=GetIDField(varRDobj[n].ID);
                     if (m>=0)
                        {
                         if ((hmiobj[m].OBJECT=='label')&&(hmiobj[m].VTYPE==kVarCACHE))
                            {
                             hmiobj[m].TEXT=varRDobj[n].VALUE;
                            }
                         else if (hmiobj[m].OBJECT=='option') hmiobj[m].SELECTIDX=varRDobj[n].VALUE;
                        }
                    }
                RDMemcacheSEQ=kRDMemCacheIDLE;
                if (firstStart==kBOOT_FIRST) firstStart=kBOOT_READ_CACHE;
                tickCACHE=true;
                FastRefresh=false;
                tickSys_++;
               }
          else
             {
              if (RDMemcacheSEQtmr) RDMemcacheSEQtmr--;
              else RDMemcacheSEQ=kRDMemCachePRE;
            }
         }
   }



function WriteMemCacheSeq()
    {
     var buff=new Array();
     var names=[];
     var values=[];
     var total;
     var tagid;
     var n, m, k;
     var i=0;
     var j=0;
     var stat=true;

     if (CacheRDY==false) return;
     if (WRMemcacheSEQ==kWRMemCacheIDLE)
         {
          if (BuffWRCACHE.length)
            {
             if (rdcacheSeq!=rdcacheSeq_)
                {
                 BuffWRCACHE_=BuffWRCACHE;
                 BuffWRCACHE=[];
                 WRMemcacheSEQ=kWRMemCacheSTART;
                 rdcacheSeq_=rdcacheSeq;
                 //console.log(BuffWRCACHE);
                }
            }
         }
     else if (WRMemcacheSEQ==kWRMemCacheSTART)
         {
          //console.log("Write CACHE1 !!!");
          WRMemcacheSEQ=kWRMemCachePRE;
         }
     else if (WRMemcacheSEQ==kWRMemCachePRE)
         {
          WRMemcacheSEQ=kWRMemCacheRUN;
          WRMemcacheSEQtmr=30;
         } 
     else if (WRMemcacheSEQ==kWRMemCacheRUN)
           {
            if (flagTimeWriteCache==false)
                {
                 flagTimeWriteCache=true;   
                 timestampWriteCache = Date.now();   
                }
            i=0;
            j=0;
            tagid='wrcache'+wrcacheSeq;
            names[i]='tag';            values[i++]=tagid;
            names[i]='wrmulti';        values[i++]='1';

            //console.log(BuffWRCACHE_);
            
            for (k=0; k<BuffWRCACHE_.length; k++)
                {
                 n=GetVarWRID(BuffWRCACHE_[k].ID);
/*                 
                 m=GetID(BuffWRCACHE_[k].ID);                 
                 if (m>=0)
                    {
                     if (hmiobj[m].OBJECT=='option') varWRobj[n].VALUE=hmiobj[m].SELECTIDX;
                     else if (hmiobj[m].OBJECT=='label') varWRobj[n].VALUE=hmiobj[m].TEXT;
                    }
*/                    
                 if (n>=0)
                    {
                     names[i]='id'+j;           values[i++]=varWRobj[n].ID;         names[i]='val'+j++;         values[i++]=varWRobj[n].VALUE;    
                     names[i]='id'+j;           values[i++]=varWRobj[n].ID+'_';     names[i]='val'+j++;         values[i++]=varWRobj[n].VALUE;
                    }
                 else stat=false;
                }

            if (stat)
                {
                 names[i]='total';          values[i++]=j;
                 buff=getpostX('memcache.php', names, values);
                 if ((buff[0]==tagid)&&(buff[1]='ACK'))
                    {
                     cachewritetime=Date.now()-timestampWriteCache;
                     flagTimeWriteCache=false;
                     //console.log("time: "+timestampWriteCache+", "+cachewritetime);
                     wrcacheSeq++;
                     BuffWRCACHE_=[];
                     WRMemcacheSEQ=kWRMemCacheIDLE;
                     FastRefresh=true;
                    }
                 else
                    {
                     if (WRMemcacheSEQtmr) WRMemcacheSEQtmr--;
                     else WRMemcacheSEQ=kWRMemCacheSTART;
                    }
                }
            else WRMemcacheSEQ=kWRMemCacheIDLE;
           }
    }



function GetDBASE(id)
  {
  var names=[];
  var values=[];
  var buff=new Array();
  var Mode=new Array();
  var Value=new Array();
  var i, j, n, m;
  var TotField=0;

  m=GetID(id);
  if (m>=0)
     {
      if (hmiobj[m].VTYPE==kVarDBASE)
          {
           if (RDDBASEstate==kRDDBASESTART)
                {
                 RDDBASEstate=kRDDBASEPRE;
                }
           else if (RDDBASEstate==kRDDBASEPRE)
                 {
                  RDDBASEstate=kRDDBASERUN;
                  RDDBASEtmr=10;
                 }
           else if (RDDBASEstate==kRDDBASERUN)
                {
                 buff=[];
                 i=0;
                 j=0;
                 total=1;
                 names[i]='tag';          values[i++]=id;
                 names[i]='serverx';      values[i++]=hmiobj[m].VDBASE[kParamDBASEServer];  //'127.0.0.1';
                 names[i]='userx';        values[i++]=hmiobj[m].VDBASE[kParamDBASEUser];  //'remote';
                 names[i]='passx';        values[i++]=hmiobj[m].VDBASE[kParamDBASEPass];  //'remote';
                 names[i]='dbasex';       values[i++]=hmiobj[m].VDBASE[kParamDBASEName];  //db_process;
                 names[i]='tablex';       values[i++]=hmiobj[m].VDBASE[kParamDBASETable];
                 names[i]='selectid';     values[i++]=hmiobj[m].VID;
                 names[i]='limit';        values[i++]='1';
                 names[i]='id'+j++;       values[i++]=hmiobj[m].VFIELD;
                 TotField=parseInt(j);
                 //console.log(id, hmiobj[m].VDBASE);
                 buff=getpostX('mysqlproc.php', names, values);
                 if (buff[0]==values[0])
                     {
                      //console.log(buff);
                      var x=GetID(buff[0]);
                      if (hmiobj[x].OBJECT=='label') hmiobj[x].TEXT=buff[1];
                      else if (hmiobj[x].OBJECT=='option') hmiobj[x].SELECTIDX=buff[1];
                      RDDBASEstate=kRDDBASEIDLE;
                     }
                 if (RDDBASEtmr) RDDBASEtmr--;
                 else RDDBASEstate=kRDDBASEPRE;               
                }
            }
        }
    }


function WriteDBASE(id)
{
  var names=[];
  var values=[];
  var buff=new Array();
  var i, j, n, m;
  var TotField=0;
  var value;

  if (WRDBASEstate==kWRDBASESTART)
     {
      WRDBASEstate=kWRDBASEPRE;
     } 
  else if (WRDBASEstate==kWRDBASEPRE)
      {
       WRDBASEstate=kWRDBASERUN;
       WRDBASEtmr=50;
      }
  else if (WRDBASEstate==kWRDBASERUN)
      {   
          m=GetID(id);

          if (hmiobj[m].OBJECT=='label') 
               {
                value=hmiobj[m].TEXT;
               }
          else if (hmiobj[m].OBJECT=='option')
               {
                value=hmiobj[m].SELECTIDX;
               }
          buff=[];
          i=0;
          j=0;
          names[i]='tag';          values[i++]='setdata';
          names[i]='table';        values[i++]=hmiobj[m].VTABLE;
          names[i]='update';       values[i++]='1';
          names[i]='cond';         values[i++]='id';
          names[i]='vcond';        values[i++]=hmiobj[m].VID;
          names[i]='field'+j;      values[i++]=field=hmiobj[m].VFIELD;  names[i]='val'+j++;       values[i++]='\''+value+'\'';          
          names[i]='total';        values[i++]=j;
          TotField=parseInt(j);
          buff=getpostX('mysqlproc.php', names, values);
          if (buff[0]==values[0])
               {
                WRDBASEstate=kWRDBASEIDLE;
               } 
          if (WRDBASEtmr) WRDBASEtmr--;
          else WRDBASEstate=kWRDBASEPRE;
       }
}


function GetDATABSESeq()
   {
    var n, i;

    if (hmiobj.length==0) return;

    if (RDDBASESEQstate==kRDDBASESEQSTART)
         {
          RDDBASESEQidx=0;
          SCALER_RDDBASE=kSCLAER_RDDBASE;  
          RDDBASESEQstate=kRDDBASESEQPRE;
         }
    else if (RDDBASESEQstate==kRDDBASESEQSTARTCYC)
         {
          RDDBASESEQidx=0;
          if (SCALER_RDDBASE) SCALER_RDDBASE--;
          else
               {
                SCALER_RDDBASE=kSCLAER_RDDBASE;  
                RDDBASESEQstate=kRDDBASESEQPRE;
               }
         }
    else if (RDDBASESEQstate==kRDDBASESEQPRE)
         {
          if (RDDBASESEQidx>=hmiobj.length) RDDBASESEQstate=kRDDBASESEQSTARTCYC;
          else RDDBASESEQstate=kRDDBASESEQRUN;
         }
    else if (RDDBASESEQstate==kRDDBASESEQRUN)
         {
          if (hmiobj[RDDBASESEQidx].VTYPE==kVarDBASE)
               {
                RDDBASEstate=kRDDBASESTART;
                RDDBASESEQstate=kRDDBASESEQRESP;
               }  
          else 
               {
                RDDBASESEQidx++;
                RDDBASESEQstate=kRDDBASESEQPRE;
               }
         }
    else if (RDDBASESEQstate==kRDDBASESEQRESP)
         {
          GetDBASE(hmiobj[RDDBASESEQidx].ID);
          if (RDDBASEstate==kRDDBASEIDLE)
               {
                RDDBASESEQidx++;
                RDDBASESEQstate=kRDDBASESEQPRE;
               }
         }
   }


function SetDATABSESeq()
   {
    var n, m, i;

    if (hmiobj.length==0) return;
    if (WRDBASESEQstate==kWRDBASESEQSTART)                                    // Saving Specified ID to Database
         {
          WRDBASESEQstate=kWRDBASESEQRUN;
          WRDBASEstate=kWRDBASESTART;
         }
    else if (WRDBASESEQstate==kWRDBASESEQRUN)
         {
          //console.log(WRDBASESEQ_ID);
          WriteDBASE(WRDBASESEQ_ID);
          if (WRDBASEstate==kWRDBASEIDLE)
               {
                WRDBASESEQstate=kWRDBASESEQIDLE;
               }
         }
    else if (WRDBASESEQstate==kWRDBASESEQSTARTALL)                            // Saving All ID to Database
         {
          WRDBASESEQstate=kWRDBASESEQPREALL;
          WRDBASESEQidx=0;
         }
    else if (WRDBASESEQstate==kWRDBASESEQPREALL)
         {
          if (WRDBASESEQidx>=hmiobj.length) WRDBASESEQstate=kWRDBASESEQIDLE;
          else 
               {
                WRDBASESEQstate=kWRDBASESEQRUNALL;
                WRDBASEstate=kWRDBASESTART;
               }
         }
    else if (WRDBASESEQstate==kWRDBASESEQRUNALL)
         {
          if (hmiobj[WRDBASESEQidx].VTYPE==kVarDBASE) 
             {
              WriteDBASE(hmiobj[WRDBASESEQidx].ID);
              if (WRDBASEstate==kWRDBASEIDLE)
                   {
                    WRDBASESEQidx++;
                    WRDBASESEQstate=kWRDBASESEQPREALL;
                   }
             }
          else
             {
              WRDBASESEQidx++;
              WRDBASESEQstate=kWRDBASESEQPREALL;  
             }
         }
   }

//*******************************************************************************************************//
//                                                  Misc                                                 //
//*******************************************************************************************************//
function CheckResUpdate()
       {
        var x,y;
        var n;

        x=Math.abs(window.innerWidth-resX);
        y=Math.abs(window.innerHeight-resY);
        if ((x>=350)||(y>=350))
            {
             if (refresh==false)
                {
                 refresh=true;
                 ///window.location.reload(); 
                }
            }
       }


function InitHMI()
    {      
     resX=window.innerWidth;
     resY=window.innerHeight;
     if ((resY<600)&&(resX<1024))
          {
           resY=resY*2;
           resX=resX*2;
          }  
//     offX=window.innerl
     queryString = window.location.search;
     urlParams = new URLSearchParams(queryString);
     var serverloc=localStorage.getItem("server");
     if (serverloc) db_process=serverloc;
    }


function GetID(id)
{
 var n=0;

 if (hmiobj.length)
    {
     while(1)
        {
         if (hmiobj[n].ID==id) return(n);
         n++;
         if (n>=hmiobj.length) return(-1);
        }
    }
 else return(-1);
}


function GetIDField(field)
{
 var n=0;

 if (hmiobj.length)
    {
     while(1)
        {
         if (hmiobj[n].VFIELD==field) return(n);
         n++;
         if (n>=hmiobj.length) return(-1);
        }
    }
 else return(-1);
}



function GetBuffID(id)
{
 var n=0;
 
 while(1)
    {
     if (buff[n].ID==id) return(n);
     n++;
     if (n>=buff.length) return(-1);
    }   
}

function CheckFocusID()
{
 if (focusid!=focusid_)
     {
      var n=GetID(focusid_);
      if (n>=0) hmiobj[n].REFRESH=true;
      focusid_=focusid; 
     }
}

//*****************************************************************************************************//
//                                              HMI Services                                           //
//*****************************************************************************************************//
 function HMIServices()
    {
     var n=0;
     var temp=0;
     
     if (hmiobj.length==0) return;
     CheckFocusID();
     CheckResUpdate();
     ReadLocalStorage();
     if ((BuffWRCACHE.length)||(WRMemcacheSEQ!=kWRMemCacheIDLE))
        {
         //console.log(BuffWRCACHE);
         WriteMemCacheSeq();
        }
     if (FastRefresh) scalercache=0;
     if (scalercache) scalercache--;
     else
        {
         scalercache=kscalercache;
         ReadMemCacheSeq();
        }
     GetDATABSESeq();
     SetDATABSESeq();
     ///if (tickCACHE==false) return;
//********************************************** Button Services ***************************************//
     for (n=0; n<hmiobj.length; n++)
        {
         if (hmiobj[n].OBJECT=='button')
            {
             hmiobj[n].EDGEPRESS=false;
             hmiobj[n].EDGERELEASE=false;
             if (hmiobj[n].ENABLE)
                {
                 if (hmiobj[n].PRESSTAT==true)
                    {
                     if (hmiobj[n].PRESS==false)
                        {
                         hmiobj[n].EDGEPRESS=true;
                         hmiobj[n].REFRESH=true;
                        }
                     hmiobj[n].PRESS=true;
                    }
                 else 
                    {
                     if (hmiobj[n].PRESS==true)
                        {
                         hmiobj[n].EDGERELEASE=true;
                         hmiobj[n].REFRESH=true;
                        }
                     hmiobj[n].PRESS=false;
                    }
                }
             if (hmiobj[n].ENABLE!=hmiobj[n].ENABLE_)
                {
                 hmiobj[n].ENABLE_=hmiobj[n].ENABLE;
                 hmiobj[n].REFRESH=true;
                }

             if ((hmiobj[n].REFRESH)||(hmiobj[n].ENABLE_!=hmiobj[n].ENABLE))
                {
                 DrawButton(hmiobj[n].ID, 100);
                 hmiobj[n].REFRESH=false;
                 hmiobj[n].ENABLE_=hmiobj[n].ENABLE;
                }
            }
//******************************************** Label Services *****************************************//            
         else if (hmiobj[n].OBJECT=='label')
            {
             if (hmiobj[n].VTYPE==kVarCACHE)
               {
                //console.log(hmiobj[n].ID);
                temp=GetValVarRDObj(hmiobj[n].ID);
                if (hmiobj[n].TEXT!=temp)
                    {
                     hmiobj[n].TEXT=temp;
                     //console.log(temp, hmiobj[n].ID);
                    }
               }
             if ((hmiobj[n].TEXT!=hmiobj[n].TEXT_)||(hmiobj[n].REFRESH))
              {
//               console.log(hmiobj[n].TEXT+"-->"+hmiobj[n].TEXT_, hmiobj[n].REFRESH);
               hmiobj[n].REFRESH=false;
               hmiobj[n].TEXT_=hmiobj[n].TEXT;
               hmiobj[n].EDITED=true;           
               DrawTextLabel(hmiobj[n].ID, 50);
                cycle++;
                //console.log(cycle);

               //console.log('masuk ini', hmiobj[n].TEXT);
              }
            }
//******************************************** Label Services *****************************************//            
         else if (hmiobj[n].OBJECT=='labellocal')
            {
              hmiobj[n].EDITED=false;
              if (hmiobj[n].ID==focusid)
                  {
                  if (tick500mS) hmiobj[n].REFRESH=true;        
                  }
              if (focusid!=hmiobj[n].ID)
                  {
                   if (hmiobj[n].VTYPE==kVarCACHE)
                      {
                       //var temp=GetValVarRDObj(hmiobj[n].ID);
                       hmiobj[n].TEXT=GetValVarRDObj(hmiobj[n].ID);
                      }
                  }

              if ((hmiobj[n].TEXT!=hmiobj[n].TEXT_)||(hmiobj[n].REFRESH))
                 {
                  hmiobj[n].REFRESH=false;
                  hmiobj[n].TEXT_=hmiobj[n].TEXT;
                  if (focusid!=hmiobj[n].ID)
                      {
                       //console.log("refresh");
                       hmiobj[n].TEXTPROC=hmiobj[n].TEXT;
                      }
                  DrawTextLabelLocal(hmiobj[n].ID, 50);
                 }
             if (hmiobj[n].EDITED_)
                {
                 hmiobj[n].EDITED_=false;
                 hmiobj[n].EDITED=true;
                }
            }
//***************************************** Chart Services ******************************************//
         else if (hmiobj[n].OBJECT=='chart')
            {
             if (hmiobj[n].REFRESH)
               {
                hmiobj[n].REFRESH=false;
                DrawChart(hmiobj[n].ID);
               }
            }
//***************************************** Gauge Service ******************************************//
         else if (hmiobj[n].OBJECT=='gauge')
            {
             if (hmiobj[n].REFRESH)
                {
                 hmiobj[n].REFRESH=false;
                 DrawGauge(hmiobj[n].ID)
                }
            }
//***************************************** Histogram Services ******************************************//
         else if (hmiobj[n].OBJECT=='histo')
            {
             if (hmiobj[n].REFRESH)
               {
                hmiobj[n].REFRESH=false;
                DrawHistogram(hmiobj[n].ID);
               }
            }

//******************************************** Table Services *****************************************//
        else if (hmiobj[n].OBJECT=='table')
            {
             hmiobj[n].SELECTEDGE=false;
             if ((KeyBoardEdgePress)&&(focusid==hmiobj[n].ID))
                 {
                  if (KeyChar=='ArrowUp')
                     {
                      hmiobj[n].SELECTIDX--;
                      if (hmiobj[n].SELECTIDX<=0) hmiobj[n].SELECTIDX=0;
                      if (hmiobj[n].SELECTIDX<=hmiobj[n].OFFSET) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX;
                      hmiobj[n].REFRESH=true;
                      hmiobj[n].SELECTEDGE=true;
                     }
                  if (KeyChar=='PageUp')
                     {
                      hmiobj[n].SELECTIDX-=hmiobj[n].TOTROW;
                      if (hmiobj[n].SELECTIDX<=0) hmiobj[n].SELECTIDX=0;
                      if (hmiobj[n].SELECTIDX<=hmiobj[n].OFFSET) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX;
                      hmiobj[n].REFRESH=true;
                      hmiobj[n].SELECTEDGE=true;
                     }
                  else if (KeyChar=='ArrowDown')
                     {
                      hmiobj[n].SELECTIDX++;
                      if (hmiobj[n].SELECTIDX>=hmiobj[n].MAXROW) hmiobj[n].SELECTIDX=hmiobj[n].MAXROW-1;
                      if (hmiobj[n].SELECTIDX>=(hmiobj[n].OFFSET+hmiobj[n].TOTROW)) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX-(hmiobj[n].TOTROW-1);
                      hmiobj[n].REFRESH=true;
                      hmiobj[n].SELECTEDGE=true;
                     }
                  else if (KeyChar=='PageDown')
                     {
                      hmiobj[n].SELECTIDX+=hmiobj[n].TOTROW;
                      if (hmiobj[n].SELECTIDX>=hmiobj[n].MAXROW) hmiobj[n].SELECTIDX=hmiobj[n].MAXROW-1;
                      if (hmiobj[n].SELECTIDX>=(hmiobj[n].OFFSET+hmiobj[n].TOTROW)) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX-(hmiobj[n].TOTROW-1);
                      hmiobj[n].REFRESH=true;
                      hmiobj[n].SELECTEDGE=true;
                     }
                 }
             hmiobj[n].CHANGED=false;
             if (hmiobj[n].REFRESH)
                {
                 hmiobj[n].REFRESH=false;                    
                 DrawTable(hmiobj[n].ID, 50);
                }
            }
//******************************************** Image Services *****************************************//
        else if (hmiobj[n].OBJECT=='image')
            {
             if ((hmiobj[n].REFRESH)||(hmiobj[n].SRC!=hmiobj[n].SRC_))
                {
                 hmiobj[n].SRC_=hmiobj[n].SRC;
                 hmiobj[n].REFRESH=false;
                 //console.log(id, 'here');
                 DrawImageX(hmiobj[n].ID, 100);
                }
            }
//******************************************** Option Services *****************************************//
        else if (hmiobj[n].OBJECT=='option')
            {
             hmiobj[n].CHANGED=false;   
             if ((KeyBoardEdgePress)&&(focusid==hmiobj[n].ID))
                 {
                  if (KeyChar=='ArrowUp')
                     {
                      hmiobj[n].SELECTIDX--;
                      if (hmiobj[n].SELECTIDX<=0) hmiobj[n].SELECTIDX=0;
                      //if (hmiobj[n].SELECTIDX<=hmiobj[n].OFFSET) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX;
                      hmiobj[n].REFRESH=true;
                     }
                  if (KeyChar=='PageUp')
                     {
                      hmiobj[n].SELECTIDX-=hmiobj[n].TOTROW;
                      if (hmiobj[n].SELECTIDX<=0) hmiobj[n].SELECTIDX=0;
                      //if (hmiobj[n].SELECTIDX<=hmiobj[n].OFFSET) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX;
                      hmiobj[n].REFRESH=true;
                     }
                  else if (KeyChar=='ArrowDown')
                     {
                      hmiobj[n].SELECTIDX++;
                      if (hmiobj[n].SELECTIDX>=hmiobj[n].MAXITEM) hmiobj[n].SELECTIDX=hmiobj[n].MAXITEM-1;
                      //if (hmiobj[n].SELECTIDX>=(hmiobj[n].OFFSET+hmiobj[n].TOTROW)) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX-(hmiobj[n].TOTROW-1);
                      hmiobj[n].REFRESH=true;
                     }
                  else if (KeyChar=='PageDown')
                     {
                      hmiobj[n].SELECTIDX+=hmiobj[n].TOTROW;
                      if (hmiobj[n].SELECTIDX>=hmiobj[n].MAXITEM) hmiobj[n].SELECTIDX=hmiobj[n].MAXITEM-1;
                      //if (hmiobj[n].SELECTIDX>=(hmiobj[n].OFFSET+hmiobj[n].TOTROW)) hmiobj[n].OFFSET=hmiobj[n].SELECTIDX-(hmiobj[n].TOTROW-1);
                      hmiobj[n].REFRESH=true;
                     }
                  else if (KeyChar=='Enter')
                     {
                      hmiobj[n].SELECTION=false;
                      hmiobj[n].REFRESH=true;  
                     }
                 }                
             if ((hmiobj[n].SELECTIDX!=hmiobj[n].SELECTIDX_)||(hmiobj[n].REFRESH))
                  {
                   //console.log('refresh option');
                   hmiobj[n].REFRESH=false;
                   hmiobj[n].SELECTIDX_=hmiobj[n].SELECTIDX;
                   DrawOption(hmiobj[n].ID, 100);
                  }
            }            
//*****************************************************************************************************//
         else if (hmiobj[n].OBJECT=='calendar')
            {
             if ((KeyBoardEdgePress)&&(focusid==hmiobj[n].ID))
                {
                 if ((KeyChar=='Escape')||(KeyChar=='Enter'))
                    {
                     hmiobj[n].SELECTION=false;
                     hmiobj[n].REFRESH=true;
                     //console.log('Key here...');
                    }
                 
                }
             if (hmiobj[n].REFRESH)
                {
                 hmiobj[n].REFRESH=false;
                 DrawCalendar(hmiobj[n].ID, 100);   
                }
            }   
//*****************************************************************************************************//            
         else if (hmiobj[n].OBJECT=='progressbar')
            {
             if (hmiobj[n].REFRESH)
                {
                 hmiobj[n].REFRESH=false;
                 DrawProgressBar(hmiobj[n].ID)
                }
            }
        }
     HMICycle++;
    }




//*****************************************************************************************************//
//                                              Delete Object                                          //
//*****************************************************************************************************//
function DeleteObjHMI(id)
{
 var n;   
 if (hmiobj.length==0) return;
 for (n=0; n<hmiobj.length; n++)
     {
       if (hmiobj[n].ID==id)
        {
          console.log("Before", hmiobj);
          delete hmiobj[n];            
          const element = document.getElementById('div'+id);
          element.remove();
          console.log("After", hmiobj);
          break;
        }
     }
}


//*****************************************************************************************************//
//                                              Button Object                                         //
//*****************************************************************************************************//
function KeyEdgePressed(id)
{
 var n=GetID(id);

 if (hmiobj[n].OBJECT=='button')
    {
     if (hmiobj[n].EDGEPRESS==true) return(true);
     else return(false);
    }
}


function KeyEdgeRelease(id)
{
 var n=GetID(id);

 if (hmiobj[n].OBJECT=='button')
    {
     if (hmiobj[n].EDGERELEASE==true) return(true);
     else return(false);
    }
}


function KeyPress(id)
{
 var n=GetID(id);

 if (hmiobj[n].OBJECT=='button')
    {
     if (hmiobj[n].PRESSTAT==true) return(true);
     else return(false);
    }
}


function PressButton(id)
{
 var n=GetID(id);

 if (hmiobj[n].ENABLE==false) return;
 focustag=id;
 hmiobj[n].PRESSTAT=true;
 DrawButton(id, 50);
 if (hmiobj[n].LINK) submit(hmiobj[n].LINK, '', '');
}
 

function ReleaseButton(id)
{
 var n=GetID(id);

 if (hmiobj[n].ENABLE==false) return;
 hmiobj[n].PRESSTAT=false;
 DrawButton(id, 50);
}


function SamePosXId(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return(hmiobj[n].LEFT*100/resX);
  return(-1);
}

function GetAfterPosXId(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return((hmiobj[n].LEFT+hmiobj[n].WIDHT)*100/resX);
  return(-1);
}

function SameWidth(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return(hmiobj[n].WIDHT*100/resX);
  return(-1);    
}


function SamePosYId(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return(hmiobj[n].TOP*100/resY);
  return(-1);
}

function GetAfterPosYId(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return((hmiobj[n].TOP+hmiobj[n].HEIGHT)*100/resY);
  return(-1);
}

function SameHeight(id)
{
  var temp;
  var n=GetID(id);
  if (n>=0) return(hmiobj[n].HEIGHT*100/resY);
  return(-1);    
}


//************************************ Create Button **********************************//
function CreateButtonNew(id, left, top, width, height, src_press, src_release, stringpress, stringrelease, fontsize, fonttype, keydown, keyup, colpress, colrelease, link, position)
{
 hmiobj.push({ OBJECT:'button', ID:id, TEXTPRESS:stringpress, TEXTRELEASE:stringrelease, FONTSIZE:resY*fontsize/100, FONTTYPE:fonttype,
               TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               SRCPRESS:src_press, SRCRELEASE:src_release, KEYPRESS:keydown, RELEASE:keyup, COLOR_PRESS:colpress, COLOR_RELEASE:colrelease,
               PRESSTAT:false, PRESS:false, EDGEPRESS:false, EDGERELEASE:false, REFRESH:false, LINK:link, ENABLE:true, ENABLE_:true, FIRSTDRAW:false});

 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 //vdiv.style.position="absolute";
 
 vdiv.style.position=position;      //"fixed";
 
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;      //width;
 vdiv.style.height=hmiobj[n].HEIGHT;    //height;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;      //width;    
 vinput.height=hmiobj[n].HEIGHT;    //height;  
 vinput.style="border:0px solid";
 vinput.style.background="transparent";
 if (keydown!=null) vinput.setAttribute("onmousedown", keydown);
 if (keyup!=null) vinput.setAttribute("onmouseup", keyup);
 if (keydown!=null) vinput.setAttribute("ontouchstart", keydown);
 if (keyup!=null) vinput.setAttribute("ontouchend", keyup);

 var vinputimg = document.createElement('img');        
 document.body.appendChild(vinputimg); 
 vinputimg.setAttribute("id", "img"+id);
 vinputimg.src=src_release;
 vinputimg.style.display='none';   //       'none';//'block';    //block
 vinputimg.style.position='absolute';
 DrawButton(id, 500);
}


function DrawButton(id, timeout)
{
 var str=null;  
 var n=GetID(id);
 if (hmiobj[n].FIRSTDRAW)
     {
       var ctx = document.getElementById(id).getContext("2d");
       var img = document.getElementById("img"+id);
       
       ctx.beginPath();
       ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;

       if (hmiobj[n].ENABLE)
          {
           if (hmiobj[n].PRESSTAT==true)
              {
               ctx.fillStyle = hmiobj[n].COLOR_PRESS; //"red";//color;
               ctx.textAlign = "center";
               img.src=hmiobj[n].SRCPRESS;
               str=hmiobj[n].TEXTPRESS;
              }
           else
              {
               ctx.fillStyle = hmiobj[n].COLOR_RELEASE; //"red";//color;
               ctx.textAlign = "center";
               img.src=hmiobj[n].SRCRELEASE;
               str=hmiobj[n].TEXTRELEASE;
              }
          }
       else
          {
           ctx.fillStyle = "gray";
           ctx.textAlign = "center";
           img.src=hmiobj[n].SRCPRESS;
           str=hmiobj[n].TEXTPRESS
          }
       
       ctx.beginPath();
       var temp=hmiobj[n].FONTSIZE;
       temp=(hmiobj[n].HEIGHT+0.7*temp)/2;
       setTimeout(function()
             {
              ctx.drawImage(img, 0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
              ctx.fillText(str, hmiobj[n].WIDHT/2, temp);
              },timeout);
       ctx.stroke();          
     }
 else
    {
      var canvas = document.getElementById(id);
      var ctx = canvas.getContext("2d");
      var img = document.getElementById("img" + id);
       str=hmiobj[n].TEXTRELEASE;
       var temp=hmiobj[n].FONTSIZE;
       temp=(hmiobj[n].HEIGHT+0.7*temp)/2;
       //var ctx = vcanvas.getContext("2d");
       
       // Create image in memory
       var img = new Image();
       img.src = hmiobj[n].SRCRELEASE;
       img.onload = function() {
           ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
           ctx.fillStyle = hmiobj[n].COLOR_RELEASE; //"red";//color;
           ctx.textAlign = "center";
           ctx.clearRect(0, 0, canvas.width, canvas.height); // optional
           ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
           ctx.fillText(str, hmiobj[n].WIDHT/2, temp);
           ctx.stroke();
       };
     hmiobj[n].FIRSTDRAW=true; 
    }
}


/*

    var vcanvas = document.createElement('canvas');
    vcanvas.setAttribute("id", id); 
    vdiv.appendChild(vcanvas);
    vcanvas.style.position = 'absolute';
    vcanvas.style.top = 0;
    vcanvas.style.left = 0;
    vcanvas.width = resX*width/100;    
    vcanvas.height = resY*height/100;
    vcanvas.style.border = "0px solid";
    vcanvas.style.background = "transparent";
    
    var ctx = vcanvas.getContext("2d");
    
    // Create image in memory
    var img = new Image();
    img.src = filename;
    img.onload = function() {
        ctx.clearRect(0, 0, vcanvas.width, vcanvas.height); // optional
        ctx.drawImage(img, 0, 0, vcanvas.width, vcanvas.height);
        ctx.stroke();
    };

*/

/*
function DrawButton(id, timeout)
{
 var n=GetID(id);
 var ctx = document.getElementById(id).getContext("2d");
 var img = document.getElementById("img"+id);
 var str=null;
 ctx.beginPath();
 ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;

 if (hmiobj[n].ENABLE)
    {
     if (hmiobj[n].PRESSTAT==true)
        {
         ctx.fillStyle = hmiobj[n].COLOR_PRESS; //"red";//color;
         ctx.textAlign = "center";
         img.src=hmiobj[n].SRCPRESS;
         str=hmiobj[n].TEXTPRESS;
        }
     else
        {
         ctx.fillStyle = hmiobj[n].COLOR_RELEASE; //"red";//color;
         ctx.textAlign = "center";
         img.src=hmiobj[n].SRCRELEASE;
         str=hmiobj[n].TEXTRELEASE;
        }
    }
 else
    {
     ctx.fillStyle = "gray";
     ctx.textAlign = "center";
     img.src=hmiobj[n].SRCPRESS;
     str=hmiobj[n].TEXTPRESS
    }
 
 ctx.beginPath();
 var temp=hmiobj[n].FONTSIZE;
 temp=(hmiobj[n].HEIGHT+0.7*temp)/2;

 setTimeout(function()
       {
        ctx.drawImage(img, 0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
        ctx.fillText(str, hmiobj[n].WIDHT/2, temp);
        },timeout);
 ctx.stroke();    
}
*/

//*****************************************************************************************************//
//                                           Gauge Object                                               //
//*****************************************************************************************************//
function CreateGaugeNew(id, left, top, diameter, start, length, fonttype, fontSize, background, border, bordercolor, min, max, aux)
{
 hmiobj.push({ OBJECT:'gauge', ID:id, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:Math.round(resY*top/100), LEFT:Math.round(resX*left/100), DIAMETER:Math.round(resX*diameter/100)-(border/2),
               HEIGHT:Math.round(resX*diameter/100), WIDHT:Math.round(resX*diameter/100), BORDER:border, BORDERCOLOR:bordercolor,
               REFRESH:false, LINEWIDTH:1, OFFSET:0, START:start, LENGTH:length,  VAL:0, MIN:min, MAX:max, UPDATE:true, AUX:aux, HAND1VAL:0, HAND2VAL:0,
               });    
 var n=GetID(id);
 var i, k, m;//, temp;
  
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;   //300;  //hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;  //300; //hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");

 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.top=0;
 vinput.left=0;
 vinput.width=hmiobj[n].WIDHT;  //+hmiobj[n].BORDER;  //hmiobj[n].DIAMETER+(thick);   //300;//hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;      //+hmiobj[n].BORDER;    //hmiobj[n].DIAMETER+(thick);  //300;//hmiobj[n].HEIGHT;
 vinput.style.border=border+border+bordercolor;
 vinput.style.background=background;

 var vinput1 = document.createElement('canvas');
 vinput1.setAttribute("id", id+"_");
 vdiv.appendChild(vinput1);
 vinput1.style.position='absolute';
 vinput1.top=0;
 vinput1.left=0;
 vinput1.width=hmiobj[n].WIDHT;  //+hmiobj[n].BORDER;  //hmiobj[n].DIAMETER+(thick);   //300;//hmiobj[n].WIDHT;
 vinput1.height=hmiobj[n].HEIGHT;      //+hmiobj[n].BORDER;    //hmiobj[n].DIAMETER+(thick);  //300;//hmiobj[n].HEIGHT;
 vinput1.style.border=border+border+bordercolor;
 vinput1.style.background=background;
 DrawGauge(id);
}


function DrawGauge(id)
{
 var n=GetID(id);
 var tStart;
 var radStart;
 var radEnd;
 var n=GetID(id);
 var temp;
 var start;
 var length;
 var x, y, x1,y1, div;
 var i;
 var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
 var ctx_ = document.getElementById(id+"_").getContext("2d");     //c.getContext("2d");
 //console.log(hmiobj[n].LEFT, hmiobj[n].TOP, hmiobj[n].DIAMETER);
//***************************************************************************************************// Draw Frame
 if (hmiobj[n].UPDATE)
    {
     ctx.beginPath();
     ctx.fillStyle = "white";   //hmiobj[n].SEGY[i].TEXTCOLOR;
     ctx.lineWidth=2;
     ctx.strokeStyle = hmiobj[n].BORDERCOLOR;   ///"yellow"; //"#505050";
     start=hmiobj[n].START;
     length=hmiobj[n].LENGTH;
     if (length==360)
        {
         tStart=(start)+180;
         radStart=(tStart*Math.PI)/180;
         radEnd=((tStart+length)*Math.PI)/180;
        }
     else
        {    
         tStart=(start-1)+180;
         radStart=(tStart*Math.PI)/180;
         radEnd=((tStart+length+2)*Math.PI)/180;
        }
    // console.log(tStart, radStart, radEnd);
     ctx.arc((ctx.lineWidth)+hmiobj[n].DIAMETER*0.5, (ctx.lineWidth+hmiobj[n].DIAMETER*0.5), (hmiobj[n].DIAMETER*0.5), radStart, radEnd, false);
     ctx.fill();
     ctx.stroke();
    }
//***************************************************************************************************// Draw Scale
if (hmiobj[n].UPDATE)
    {
     div=12;
     for (i=0; i<=div; i++)
        {
         ctx.beginPath();
         ctx.fillStyle = "white";   //hmiobj[n].SEGY[i].TEXTCOLOR;
         ctx.lineWidth=5;
         ctx.strokeStyle = "black";
         temp=180-(i*length/div)-hmiobj[n].START;
         y1=(Math.round((hmiobj[n].DIAMETER/2)-20)*Math.sin(Math.PI*temp/180));
         x1=(Math.round((hmiobj[n].DIAMETER/2)-20)*Math.cos(Math.PI*temp/180));
         y=(Math.round((hmiobj[n].DIAMETER/2))*Math.sin(Math.PI*temp/180));
         x=(Math.round((hmiobj[n].DIAMETER/2))*Math.cos(Math.PI*temp/180));
            // console.log(hmiobj[n].DIAMETER, temp, x, y);
         ctx.moveTo(Math.round(hmiobj[n].WIDHT/2)+x1, Math.round(hmiobj[n].HEIGHT/2)-y1);
         ctx.lineTo(Math.round(hmiobj[n].WIDHT/2)+x, Math.round(hmiobj[n].WIDHT/2)-y);
         ctx.stroke();
        }
    }
//***************************************************************************************************// Draw Pointer
 ctx_.beginPath();
 ctx_.clearRect(0, 0, hmiobj[n].DIAMETER, hmiobj[n].DIAMETER);
 ctx_.stroke();
 //hmiobj[n].HAND1VAL=30;
 //hmiobj[n].HAND2VAL=60;
//***************************************************************************************************// Draw Pointer Hand 1 
 if (hmiobj[n].HAND1VAL>=hmiobj[n].MAX) temp=hmiobj[n].MAX;
 else if (hmiobj[n].HAND1VAL<=hmiobj[n].MIN) temp=hmiobj[n].MIN;
 else temp=hmiobj[n].HAND1VAL;
 temp-=hmiobj[n].MIN;
 temp/=(hmiobj[n].MAX-hmiobj[n].MIN);
 temp*=hmiobj[n].LENGTH;
 
 if (temp<=hmiobj[n].LENGTH) temp=180-temp-hmiobj[n].START;
 else temp=180-hmiobj[n].LENGTH-hmiobj[n].START;

 //if (hmiobj[n].VAL<=hmiobj[n].LENGTH) temp=180-hmiobj[n].VAL-hmiobj[n].START;
 //else temp=temp=180-hmiobj[n].LENGTH-hmiobj[n].START;
 y=(hmiobj[n].DIAMETER/2-45)*Math.sin(Math.PI*temp/180);
 x=(Math.round((hmiobj[n].DIAMETER/2)-45)*Math.cos(Math.PI*temp/180));
// console.log(hmiobj[n].DIAMETER, temp, x, y);
 ctx_.beginPath();
 //ctx_.clearRect(0, 0, hmiobj[n].DIAMETER, hmiobj[n].DIAMETER);
 ctx_.fillStyle = "white";   //hmiobj[n].SEGY[i].TEXTCOLOR;
 ctx_.lineWidth=7;
 ctx_.strokeStyle = "blue"; //"#505050"; 
 ctx_.moveTo(Math.round(hmiobj[n].WIDHT/2), Math.round(hmiobj[n].HEIGHT/2));
 ctx_.lineTo(Math.round(hmiobj[n].WIDHT/2)+x, Math.round(hmiobj[n].WIDHT/2)-y);
 ctx_.stroke();
//***************************************************************************************************// Draw Pointer Hand 2 
 if (hmiobj[n].HAND2VAL>=hmiobj[n].MAX) temp=hmiobj[n].MAX;
 else if (hmiobj[n].HAND2VAL<=hmiobj[n].MIN) temp=hmiobj[n].MIN;
 else temp=hmiobj[n].HAND2VAL;
 temp-=hmiobj[n].MIN;
 temp/=(hmiobj[n].MAX-hmiobj[n].MIN);
 temp*=hmiobj[n].LENGTH;
 if (temp<=hmiobj[n].LENGTH) temp=180-temp-hmiobj[n].START;
 else temp=180-hmiobj[n].LENGTH-hmiobj[n].START;
 //if (hmiobj[n].VAL<=hmiobj[n].LENGTH) temp=180-hmiobj[n].VAL-hmiobj[n].START;
 //else temp=temp=180-hmiobj[n].LENGTH-hmiobj[n].START;
 y=(hmiobj[n].DIAMETER/2-45)*Math.sin(Math.PI*temp/180);
 x=(Math.round((hmiobj[n].DIAMETER/2)-45)*Math.cos(Math.PI*temp/180));
// console.log(hmiobj[n].DIAMETER, temp, x, y);
 ctx_.beginPath();
 //ctx_.clearRect(0, 0, hmiobj[n].DIAMETER, hmiobj[n].DIAMETER);
 ctx_.fillStyle = "white";   //hmiobj[n].SEGY[i].TEXTCOLOR;
 ctx_.lineWidth=7;
 ctx_.strokeStyle = "blue"; //"#505050"; 
 ctx_.moveTo(Math.round(hmiobj[n].WIDHT/2), Math.round(hmiobj[n].HEIGHT/2));
 ctx_.lineTo(Math.round(hmiobj[n].WIDHT/2)+x, Math.round(hmiobj[n].WIDHT/2)-y);
 ctx_.stroke(); 
//***************************************************************************************************// Draw Pointer Main
 if (hmiobj[n].VAL>=hmiobj[n].MAX) temp=hmiobj[n].MAX;
 else if (hmiobj[n].VAL<=hmiobj[n].MIN) temp=hmiobj[n].MIN;
 else temp=hmiobj[n].VAL;
 temp-=hmiobj[n].MIN;
 temp/=(hmiobj[n].MAX-hmiobj[n].MIN);
 temp*=hmiobj[n].LENGTH;
 
 if (temp<=hmiobj[n].LENGTH) temp=180-temp-hmiobj[n].START;
 else temp=180-hmiobj[n].LENGTH-hmiobj[n].START;

 //if (hmiobj[n].VAL<=hmiobj[n].LENGTH) temp=180-hmiobj[n].VAL-hmiobj[n].START;
 //else temp=temp=180-hmiobj[n].LENGTH-hmiobj[n].START;
 y=(Math.round((hmiobj[n].DIAMETER/2)-5)*Math.sin(Math.PI*temp/180));
 x=(Math.round((hmiobj[n].DIAMETER/2)-5)*Math.cos(Math.PI*temp/180));
// console.log(hmiobj[n].DIAMETER, temp, x, y);
 ctx_.beginPath();
 //ctx_.clearRect(0, 0, hmiobj[n].DIAMETER, hmiobj[n].DIAMETER);
 ctx_.fillStyle = "white";   //hmiobj[n].SEGY[i].TEXTCOLOR;
 ctx_.lineWidth=7;
 ctx_.strokeStyle = "red"; //"#505050"; 
 ctx_.moveTo(Math.round(hmiobj[n].WIDHT/2), Math.round(hmiobj[n].HEIGHT/2));
 ctx_.lineTo(Math.round(hmiobj[n].WIDHT/2)+x, Math.round(hmiobj[n].WIDHT/2)-y);
 ctx_.stroke();
//***************************************************************************************************// Draw TEXT
 ctx_.beginPath();
 ctx_.fillStyle = "black";
 ctx_.textAlign = "center";
 fontsize=hmiobj[n].FONTSIZE;   //"";=Math.round(hmiobj[n].SEGY[i].FONTSIZE);
 temp=(fontsize*0.7)/2;
 ctx_.font = fontsize+'px '+hmiobj[n].FONTTYPE;  //"Arial Bold";   //hmiobj[n].SEGY[i].FONTSIZE+'px '+"Arial";
 ctx_.fillText(hmiobj[n].VAL, hmiobj[n].WIDHT/2, -20+temp+hmiobj[n].HEIGHT/2);
 ctx_.stroke();
 hmiobj[n].UPDATE=false; 
}



//*****************************************************************************************************//
//                                           Histogram Object                                          //
//*****************************************************************************************************//
function CreateHistogramNew(id, left, top, width, height, param, segx, segy, header, fonttype, fontSize, background, border, bordercolor)
{
 hmiobj.push({ OBJECT:'histo', ID:id, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               REFRESH:false, EDITED:false, LINEWIDTH:1, OFFSET:0, PARAM:param, SEGX:segx, SEGY:segy, CURSORPOS:0, HEADER:header,
               });    
 var n=GetID(id);
 var i, k, m;//, temp;

 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");

 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.top=0;
 vinput.left=0;
 vinput.width=hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style.border=border+border+bordercolor;
 vinput.style.background=background;
 //vinput.setAttribute("onmousedown", "MouseKeydown(this.id)");
 for (i=0; i<hmiobj[n].PARAM.length; i++)
    {
     buffhisto.push({ID:id+i, BUFFER:Array(hmiobj[n].PARAM[i].SIZE)});
    }
 for (i=0; i<hmiobj[n].PARAM.length; i++)
    {
     m=GetHistogramBuffID(id+i);
     for (j=0; j<hmiobj[n].PARAM[i].SIZE; j++) buffhisto[m].BUFFER[j]=null;
    }
 DrawHistogram(id);
}


function GetHistogramBuffID(id)
    {
     var n;

     for (n=0; n<buffhisto.length; n++)
        {
         if (buffhisto[n].ID==id) return(n);
        }
     return(-1);
    }


function DrawHistogram(id)
{
  var x, i, j, temp, tempy;
  var n=GetID(id);
  var scalex;
  var scaley;
  //var offx;
  //var min, max, delta;
  var avgval;
  var fontsize;
  var buff=[];
  var tot;

  if (n<0) return;
  
  var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
  ctx.clearRect(0, 0, document.getElementById(id).width, document.getElementById(id).height);       // Clear All
/*****************************************************************************************/     // Draw Line
  ctx.beginPath();
  ctx.lineWidth=1;
  ctx.strokeStyle = "#505050";
  for (i=0; i<=hmiobj[n].SEGX.length; i++)
      {
       ctx.moveTo(i*hmiobj[n].WIDHT/(hmiobj[n].SEGX.length+1), 0);
       ctx.lineTo(i*hmiobj[n].WIDHT/(hmiobj[n].SEGX.length+1), hmiobj[n].HEIGHT);
      }
  ctx.stroke();

  ctx.beginPath();
  ctx.lineWidth=1;
  ctx.strokeStyle = "#505050";
  for (i=0; i<=hmiobj[n].SEGY.length; i++)
      {
       ctx.moveTo(0, i*hmiobj[n].HEIGHT/(hmiobj[n].SEGY.length+1));
       ctx.lineTo(hmiobj[n].WIDHT, i*hmiobj[n].HEIGHT/(hmiobj[n].SEGY.length+1));
      }
  ctx.stroke();
/*****************************************************************************************/     // Draw Header
  fontsize=Math.round(hmiobj[n].FONTSIZE);
  ctx.beginPath();
  ctx.fillStyle =  "white";
  ctx.textAlign = "center";
  temp=((fontsize*1.5)+0.7*fontsize)/2;
  ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
  ctx.fillText(hmiobj[n].HEADER, hmiobj[n].WIDHT/2, temp);
  ctx.stroke();  
/*****************************************************************************************/      // Draw Histogram
  var scalex_;
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       m=GetHistogramBuffID(id+i);
       buff=[];
       tot=hmiobj[n].PARAM[i].MAX-hmiobj[n].PARAM[i].MIN;
//       console.log("total:"+tot+"  buff Length:"+buffhisto[m].BUFFER.length+", "+hmiobj[n].PARAM[0].SIZE);
       for (j=0; j<tot; j++) buff[j]=0;

       if (buffhisto[m].BUFFER.length>=hmiobj[n].PARAM[i].SIZE)
           {
            for (x=0; x<hmiobj[n].PARAM[i].SIZE; x++)
                {
                 if (buffhisto[m].BUFFER[x]!=null)
                    {
                     if ((buffhisto[m].BUFFER[x]>=hmiobj[n].PARAM[i].MIN)&&(buffhisto[m].BUFFER[x]<=hmiobj[n].PARAM[i].MAX))
                         {
                          temp=Math.round(buffhisto[m].BUFFER[x]);
                          temp=temp-hmiobj[n].PARAM[i].MIN;
                          buff[temp]++;
                          //console.log(buffhisto[m].BUFFER[x], hmiobj[n].PARAM[i].MIN);
                         }
                    }
                }

            var scaley_=0;                
            for (j=0; j<tot; j++) if (buff[j]>scaley_) scaley_=buff[j];
//            console.log(scaley_);
            scaley=hmiobj[n].HEIGHT/scaley_;

            ctx.beginPath();
            ctx.strokeStyle = hmiobj[n].PARAM[i].SHADOW;
            ctx.lineWidth=2;
            ctx.fillStyle=hmiobj[n].PARAM[i].COLOR;
            scalex=hmiobj[n].WIDHT/tot;
            for (j=0; j<tot; j++)
                {
                 if (buff[j]>hmiobj[n].HEIGHT)
                    {
                     if ((scaleyStatic)>hmiobj[n].HEIGHT/buff[j])
                        {
                         scaleyStatic=hmiobj[n].HEIGHT/buff[j];
                        }
                    }
                }
            for (j=0; j<tot; j++)
                {
                 temp=Math.round(j*(scalex));
                 //tempy=Math.round(buff[j]*scaleyStatic);
                 tempy=Math.round(buff[j]*scaley);
                 if (tempy>hmiobj[n].HEIGHT) tempy=hmiobj[n].HEIGHT;
                 ctx.fillRect(Math.round(temp-scalex/2), hmiobj[n].HEIGHT-tempy, scalex, hmiobj[n].HEIGHT);
                 ctx.moveTo(Math.round(temp+scalex/2-1), hmiobj[n].HEIGHT);
                 ctx.lineTo(Math.round(temp+scalex/2-1), hmiobj[n].HEIGHT-(tempy-1));
                }

            ctx.stroke();            
           }
      }
/*****************************************************************************************/      // Draw Scale Text
  //temp=hmiobj[n].PARAM
  for (i=0; i<hmiobj[n].SEGX.length; i++)
    {
     ctx.beginPath();
     ctx.textAlign = "center";
     ctx.fillStyle = hmiobj[n].SEGX[i].TEXTCOLOR;
     ctx.font = hmiobj[n].SEGX[i].FONTSIZE+'px '+"Arial";
     ctx.fillText(hmiobj[n].SEGX[i].TEXT, hmiobj[n].SEGX[i].X*hmiobj[n].WIDHT/100, hmiobj[n].SEGX[i].Y*hmiobj[n].HEIGHT/100);
     ctx.stroke();
    }

  for (i=0; i<hmiobj[n].SEGY.length; i++)
    {
     ctx.beginPath();
     ctx.fillStyle = hmiobj[n].SEGY[i].TEXTCOLOR;
     fontsize=Math.round(hmiobj[n].SEGY[i].FONTSIZE);
     temp=(fontsize*0.7)/2;
     ctx.font = hmiobj[n].SEGY[i].FONTSIZE+'px '+"Arial";
     ctx.fillText(hmiobj[n].SEGY[i].TEXT, hmiobj[n].SEGY[i].X*hmiobj[n].WIDHT/100, temp+hmiobj[n].SEGY[i].Y*hmiobj[n].HEIGHT/100);
     ctx.stroke();
    }
/*****************************************************************************************/      // Calc Standard Deviation
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       m=GetHistogramBuffID(id+i);
       buff=[];
       for (j=0; j<tot; j++) buff[j]=0;
       avg=0;
       for (x=0; x<hmiobj[n].PARAM[i].SIZE; x++)
            {
             avg+=buffhisto[m].BUFFER[x];
            }
       avg/=hmiobj[n].PARAM[i].SIZE;
       avg=Math.round(avg);
       sd=0;
       for (x=0; x<hmiobj[n].PARAM[i].SIZE; x++)
            {
             temp=buffhisto[m].BUFFER[x]-avg;
             temp*=temp;
             sd+=temp;
            }
       sd/=hmiobj[n].PARAM[i].SIZE;
       sd=Math.sqrt(sd);
       sd=Math.round(sd);
       //console.log(avg, sd);

       for (i=0; i<hmiobj[n].PARAM.length; i++)
            {    
             ctx.beginPath();
             ctx.strokeStyle = "white";//hmiobj[n].PARAM[i].COLOR;
             ctx.lineWidth=1;
             temp=avg-hmiobj[n].PARAM[i].MIN;
             temp*=hmiobj[n].WIDHT;
             temp/=(hmiobj[n].PARAM[i].MAX-hmiobj[n].PARAM[i].MIN);
             temp=Math.round(temp);
             ctx.moveTo(temp, hmiobj[n].HEIGHT);
             ctx.lineTo(temp, 1);
             ctx.stroke();

             ctx.beginPath();
             ctx.strokeStyle = "yellow";//hmiobj[n].PARAM[i].COLOR;
             ctx.lineWidth=1;
             temp=(avg-sd)-hmiobj[n].PARAM[i].MIN;
             temp*=hmiobj[n].WIDHT;
             temp/=(hmiobj[n].PARAM[i].MAX-hmiobj[n].PARAM[i].MIN);
             temp=Math.round(temp);
             ctx.moveTo(temp, hmiobj[n].HEIGHT);
             ctx.lineTo(temp, 1);
             ctx.stroke(); 

             ctx.beginPath();
             ctx.strokeStyle = "yellow";//hmiobj[n].PARAM[i].COLOR;
             ctx.lineWidth=1;
             temp=(avg+sd)-hmiobj[n].PARAM[i].MIN;
             temp*=hmiobj[n].WIDHT;
             temp/=(hmiobj[n].PARAM[i].MAX-hmiobj[n].PARAM[i].MIN);
             temp=Math.round(temp);
             ctx.moveTo(temp, hmiobj[n].HEIGHT);
             ctx.lineTo(temp, 1);
             ctx.stroke(); 
            }
      }    
}


//*****************************************************************************************************//
//                                              Chart Object                                           //
//*****************************************************************************************************//
function MouseKeydown(id)
{
 var n=GetID(id);
 hmiobj[n].CURSORPOS=MouseX;
}


function GetChartBuffID(id)
    {
     var n;

     for (n=0; n<buffchart.length; n++)
        {
         if (buffchart[n].ID==id) return(n);
        }
     return(-1);
    }

function GetChartTimeBuffID(id)
    {
     var n;

     for (n=0; n<buffcharttime.length; n++)
        {
         if (buffcharttime[n].ID==id) return(n);
        }
     return(-1);
    }


function CreateChartNew(id, left, top, width, height, param, segx, segy, header, fonttype, fontSize, background, border, headercolor)
{
 hmiobj.push({ OBJECT:'chart', ID:id, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               REFRESH:false, EDITED:false, LINEWIDTH:1, OFFSET:0, PARAM:param, SEGX:segx, SEGY:segy, CURSORPOS:0, HEADER:header, HEADERCOLOR:headercolor,
               });    
 var n=GetID(id);
 var i, k, m;//, temp;

 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");

 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.top=0;
 vinput.left=0;
 vinput.width=hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style.border=border+border+" black";
 vinput.style.background=background;
 vinput.setAttribute("onmousedown", "MouseKeydown(this.id)");

 buffcharttime.push({ID:id, BUFFER:Array(hmiobj[n].PARAM[0].SIZE)});
 m=GetChartTimeBuffID(id);
 for (j=0; j<hmiobj[n].PARAM[0].SIZE; j++) buffcharttime[m].BUFFER[j]=null;

 for (i=0; i<hmiobj[n].PARAM.length; i++)
    {
     buffchart.push({ID:id+i, BUFFER:Array(hmiobj[n].PARAM[i].SIZE)});
    }
 for (i=0; i<hmiobj[n].PARAM.length; i++)
    {
     m=GetChartBuffID(id+i);
     for (j=0; j<hmiobj[n].PARAM[i].SIZE; j++)
        {
         buffchart[m].BUFFER[j]=null;
        }
    }
 DrawChart(id);
}



function DrawChart(id)
 {
  var x, i, j, temp, tempy;
  var n=GetID(id);
  var scalex;
  var scaley;
  var offx;
  var min, max, delta;
  var avgval;
  var fontsize;

  if (n<0) return;


  var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
  ctx.clearRect(0, 0, document.getElementById(id).width, document.getElementById(id).height);   // Clear Chart
  offx=hmiobj[n].OFFSET;
/*****************************************************************************************/     // Draw Line
  ctx.beginPath();
  ctx.lineWidth=1;
  ctx.strokeStyle = "#505050";
  for (i=0; i<=hmiobj[n].SEGX.length; i++)
      {
       ctx.moveTo(i*hmiobj[n].WIDHT/(hmiobj[n].SEGX.length+1), 0);
       ctx.lineTo(i*hmiobj[n].WIDHT/(hmiobj[n].SEGX.length+1), hmiobj[n].HEIGHT);
      }
  ctx.stroke();

  ctx.beginPath();
  ctx.lineWidth=1;
  ctx.strokeStyle = "#505050";
  for (i=0; i<=hmiobj[n].SEGY.length; i++)
      {
       ctx.moveTo(0, i*hmiobj[n].HEIGHT/(hmiobj[n].SEGY.length+1));
       ctx.lineTo(hmiobj[n].WIDHT, i*hmiobj[n].HEIGHT/(hmiobj[n].SEGY.length+1));
      }
  ctx.stroke();
/*****************************************************************************************/     // Draw Header
  fontsize=Math.round(hmiobj[n].FONTSIZE);
  ctx.beginPath();
  ctx.fillStyle =  hmiobj[n].HEADERCOLOR;
  ctx.textAlign = "center";
  temp=((fontsize*1.5)+0.7*fontsize)/2;
  ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
  ctx.fillText(hmiobj[n].HEADER, hmiobj[n].WIDHT/2, temp);
  ctx.stroke();  
/*****************************************************************************************/      // Draw Scale Text
  ctx.beginPath();
  ctx.fillStyle =  "black";
  ctx.textAlign = "center";

  for (i=0; i<hmiobj[n].SEGX.length; i++)
    {
     ctx.font = hmiobj[n].SEGX[i].FONTSIZE+'px '+"Arial Black";
     ctx.fillText(hmiobj[n].SEGX[i].TEXT, hmiobj[n].SEGX[i].X*hmiobj[n].WIDHT/100, hmiobj[n].SEGX[i].Y*hmiobj[n].HEIGHT/100);
    }
  ctx.stroke();


  ctx.beginPath();
  for (i=0; i<hmiobj[n].SEGY.length; i++)
    {
     fontsize=Math.round(hmiobj[n].SEGY[i].FONTSIZE);
     temp=(fontsize*0.7)/2;
     ctx.font = hmiobj[n].SEGY[i].FONTSIZE+'px '+"Arial  Black";
     ctx.fillText(hmiobj[n].SEGY[i].TEXT, hmiobj[n].SEGY[i].X*hmiobj[n].WIDHT/100, temp+hmiobj[n].SEGY[i].Y*hmiobj[n].HEIGHT/100);
    }
  ctx.stroke();
/*****************************************************************************************/      // Draw LIMIT
  var limlow, limhigh, avg;
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       m=GetChartBuffID(id+i);
       min=hmiobj[n].PARAM[i].MIN;
       max=hmiobj[n].PARAM[i].MAX;
       avg=hmiobj[n].PARAM[i].AVG;
       limlow=hmiobj[n].PARAM[i].LIMITLOW;
       limhigh=hmiobj[n].PARAM[i].LIMITHIGH;

       ctx.beginPath();
       ctx.strokeStyle = hmiobj[n].PARAM[i].LIMLOWCOLOR;
       tempy=limlow-min;
       tempy*=(hmiobj[n].HEIGHT);
       tempy/=(max-min);
       //console.log(limlow, limhigh, tempy);
       ctx.moveTo(0, hmiobj[n].HEIGHT-tempy);
       ctx.lineTo(hmiobj[n].WIDHT, hmiobj[n].HEIGHT-tempy);
       ctx.stroke();

       ctx.beginPath();
       ctx.strokeStyle = hmiobj[n].PARAM[i].LIMHIGHCOLOR;
       tempy=limhigh-min;
       tempy*=(hmiobj[n].HEIGHT);
       tempy/=(max-min);
       //console.log(limlow, limhigh, tempy);
       ctx.moveTo(0, hmiobj[n].HEIGHT-tempy);
       ctx.lineTo(hmiobj[n].WIDHT, hmiobj[n].HEIGHT-tempy);
       ctx.stroke();

       ctx.beginPath();
       ctx.strokeStyle = hmiobj[n].PARAM[i].AVGCOLOR;
       tempy=avg-min;
       tempy*=(hmiobj[n].HEIGHT);
       tempy/=(max-min);
       //console.log(limlow, limhigh, tempy);
       ctx.moveTo(0, hmiobj[n].HEIGHT-tempy);
       ctx.lineTo(hmiobj[n].WIDHT, hmiobj[n].HEIGHT-tempy);
       ctx.stroke();
      }    
/*****************************************************************************************/      // Draw Chart
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       if (hmiobj[n].PARAM[i].SIZE>=hmiobj[n].WIDHT) scalex=1.0;
       else scalex=hmiobj[n].WIDHT/hmiobj[n].PARAM[i].SIZE;
       ctx.beginPath();
       m=GetChartBuffID(id+i);
       ctx.strokeStyle = hmiobj[n].PARAM[i].COLOR;
       ctx.lineWidth=1;
       min=hmiobj[n].PARAM[i].MIN;
       max=hmiobj[n].PARAM[i].MAX;
       delta=hmiobj[n].PARAM[i].MAX-hmiobj[n].PARAM[i].MIN;
       if (hmiobj[n].PARAM[i].SIZE>=hmiobj[n].WIDHT)
          {
           tempy=buffchart[m].BUFFER[offx]-min;
           tempy=hmiobj[n].HEIGHT*(tempy/delta);
           ctx.moveTo(0, hmiobj[n].HEIGHT-tempy);
           for (x=0; x<hmiobj[n].WIDHT; x++)
              {
                if (buffchart[m].BUFFER[x]==null) break;
                temp=Math.round(x*scalex);
                tempy=buffchart[m].BUFFER[offx+x]-min;
                tempy=hmiobj[n].HEIGHT*(tempy/delta);
                ctx.lineTo(x, hmiobj[n].HEIGHT-tempy);
                ctx.moveTo(x, hmiobj[n].HEIGHT-tempy);
              }
          }
       else
          {
           tempy=buffchart[m].BUFFER[0]-min;
           tempy=hmiobj[n].HEIGHT*(tempy/delta);
           ctx.moveTo(0, hmiobj[n].HEIGHT-tempy);
           for (x=0; x<hmiobj[n].PARAM[i].SIZE; x++)
              {
                if (buffchart[m].BUFFER[x]==null) break;
                temp=Math.round(x*scalex);
                tempy=buffchart[m].BUFFER[x]-min;
                tempy=hmiobj[n].HEIGHT*(tempy/delta);
                ctx.lineTo(temp, hmiobj[n].HEIGHT-tempy);
                ctx.moveTo(temp, hmiobj[n].HEIGHT-tempy);
              }
          }
        ctx.stroke();
       }
/*****************************************************************************************/      // Draw Value AVG
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       //ctx.font = hmiobj[n].PARAM[i].FONTSIZE+'px '+"Arial";
       ctx.font = '16px '+"Arial Black";
       avgval=0;        
       j=0;
       m=GetChartBuffID(id+i);
       for (x=0; x<hmiobj[n].PARAM[i].SIZE; x++)
          {
            if (buffchart[m].BUFFER[x]==null) break;
            avgval+=buffchart[m].BUFFER[x];
            j++;
          }
       avgval=avgval/j;
       ctx.beginPath();
       ctx.textAlign = "left";
       ctx.fillStyle  = "black";
       ctx.fillText("AVG:"+Math.round(avgval), 5*hmiobj[n].WIDHT/100+1, (5+(i*5))*hmiobj[n].HEIGHT/100+1);
       ctx.stroke();
       ctx.beginPath();
       ctx.textAlign = "left";
       ctx.fillStyle  = hmiobj[n].PARAM[i].COLOR;
       ctx.fillText("AVG:"+Math.round(avgval), 5*hmiobj[n].WIDHT/100, (5+(i*5))*hmiobj[n].HEIGHT/100);
       ctx.stroke();
      }
/*****************************************************************************************/      // Draw Value
  ctx.beginPath();
  ctx.lineWidth="1px";
  ctx.strokeStyle = "#C0C0C0";
  for (i=0; i<=hmiobj[n].SEGX.length; i++)
      {
       ctx.moveTo(hmiobj[n].CURSORPOS, 0);
       ctx.lineTo(hmiobj[n].CURSORPOS, hmiobj[n].HEIGHT);
      }
  ctx.stroke();

  
  for (i=0; i<hmiobj[n].PARAM.length; i++)
      {
       //ctx.font = hmiobj[n].PARAM[i].FONTSIZE+'px '+"Arial Black";
       ctx.font = "16px "+"Arial Black";
       m=GetChartBuffID(id+i);
       if (hmiobj[n].PARAM[i].SIZE>=hmiobj[n].WIDHT) scalex=1.0;
       else scalex=hmiobj[n].PARAM[i].SIZE/hmiobj[n].WIDHT;
       temp=Math.round(hmiobj[n].CURSORPOS*scalex);
       //console.log("pos: "+temp+"  scale: "+scalex);
       if (hmiobj[n].PARAM[i].SIZE>=hmiobj[n].WIDHT)
          {
           tempy=buffchart[m].BUFFER[offx+temp];
          }
       else
          {
           tempy=buffchart[m].BUFFER[temp];
          }
       ctx.beginPath();
       ctx.textAlign = "left";
       ctx.fillStyle  = "black";    //hmiobj[n].PARAM[i].COLOR;
       ctx.fillText("CUR:"+Math.round(tempy), 90*hmiobj[n].WIDHT/100+1, (5+(i*5))*hmiobj[n].HEIGHT/100+1);
       ctx.stroke();       
       ctx.beginPath();
       ctx.textAlign = "left";
       ctx.fillStyle  = hmiobj[n].PARAM[i].COLOR;
       ctx.fillText("CUR:"+Math.round(tempy), 90*hmiobj[n].WIDHT/100, (5+(i*5))*hmiobj[n].HEIGHT/100);
       ctx.stroke();       
      }       
/*****************************************************************************************/      // Draw Datetime
  
   m=GetChartTimeBuffID(id);
   temp='';
   if (buffcharttime[m].BUFFER[0]!=null)
      {
       if (hmiobj[n].PARAM[0].SIZE>=hmiobj[n].WIDHT) scalex=1.0;
       else scalex=hmiobj[n].PARAM[0].SIZE/hmiobj[n].WIDHT;
       temp=Math.round(hmiobj[n].CURSORPOS*scalex);
       if (hmiobj[n].PARAM[0].SIZE>=hmiobj[n].WIDHT)
              {
               tempy=buffcharttime[m].BUFFER[offx+temp];
              }
       else
              {
               tempy=buffcharttime[m].BUFFER[temp];
              }
       temp=ConvDatetimetoText(tempy);     
      }
   ctx.beginPath();
   ctx.textAlign = "left";
   ctx.fillStyle  = hmiobj[n].PARAM[0].COLOR;
   if (hmiobj[n].CURSORPOS<hmiobj[n].WIDHT*0.8) ctx.fillText("TIME:"+temp, hmiobj[n].CURSORPOS+5, 0.8*hmiobj[n].HEIGHT);
   else ctx.fillText("TIME:"+temp, hmiobj[n].CURSORPOS-hmiobj[n].WIDHT*0.15, 0.8*hmiobj[n].HEIGHT);
   ctx.stroke();   
 }

//*****************************************************************************************************//
//                                              Audio Object                                           //
//*****************************************************************************************************//
function CreateAudio(id, filename)
{
 hmiobj.push({ OBJECT:'audio', ID:id, FILENAME:filename,
            });
 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 var vinput = document.createElement('audio');
 vinput.setAttribute("id", id);
 vdiv.appendChild(vinput);
 vinput.src=filename;
 vinput.type="audio/mpeg";
}


function PlayAudio(id, filename)
{
 var n=GetID(id);
 var playit = document.getElementById(id);
 playit.src=filename;
 playit.play();
}


//*****************************************************************************************************//
//                                              Label Object                                           //
//*****************************************************************************************************//
function CreateLabelNew(id, left, top, width, height, fontSize, fonttype, text, color, background, border, bordercolor, keydown, type, align, vtype, vparam0, vparam1, vparam2, position)
{
 if (vtype==kVarNONE)
    {
     hmiobj.push({ OBJECT:'label', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, ENABLE:true,
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2,
               });
    }
 else if (vtype==kVarDBASE)
    {
     if ((vparam0==null)||(vparam1==null)||(vparam2==null)) return(false);
     else
        {
         hmiobj.push({ OBJECT:'label', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
                   COLOR:color, BACKGROND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, ENABLE:true,
                   VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2,
                   });
        }
    }
 else if (vtype==kVarCACHE)
    {
     hmiobj.push({ OBJECT:'label', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, ENABLE:true,
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2,
               });
     CreateVarRDObj(id);
    }    
 else if (vtype==kVarLOCAL)
    {
     hmiobj.push({ OBJECT:'label', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, ENABLE:true,
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2,
               });
    }    

 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;      //"absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = align;
 vdiv.classList.add("class"+id+align);
 //vdiv.style.textAlign = "center";
 //vdiv.classList.add("class"+id+"center");
 
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style="border:0px solid";
 vinput.style.background=background;    //"transparent";
 vinput.style.border=border+bordercolor;
 //vinput.style.fontWeight='bold';
 if (keydown!=null) vinput.setAttribute("onmousedown", keydown);
// if (keydown==null) CreateVarRDObj(id, text, true);
 //else CreateVarRDObj(id, text, false);
 //if (vtype==kVarCACHE) CreateVarRDObj(id, null, false);
 //console.log('field label:'+vparam2);
 if (vtype==kVarCACHE) CreateVarRDObj(vparam2, null, false);
 DrawTextLabel(id, 50);
 return(true);
}


function DrawTextLabel(id, timeout)
   {
    var n=GetID(id);
    var ctx = document.getElementById(id).getContext("2d");
    var temp;
    var fontsize=Math.round(hmiobj[n].FONTSIZE);
    var text='';
    var m;

    var vinput = document.getElementById(id);  
    if (hmiobj[n].ENABLE) vinput.style.background=hmiobj[n].BACKGROUND;
    else vinput.style.background='transparent';

     ctx.beginPath();
     ctx.font = fontsize+'px '+hmiobj[n].FONTTYPE;
     //ctx.fontWeight= 'bold';
     ctx.fillStyle = hmiobj[n].COLOR;
     ctx.textAlign = hmiobj[n].ALLIGN;  // "center";
     temp=(hmiobj[n].HEIGHT+0.7*fontsize)/2;

     setTimeout(function()
               {
                //console.log(hmiobj[n].TYPE);
                if (hmiobj[n].TEXT)
                    {
                    if (hmiobj[n].TYPE=="PWD")
                        {
                         for (m=0; m<hmiobj[n].TEXT.length; m++) text+='*';
                        }
                    else text=hmiobj[n].TEXT;
                    }
                ctx.clearRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
                if (hmiobj[n].ENABLE)
                    {
                     if (hmiobj[n].ALLIGN=="center") ctx.fillText(text, hmiobj[n].WIDHT/2, temp);
                     else ctx.fillText(text, 0, temp);
                    }
                },timeout);
     ctx.stroke();
    }


function PressLabel(id)
    {
     var temp;
     var n=GetID(id);
     var text='';

     if (n<0) return;
     console.log('PRESS LABEL !!!')
     if (hmiobj[n].OBJECT=='label')
         {
          console.log(hmiobj[n].VTYPE);
          console.log(hmiobj[n].VID);
          console.log(hmiobj[n].VFIELD);
          console.log(hmiobj[n].TEXT);
          if (hmiobj[n].VTYPE==kVarCACHE)
             {
              temp='key.php?type='+hmiobj[n].TYPE+'&vtype='+hmiobj[n].VTYPE+'&vid='+hmiobj[n].VID+'&vfield='+hmiobj[n].VFIELD+'&val='+hmiobj[n].TEXT;
              console.log(temp);
              submit(temp, '', '');                
             }
          else if (hmiobj[n].VTYPE==kVarDBASE)
            {
              temp='key.php?type='+hmiobj[n].TYPE+'&vtype='+hmiobj[n].VTYPE+'&vserver='+hmiobj[n].VDBASE[kParamDBASEServer]+'&vdbase='+hmiobj[n].VDBASE[kParamDBASEName]+'&vtable='+hmiobj[n].VDBASE[kParamDBASETable]+'&vuser='+hmiobj[n].VDBASE[kParamDBASEUser]+'&vpassword='+hmiobj[n].VDBASE[kParamDBASEPass]+'&vid='+hmiobj[n].VID+'&vfield='+hmiobj[n].VFIELD+'&val='+hmiobj[n].TEXT;
              submit(temp, '', '');                             
            }
          else if (hmiobj[n].VTYPE==kVarLOCAL)
             {
              if (hmiobj[n].TEXT) text=hmiobj[n].TEXT;
              temp='key.php?type='+hmiobj[n].TYPE+'&vtype='+hmiobj[n].VTYPE+'&vid='+hmiobj[n].VID+'&vfield='+hmiobj[n].VFIELD+'&val='+text;
              console.log(temp);
              submit(temp, '', '');
             }


         }
    }



//*****************************************************************************************************//
//                                              Label Object                                           //
//*****************************************************************************************************//
const kCLOCKTYPE=0x40;
function CreateLabelLocalNew(id, left, top, width, height, fontSize, fonttype, text, color, background, border, bordercolor, keydown, type, align, vtype, vparam0, vparam1, vparam2, position)
{
 if (vtype==kVarNONE)
    {
     hmiobj.push({ OBJECT:'labellocal', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROUND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, EDITED_:false, 
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2, PTRTEXT:0, TEXTLAST:'', TXTPROC:'', ENABLE:true,
               });
    }
 else if (vtype==kVarDBASE)
    {
     if ((vparam0==null)||(vparam1==null)||(vparam2==null)) return(false);
     else
        {
         hmiobj.push({ OBJECT:'labellocal', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
                   COLOR:color, BACKGROUND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, EDITED_:false, 
                   VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2, PTRTEXT:0, TEXTLAST:'', TEXTPROC:'', ENABLE:true,
                   });
        }
    }
 else if (vtype==kVarCACHE)
    {
     hmiobj.push({ OBJECT:'labellocal', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROUND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, EDITED_:false, 
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2, PTRTEXT:0, TEXTLAST:'', TEXTPROC:'', ENABLE:true,
               });
     CreateVarRDObj(id);
    }    
 else if (vtype==kVarLOCAL)
    {
     hmiobj.push({ OBJECT:'labellocal', ID:id, TEXT:text, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, BACKGROUND:background, TYPE:type, ALLIGN:align, KEYDOWN:keydown, REFRESH:false, EDITED:false, EDITED_:false, 
               VTYPE:vtype, VDBASE:vparam0, VID:vparam1, VFIELD:vparam2, PTRTEXT:0, TEXTLAST:'', TEXTPROC:'', ENABLE:true,
               });
    }

 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;      //"absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = align;
 vdiv.classList.add("class"+id+align);
 //vdiv.style.textAlign = "center";
 //vdiv.classList.add("class"+id+"center");
 
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style="border:0px solid";
 vinput.style.background=background;    //"transparent";
 vinput.style.border=border+bordercolor;
 //vinput.style.fontWeight='bold';
 if (keydown!=null) vinput.setAttribute("onmousedown", keydown);
// if (keydown==null) CreateVarRDObj(id, text, true);
 //else CreateVarRDObj(id, text, false);
 //if (vtype==kVarCACHE) CreateVarRDObj(id, null, false);
 //console.log('field label:'+vparam2);
 if (vtype==kVarCACHE) CreateVarRDObj(vparam2, null, false);
 DrawTextLabelLocal(id, 100);
 return(true);
}


function DrawTextLabelLocal(id, timeout)
   {
    var n=GetID(id);
    var ctx = document.getElementById(id).getContext("2d");
    var temp;
    var fontsize=Math.round(hmiobj[n].FONTSIZE);
    var text='';
    var m;
    var i;

    var vinput = document.getElementById(id); 
    if (hmiobj[n].ENABLE) vinput.style.background=hmiobj[n].BACKGROUND;
    else vinput.style.background='transparent';

     ctx.beginPath();
     ctx.font = fontsize+'px '+hmiobj[n].FONTTYPE;
     //ctx.fontWeight= 'bold';
     ctx.fillStyle = hmiobj[n].COLOR;
     ctx.textAlign = hmiobj[n].ALLIGN;  // "center";
     temp=(hmiobj[n].HEIGHT+0.7*fontsize)/2;

     setTimeout(function()
               {
                if (hmiobj[n].TYPE=="NUM")
                    {
                     text=hmiobj[n].TEXT;
                     for (i=0; i<hmiobj[n].TEXT.length; i++)
                         {
                          if ((hmiobj[n].TEXT[i]<'0')||(hmiobj[n].TEXT[i]>'9'))
                             {
                              hmiobj[n].TEXT='';
                              text='';
                             }
                         }
                    }
                else if (hmiobj[n].TYPE=="PWD")
                    {
                     for (m=0; m<hmiobj[n].TEXT.length; m++) text+='*';
                    }
                else if (hmiobj[n].TYPE=='CLOCK')
                    {
                     if (focusid!=id) text=hmiobj[n].TEXT;
                     else
                         {
                          if (hmiobj[n].TEXT.length<=2)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                            }
                         else if (hmiobj[n].TEXTPROC.length==3)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                              text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                            }
                         else if (hmiobj[n].TEXT.length<=4)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                             text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                             if (hmiobj[n].TEXT[3]) text+=hmiobj[n].TEXT[3];
                            }                            
                         }
                     hmiobj[n].TEXTPROC=text;
                    }
                else if (hmiobj[n].TYPE=='CLOCK_SEC')
                    {
                     //console.log("Here: "+hmiobj[n].TEXTPROC);
                     if (focusid!=id) text=hmiobj[n].TEXT;
                     else
                         {
                          if (hmiobj[n].TEXT.length<=2)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                             //console.log("here1 "+text, hmiobj[n].TEXTPROC);
                            }
                         else if (hmiobj[n].TEXTPROC.length==3)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                              text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                             //console.log("here2 "+text, hmiobj[n].TEXTPROC);
                            }
                         else if (hmiobj[n].TEXT.length<=4)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                             text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                             if (hmiobj[n].TEXT[3]) text+=hmiobj[n].TEXT[3];
                             //console.log("here3 "+text, hmiobj[n].TEXTPROC);
                            }
                         else if (hmiobj[n].TEXT.length==5)
                            {
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                             text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                             if (hmiobj[n].TEXT[3]) text+=hmiobj[n].TEXT[3];
                             text+=":";
                             if (hmiobj[n].TEXT[4]) text+=hmiobj[n].TEXT[4];
                             //console.log("here4 "+text, hmiobj[n].TEXTPROC);
                            }
                         else
                            { 
                             if (hmiobj[n].TEXT[0]) text+=hmiobj[n].TEXT[0];
                             if (hmiobj[n].TEXT[1]) text+=hmiobj[n].TEXT[1];
                             text+=":";
                             if (hmiobj[n].TEXT[2]) text+=hmiobj[n].TEXT[2];
                             if (hmiobj[n].TEXT[3]) text+=hmiobj[n].TEXT[3];
                             text+=":";
                             if (hmiobj[n].TEXT[4]) text+=hmiobj[n].TEXT[4];
                             if (hmiobj[n].TEXT[5]) text+=hmiobj[n].TEXT[5];
                             //console.log("here5 "+text+" --->"+hmiobj[n].TEXTPROC); 
                            }
                        }
                     hmiobj[n].TEXTPROC=text;
                     //console.log("here6 "+hmiobj[n].TEXTPROC);
                    }
                else
                    {
                     text=hmiobj[n].TEXT;
                    }

              //console.log(hmiobj[n].TEXT, text);
              //console.log("here", hmiobj[n].ENABLE);
              ctx.clearRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
              if (hmiobj[n].ENABLE)
                 { 
                  if (focusid==id)
                     {
                      if (cycle500mS) text+='_';
                     }
    //              console.log("Final:"+hmiobj[n].TEXT+" -->"+text);
                   if (hmiobj[n].ALLIGN=="center") ctx.fillText(text, hmiobj[n].WIDHT/2, temp);
                   else ctx.fillText(text, 0, temp);
                 }  
            },timeout);
     ctx.stroke();
    }


function PressLabelLocal(id)
    {
     var temp;
     var n=GetID(id);
     var text='';
     var i;

     if (n<0) return;
     if (focusid!=id)
        {
         var m=GetID(focusid);                                                                          // Update label local when unfocus to others label local
         if (m>=0)                                                                                      //
             {                                                                                          //
              if (hmiobj[m].OBJECT=='labellocal') UpdateLocalLabel(focusid);                            // 
             }                                                                                          // 
         //if (hmiobj[n].VTYPE==kVarNONE)
         hmiobj[n].TEXTLAST=hmiobj[n].TEXT;
         focusid=id;
        }
     if (hmiobj[n].OBJECT=='labellocal')
         {
          //console.log(hmiobj[n].TEXT);
          for (i=0; i<hmiobj[n].TEXT.length; i++)
             {
              if (hmiobj[n].TEXT[i]!=":") text+=hmiobj[n].TEXT[i];
             }
          hmiobj[n].TEXT=text;
          //console.log(hmiobj[n].TEXT);
          KeyboardBuff=hmiobj[n].TEXT;
          hmiobj[n].TEXTPROC=hmiobj[n].TEXT;
          console.log("presslocal !!!");
         }
    }





//*****************************************************************************************************//
//                                              Table Object                                           //
//*****************************************************************************************************//
function GetTableBuffID(id)
    {
     var n;

     for (n=0; n<bufftable.length; n++)
        {
         if (bufftable[n].ID==id) return(n);
        }
     return(-1);
    }


function CreateTable(id, left, top, width, height, colorheader, colorback, colortextHeader, colortext, fontsize, fonttype, align, border, size, header, scrolsize, scrolcol, scrolimg, keydown, keyup, colsize)
{
hmiobj.push({ OBJECT:'table', ID:id, FONTSIZE:resY*fontsize/100, FONTTYPE:fonttype,
              TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
              COLORHEADER:colorheader, COLORBACK:colorback, COLORTXTHEADER:colortextHeader, COLORTXT:colortext, BORDER:border,
              TOTCOL:header.length, ROWSEL:0, OFFSET:0, HEADER:header, HEADERTYPE:null, REFRESH:false, TOTROW:0, MAXROW:0,
              SCROLLSIZE:resX*scrolsize/100, SCROLCOLOR:scrolcol, SCROLIMG:scrolimg, SCROLLPRESS:false, SCROLLPOS:0, COLSIZE:colsize, SCROLLACTIVE:false, SELECTIDX:0,
              ACTIVE:false, CHANGED:true, SELECTEDGE:false, ALIGN:align, SORTING:null,
            });
 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);

 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id);
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 
 var temp=0;
 for (i=0; i<hmiobj[n].TOTCOL; i++)
        {
         temp+=hmiobj[n].COLSIZE[i];
         //console.log("COL"+i+":"+hmiobj[n].COLSIZE[i]);
        }
 temp*=resX;
 temp/=100;
 hmiobj[n].WIDHT=temp;
 //console.log("WIDTH:", temp, resX);
 
 vinput.width=hmiobj[n].WIDHT;    //width;    
 vinput.height=hmiobj[n].HEIGHT;   //height;  
 console.log("WIDHT:"+vinput.width+" HEIGHT:"+vinput.height);
 vinput.style.border=hmiobj[n].BORDER;              //border+bordercolor;
 vinput.style.background=colorback;    //"transparent";
 if (keydown!=null) vinput.setAttribute("onmousedown", keydown);
 if (keydown|=null) vinput.setAttribute("onmouseover", keydown);
 if (keydown!=null) vinput.setAttribute("ontouchstart", keydown);
 if (keydown!=null) vinput.setAttribute("ontouchmove", keydown);
 if (keydown!=null) vinput.setAttribute("onmousemove", keydown); 
 if (keyup!=null) vinput.setAttribute("onmouseup", keyup);
 if (keyup!=null) vinput.setAttribute("ontouchend", keyup);

 
 var vinputimg = document.createElement('img'); 
 document.body.appendChild(vinputimg); 
 vinputimg.setAttribute("id", "img"+id);
 vinputimg.src=scrolimg;
 vinputimg.style.display='none';   //       'none';//'block';    //block
 vinputimg.style.position='absolute';
 vinputimg.style.height=hmiobj[n].SCROLLSIZE;
 vinputimg.style.width=hmiobj[n].SCROLLSIZE;


 var vinputimg2 = document.createElement('img');
 document.body.appendChild(vinputimg2); 
 vinputimg2.setAttribute("id", "img2"+id);
 vinputimg2.src=scrolimg;
 vinputimg2.style.display='none';   //       'none';//'block';    //block
 vinputimg2.style.position='absolute';
 vinputimg2.style.height=hmiobj[n].SCROLLSIZE;
 vinputimg2.style.width=hmiobj[n].SCROLLSIZE;

 var i;
 bufftable.push({ID:id, BUFFER:Array(header.length*size) });
 var m=GetTableBuffID(id);
 for (i=0; i<(header.length*size); i++) bufftable[m].BUFFER[i]=null;
 var sort=[];
 sort.push({SELECT:-1, SORT:"none"});
 hmiobj[n].SORTING=sort;
// console.log("Allignment:"+hmiobj[n].ALLIGN);
 DrawTable(id, 300);
}


function DrawTable(id, timeout)
{
  var n=GetID(id);
  var CentreTextPos;  
  var totrow;
  var totrowdisp;
  var totrowcount=0;
  var rowsize;
  var scrollsize;
  var temp, temp1;
  var i,j, k;
  var totalwidth=0;
  //const ratio = Math.ceil(window.devicePixelRatio);


//  if (hmiobj[n].ALIGN==null)
//  console.log(hmiobj[n].SORTING);
  if ((hmiobj[n].ALIGN==null)||(hmiobj[n].HEADER.length!=hmiobj[n].ALIGN.length))
     {
      hmiobj[n].ALIGN=[];
      for (i=0; i<hmiobj[n].HEADER.length; i++) hmiobj[n].ALIGN[i]="left"; 
     }
  if ((hmiobj[n].HEADERTYPE==null)||(hmiobj[n].HEADER.length!=hmiobj[n].HEADERTYPE.length))
     {
      hmiobj[n].HEADERTYPE=[];
      for (i=0; i<hmiobj[n].HEADER.length; i++) hmiobj[n].HEADERTYPE[i]='str';
      console.log("RESET HEADER !!!!");
     }
  hmiobj[n].TOTCOL=hmiobj[n].HEADER.length;
  for (i=0; i<hmiobj[n].COLSIZE.length; i++) totalwidth+=hmiobj[n].COLSIZE[i];
  hmiobj[n].WIDHT=resX*totalwidth/100;

  var vdiv=document.getElementById('div'+id);
  vdiv.style.width=hmiobj[n].WIDHT;
  vdiv.style.height=hmiobj[n].HEIGHT;
  var vinput = document.getElementById(id);
  vinput.width=hmiobj[n].WIDHT;    //width;    
  vinput.height=hmiobj[n].HEIGHT;   //height;  

  var ctx = document.getElementById(hmiobj[n].ID).getContext("2d");     //c.getContext("2d");
  var img = document.getElementById("img"+hmiobj[n].ID);
  var img2= document.getElementById("img2"+hmiobj[n].ID);
  var width;
  var height=hmiobj[n].HEIGHT;
  var heightauto;
  var fontsize=hmiobj[n].FONTSIZE;
  //ctx.getContext('2d').setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.font = fontsize+'px '+hmiobj[n].FONTTYPE;  //hmiobj[n].FONTSIZE;

  temp=(height/(fontsize*1.3));
  totrow=Math.round(height/(fontsize*1.3));
  //console.log('totrow:'+totrow);
  hmiobj[n].TOTROW=totrow-1;
  rowsize=height/totrow;
  CentreTextPos=((height/temp)+0.7*fontsize)/2;

  var m=GetTableBuffID(id);
  totrowcount=0;
  for (i=0; i<(bufftable[m].BUFFER.length/hmiobj[n].TOTCOL); i++)
        {
         if (bufftable[m].BUFFER[i*hmiobj[n].TOTCOL]==null) break;
         totrowcount++;
        }
 hmiobj[n].MAXROW=totrowcount;

 if (totrowcount>=totrow) scrollsize=hmiobj[n].SCROLLSIZE;
 else scrollsize=0;
 //console.log(scrollsize, posscroll, totrowcount, totrow, maxrow, posoffscroll);

 temp=0;
 for (i=0; i<hmiobj[n].TOTCOL; i++) temp+=hmiobj[n].COLSIZE[i];
 temp*=resX;
 temp/=100;
 //if (temp>=hmiobj[n].WIDHT) width=hmiobj[n].WIDHT-scrollsize;
 //else width=temp;
 width=temp-scrollsize;

 //console.log('width:'+width, hmiobj[n].WIDHT);
 if (hmiobj[n].HEADER.length==0)
    {
     vinput.style.border=0;
     width=20;
     ctx.clearRect(0, 0, width, height);
     ctx.fillRect(0, 0, width, height);
     ctx.stroke();
     return;
    }

 vinput.style.border=hmiobj[n].BORDER;//+hmiobj[n].BORDERCOLOR;
 ctx.beginPath();
 ctx.clearRect(0, 0, width, height);

 ctx.fillStyle = hmiobj[n].COLORHEADER;

 ctx.fillRect(0, 0, width, rowsize);

 ctx.fillStyle = "yellow";
 ctx.fillRect(0, rowsize+rowsize*(hmiobj[n].SELECTIDX-hmiobj[n].OFFSET), width-2, rowsize);

 if (scrollsize)
     {
      ctx.fillStyle = hmiobj[n].SCROLCOLOR;
      ctx.fillRect(width, 0, width+scrollsize, height);
      hmiobj[n].SCROLLACTIVE=true;
      //ctx.lineWidth = lineWidth;
     }
 else hmiobj[n].SCROLLACTIVE=false;

 ctx.moveTo(0, 0);
 ctx.lineTo(width, 0);
 ctx.moveTo(0, height);
 ctx.lineTo(width, height);

 //console.log(width);
 for(i=0; i<totrow; i++)
    {
     ctx.moveTo(0, (i+1)*rowsize);
     ctx.lineTo(width, (i+1)*rowsize);
    }

 temp1=0;                                                                      // Drawinging Coloum
  //console.log('tot col:'+hmiobj[n].TOTCOL, scrollsize)
  for (i=0; i<hmiobj[n].TOTCOL-1; i++)
     {
        temp=hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100;
        ctx.moveTo(temp+temp1, 0);
        ctx.lineTo(temp+temp1, height);
        temp1+=temp;    //(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100);
    }

  var tStr, tMeas;
  var leng;

  //console.log('refresh10  header: '+hmiobj[n].HEADER);

  ctx.fillStyle = hmiobj[n].COLORTXTHEADER;                                     // Drawing Header //
  ctx.textAlign = "center";
  temp1=0;
   for (i=0; i<hmiobj[n].TOTCOL; i++)       
        {
         temp=hmiobj[n].HEADER[i];
         leng=temp.length;
         while(1)
             {
              tStr=temp.slice(0,leng);
              tMeas=ctx.measureText(tStr);
              if (tMeas.width<(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100))
                 {   
                  temp=tStr;
                  break;
                 }
              leng--;
             }
         ctx.fillText(temp, temp1+((hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100)/2), CentreTextPos);
         temp1+=(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100);                      
        }

   if (totrowcount<totrow) totrowdisp=totrowcount;
   else totrowdisp=totrow;
   ctx.fillStyle = hmiobj[n].COLORTXT;
   ctx.textAlign = "left";

   console.log(hmiobj[n].OFFSET);

   for (j=0; j<totrowdisp-1; j++)
        {
         temp1=0;
         for (i=0; i<hmiobj[n].TOTCOL; i++)
            {
              //temp=bufftable[m].BUFFER[(hmiobj[n].OFFSET+j)*hmiobj[n].TOTCOL+i];
              if (hmiobj[n].HEADERTYPE[i]=="str") temp=bufftable[m].BUFFER[(hmiobj[n].OFFSET+j)*hmiobj[n].TOTCOL+i].toUpperCase();
              else if (hmiobj[n].HEADERTYPE[i]=="cur")
                    {
                     temp=parseInt(bufftable[m].BUFFER[(hmiobj[n].OFFSET+j)*hmiobj[n].TOTCOL+i]).toLocaleString('en-US').toString();
                    }
              else if (hmiobj[n].HEADERTYPE[i]=="int") temp=bufftable[m].BUFFER[(hmiobj[n].OFFSET+j)*hmiobj[n].TOTCOL+i];
              //temp="1234";
              if (temp)
                {
                  leng=temp.length;
                  while(1)
                    {
                     tStr=temp.slice(0,leng);
                     tMeas=ctx.measureText(tStr);
                     if (tMeas.width<(hmiobj[n].COLSIZE[i])*(resX-scrollsize)/100)
                        {   
                         temp=tStr;
                         break;
                        }
                     leng--;
                    }
                }
             let widthmeasure=ctx.measureText(temp).width;
             if (hmiobj[n].ALIGN[i]=='left') ctx.fillText(temp, 1+temp1, ((j+1)*height/totrow)+CentreTextPos);
             else if (hmiobj[n].ALIGN[i]=='right')
                 {
                  var temp_=(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100)-widthmeasure-2;              
                  if ((scrollsize)&&(i==hmiobj[n].TOTCOL-1))
                      {
                       temp_-=(scrollsize/2);
                       temp_-=1;
                      }
                  ctx.fillText(temp, temp1+temp_, ((j+1)*height/totrow)+CentreTextPos);  
                 }
             else if (hmiobj[n].ALIGN[i]=='center')
                 {
                  var temp_=(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100)-widthmeasure;
                  temp_=temp_/2;
                  ctx.fillText(temp, temp1+temp_, ((j+1)*height/totrow)+CentreTextPos);     
                 }
             temp1+=(hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100);
             //console.log(temp, text+'px');
            }            
        }
  if (scrollsize)
        {
          img.src=hmiobj[n].SCROLIMG;

          //setTimeout(function()
          //          {
                     if (hmiobj[n].SCROLLPRESS) ctx.drawImage(img, 0, 0, img.width, img.height, width, hmiobj[n].SCROLLPOS, scrollsize, scrollsize);
                     else ctx.drawImage(img, 0, 0, img.width, img.height, width+4, hmiobj[n].SCROLLPOS, scrollsize-4, scrollsize);
          //          },timeout);
        }
  ctx.stroke();        


  ctx.beginPath();
  if (hmiobj[n].SORTING[0].SELECT>=0)
      {
       var colombuff=[]; 
       temp=0;
       for (i=0; i<hmiobj[n].COLSIZE.length; i++)
            {
             colombuff[i]=temp;
             temp+=hmiobj[n].COLSIZE[i]*(resX-scrollsize)/100;
            }
       for (i=0; i<hmiobj[n].COLSIZE.length; i++)
           {
            if (hmiobj[n].SORTING[0].SELECT==i)
                {
                 if (hmiobj[n].SORTING[0].SORT=='asc')
                    {
                     img2.src="image/arrow_down.png";
                     ctx.drawImage(img2, colombuff[i]+3, 3, hmiobj[n].FONTSIZE/2, hmiobj[n].FONTSIZE/2);         //ctx.fillText('^', colombuff[i], 15);
                    }
                 else if (hmiobj[n].SORTING[0].SORT=='desc')
                    {
                     img2.src="image/arrow_up.png";
                     ctx.drawImage(img2, colombuff[i]+3, 3, hmiobj[n].FONTSIZE/2, hmiobj[n].FONTSIZE/2);         //ctx.fillText('^', colombuff[i], 15);
                    }
                }
           }
      }
  ctx.stroke();
}


function PressTable(id)
{
 var x,y,i,j;
 var temp, totrow;

 //console.log("press table id:", id);
 //console.log("table here......");
 var n=GetID(id);
 if (n>=0)
    {
     //console.log("Here:", id);
     focusid=id;
     hmiobj[n].SELECTEDGE=true;
     x=hmiobj[n].LEFT;
     y=hmiobj[n].TOP;
     if (hmiobj[n].SCROLLACTIVE)
        {
         if ((MouseX>=x+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)&&(MouseX<=x+hmiobj[n].WIDHT))
            {
             hmiobj[n].SCROLLPRESS=true;
             hmiobj[n].SCROLLPOS=MouseY-y;
             if (hmiobj[n].SCROLLPOS>=(hmiobj[n].HEIGHT-hmiobj[n].SCROLLSIZE)) hmiobj[n].SCROLLPOS=hmiobj[n].HEIGHT-hmiobj[n].SCROLLSIZE;
             if (hmiobj[n].SCROLLPOS<=0) hmiobj[n].SCROLLPOS=0;

             if (hmiobj[n].SCROLLPOS<(hmiobj[n].SCROLLSIZE*0.15)) temp=0;
             else temp=hmiobj[n].SCROLLPOS;

             var m=GetTableBuffID(id);
             var totrowcount=0;
             var i;
             for (i=0; i<(bufftable[m].BUFFER.length/hmiobj[n].TOTCOL); i++)
                 {
                  if (bufftable[m].BUFFER[i*hmiobj[n].TOTCOL]==null) break;
                  totrowcount++;
                 }
             //console.log('tot count:'+totrowcount);
             totrow=hmiobj[n].TOTROW+1;
             var posscroll=temp/(hmiobj[n].HEIGHT-hmiobj[n].SCROLLSIZE);
             var maxrow=Math.floor(bufftable[m].BUFFER.length/hmiobj[n].TOTCOL);
             var posoffscroll=Math.floor(((totrowcount)-(totrow-1))*posscroll);
             hmiobj[n].OFFSET=posoffscroll;             
             console.log("Offset: "+hmiobj[n].TOTROW+", "+totrowcount+", "+hmiobj[n].OFFSET);
             hmiobj[n].REFRESH=true;
             DrawTable(id, 100);     
            }
         else if ((MouseX>=x)&&(MouseX<=x+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE))
            {
             if ((MouseY>y+hmiobj[n].FONTSIZE*1.3))
                {   
                 temp=MouseY-hmiobj[n].TOP;
                 temp/=hmiobj[n].FONTSIZE*1.3;
                 temp=parseInt(temp)-1;
                 if (temp<0) temp=0;
                 hmiobj[n].SELECTIDX=temp+hmiobj[n].OFFSET;
                 hmiobj[n].REFRESH=true;
                 //console.log(hmiobj[n].SELECTIDX);
                }
             else if ((MouseY-y)<(hmiobj[n].FONTSIZE*1.3))
                {
                 var temp=0;
                 var colombuff=[];
                 var selectheader=-1;
                 for (i=0; i<hmiobj[n].COLSIZE.length; i++)
                     {
                      colombuff[i]=temp;
                      temp+=hmiobj[n].COLSIZE[i]*(resX-hmiobj[n].SCROLLSIZE)/100;
                     }
                 selectheader=hmiobj[n].COLSIZE.length-1;
                 for (i=0; i<(hmiobj[n].COLSIZE.length-1); i++)
                     {
                      temp=MouseX-x;  
                      if ((temp>=colombuff[i])&&(temp<colombuff[i+1]))
                          {
                           selectheader=i; 
                           break;
                          }
                     }
                 if (hmiobj[n].SORTING[0].SELECT!=selectheader)
                     {
                      hmiobj[n].SORTING[0].SELECT=selectheader;
                      hmiobj[n].SORTING[0].SORT="asc";
                     }
                 else
                     {
                      if (hmiobj[n].SORTING[0].SORT=="none") hmiobj[n].SORTING[0].SORT="asc";
                      else if (hmiobj[n].SORTING[0].SORT=="asc") hmiobj[n].SORTING[0].SORT="desc";
                      else if (hmiobj[n].SORTING[0].SORT=="desc") hmiobj[n].SORTING[0].SORT="asc";
                     }
                 sorting(id);
                 //hmiobj[n].REFRESH=true;
                 //console.log(hmiobj[n].SORTING[0]);
                 //console.log("press header !!!", i);
                 //console.log(colombuff);
                }
            }
         ///console.log('MouseX:'+MouseX, 'x:'+x, 'width:'+hmiobj[n].WIDHT,'scrollsize:'+hmiobj[n].SCROLLSIZE, 'Pos:'+hmiobj[n].OFFSET);            
        }
     else
        {
         //if ((MouseX>=x)&&(MouseX<=x+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)&&(MouseY>y+hmiobj[n].FONTSIZE*1.3))
         if ((MouseX>=x)&&(MouseX<=x+hmiobj[n].WIDHT))
            {
             if (MouseY>y+hmiobj[n].FONTSIZE*1.3)
                {   
                 //console.log("here3.....");
                 temp=MouseY-hmiobj[n].TOP;
                 temp/=hmiobj[n].FONTSIZE*1.3;
                 temp=parseInt(temp)-1;
                 if (temp<0) temp=0;
                 hmiobj[n].SELECTIDX=temp+hmiobj[n].OFFSET;
                 hmiobj[n].REFRESH=true;
                 //console.log(hmiobj[n].SELECTIDX);
                }
             else if ((MouseY-y)<(hmiobj[n].FONTSIZE*1.3))
                {
                 var temp=0;
                 var colombuff=[];
                 var selectheader=-1;
                 for (i=0; i<hmiobj[n].COLSIZE.length; i++)
                     {
                      colombuff[i]=temp;
                      temp+=hmiobj[n].COLSIZE[i]*resX/100;
                     }
                 selectheader=hmiobj[n].COLSIZE.length-1;
                 for (i=0; i<(hmiobj[n].COLSIZE.length-1); i++)
                     {
                      temp=MouseX-x;  
                      if ((temp>=colombuff[i])&&(temp<colombuff[i+1]))
                          {
                           selectheader=i; 
                           break;
                          }
                     }
                 if (hmiobj[n].SORTING[0].SELECT!=selectheader)
                     {
                      hmiobj[n].SORTING[0].SELECT=selectheader;
                      hmiobj[n].SORTING[0].SORT="asc";
                     }
                 else
                     {
                      if (hmiobj[n].SORTING[0].SORT=="none") hmiobj[n].SORTING[0].SORT="asc";
                      else if (hmiobj[n].SORTING[0].SORT=="asc") hmiobj[n].SORTING[0].SORT="desc";
                      else if (hmiobj[n].SORTING[0].SORT=="desc") hmiobj[n].SORTING[0].SORT="asc";
                     }
                 sorting(id);
                 //hmiobj[n].REFRESH=true;
                 //console.log(hmiobj[n].SORTING[0]);
                }
            }
        } 
    }

}


function ReleaseTable(id)
{
// var x,y;

 //console.log("table here2......");
 var n=GetID(id);
 if (n>=0)
    {
     hmiobj[n].SCROLLPRESS=false;
     DrawTable(id, 100);     
    }
}



function sorting(id)
{
 var i,j,k, totrow, lengthHeader;   
 var field=null;
 var n=GetID(id);
 var m=GetTableBuffID(id);
 let temptbl=[];

 if (hmiobj[n].SORTING[0].SELECT>=0)
    {
     lengthHeader=hmiobj[n].HEADER.length;
     totrow=bufftable[m].BUFFER.length/lengthHeader;
     //console.log("totrow: "+totrow);   
     for (i=0; i<totrow; i++)
         {
          let obj = {};
          for (j=0; j<lengthHeader; j++)
              {
               obj[hmiobj[n].HEADER[j]] = bufftable[m].BUFFER[(i*lengthHeader)+j];
              }
          temptbl.push(obj);
         }         
     field=hmiobj[n].HEADER[hmiobj[n].SORTING[0].SELECT];
//     console.log(field);
      if (hmiobj[n].SORTING[0].SORT=='asc')
        {
          if (hmiobj[n].HEADERTYPE[hmiobj[n].SORTING[0].SELECT]=="str")
              {
               temptbl.sort((a, b) => {
                 if (a[field] < b[field]) return -1;
                 if (a[field] > b[field]) return 1;
                 return 0;
                 }); 
               }
          else temptbl.sort((a, b) => a[field] - b[field]);
        }
     else if (hmiobj[n].SORTING[0].SORT=='desc')
        {
          if (hmiobj[n].HEADERTYPE[hmiobj[n].SORTING[0].SELECT]=="str")
             {
              temptbl.sort((a, b) => {
                 if (a[field] < b[field]) return 1;
                 if (a[field] > b[field]) return -1;
                 return 0;
                 }); 
             }
         else  temptbl.sort((a, b) => b[field] - a[field]);              
        }
     //console.log(temptbl);
     bufftable[m].BUFFER=[];
     j=0;
     for (i=0; i<totrow; i++)
         {
          //bufftable[m].BUFFER[j++]=(i+1).toString();
          for (k=0; k<lengthHeader; k++)
             {  
              bufftable[m].BUFFER[j++]=temptbl[i][hmiobj[n].HEADER[k]];
             }
         }
    }
 
}



function ResetTable(id)
{
 var m=GetTableBuffID(id);
 var n=GetID(id);

 if (m>=0) bufftable[m].BUFFER=[];
 if (n>=0)
    {
     hmiobj[n].SORTING[0].SELECT=-1;
     hmiobj[n].SORTING[0].SORT="none";
    }

}

/*

buff.sort((a, b) => {
    if (a.FIELD0 < b.FIELD0) return -1;
    if (a.FIELD0 > b.FIELD0) return 1;
    return 0;
});

*/

/*
//----------------- Ascending: -------------------//
let buff = [];
buff.push({ FIELD0: "budi", NUMBER: 1234 });
buff.push({ FIELD0: "amir", NUMBER: 3241 });
buff.push({ FIELD0: "boba", NUMBER: 12 });
buff.push({ FIELD0: "iwan", NUMBER: 56 });

buff.sort((a, b) => a.NUMBER - b.NUMBER);

console.log(buff);
//----------------- Descending: -------------------//

let buff = [];
buff.push({ FIELD0: "budi", NUMBER: 1234 });
buff.push({ FIELD0: "amir", NUMBER: 3241 });
buff.push({ FIELD0: "boba", NUMBER: 12 });
buff.push({ FIELD0: "iwan", NUMBER: 56 });

buff.sort((a, b) => b.NUMBER - a.NUMBER);

console.log(buff);

*/


/************************************************************************************************************/
/*                                                  Create Image                                            */
/************************************************************************************************************/
function CreateImage(id, left, top, width, height, src, position)
{
hmiobj.push({ OBJECT:'image', ID:id, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               REFRESH:false, SRC:src, SRC_:src,
            });    
 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;  //"absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;    
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style="border:0px solid";
 vinput.style.background="transparent";

 var vinputimg = document.createElement('img');
 document.body.appendChild(vinputimg); 
 vinputimg.setAttribute("id", "img"+id);
 if (src!=null) vinputimg.src=src;
 vinputimg.style.display='none';   //       'none';//'block';    //block
 vinputimg.style.position='absolute';
 DrawImageX(id, 500);
}


function DrawImageX(id, timeout)
{
 var n=GetID(id);
 var ctx = document.getElementById(id).getContext("2d");
 var img = document.getElementById("img"+id);
 if (hmiobj[n].SRC!=null) img.src=hmiobj[n].SRC;
 ctx.beginPath();
 setTimeout(function()
             {
              if (hmiobj[n].SRC!=null) ctx.drawImage(img, 0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
            },timeout);
 ctx.stroke();
}


/************************************************************************************************************/
/*                                                  Create Canvas                                           */
/************************************************************************************************************/
function CreateCanvas(id, left, top, width, height, position)
{
hmiobj.push({ OBJECT:'image', ID:id, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               REFRESH:false,
            });    
 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;   //"absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;    
 vinput.height=hmiobj[n].HEIGHT;
 vinput.style="border:0px solid";
 vinput.style.background="transparent";
}


//*****************************************************************************************************//
//                                           Option List                                               //
//*****************************************************************************************************//
function CreateOption(id, left, top, width, height, fontSize, fonttype, textoption, selectidx, color, background, colsel, border, bordercolor, scrolsize, vtype, vparam0, vparam1, vparam2, position)
{
 hmiobj.push({ OBJECT:'option', ID:id, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               TEXTOPTION:textoption, SELECTIDX:selectidx, SELECTIDX_:selectidx, SCROLLSIZE:resY*scrolsize/100, CHANGED:false,
               FONTSIZE:fontSize*resY/100, FONTTYPE:fonttype,
               COLOR:color, BACKGROUND:background, COLSEL:colsel,
               SELECTION:false, REFRESH:false, SHOW:kTop, CLICKUP:false, CLICKDOWN:false, EDITED:false,
               MAXITEM:0, OFFSET:0,
               VTYPE:vtype, VTABLE:vparam0, VID:vparam1, VFIELD:vparam2,
               ZINDEX:1
               });

 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "left";
 vdiv.classList.add("class"+id+"left");
 
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id);
 vdiv.appendChild(vinput);
 vinput.style.position=position;
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT
 vinput.height=hmiobj[n].FONTSIZE;  //   fontSize;  //textoption.length*(fontSize*resY)/100;//height;  
 vinput.style="border:0px solid";
 vinput.style.background=background;    //"transparent";
 vinput.style.border=border+bordercolor;
 vinput.setAttribute("onmousedown", "PressOption(this.id)");
 vinput.setAttribute("onmouseup", "ReleaseOption(this.id)");
 
 var vinputimgup = document.createElement('img');
 document.body.appendChild(vinputimgup);
 vinputimgup.setAttribute("id", "optup"+id);
 vinputimgup.src='image/arrowup.png';
 vinputimgup.style.display='none';   //       'none';//'block';    //block
 vinputimgup.style.position=position;
 var vinputimgdown = document.createElement('img');
 document.body.appendChild(vinputimgdown); 
 vinputimgdown.setAttribute("id", "optdown"+id);
 vinputimgdown.src='image/arrowdown.png';
 vinputimgdown.style.display='none';   //       'none';//'block';    //block
 vinputimgdown.style.position=position;
// CreateVarRDObj(id, selectidx, false);
// console.log(varRDobj);
 if (vtype==kVarCACHE) CreateVarRDObj(vparam2, null, true);
 DrawOption(id, 500);
}


function DrawOption(id, timeout)
   {
     //console.log('Option Id:'+id);
     var n=GetID(id);
     var ctx = document.getElementById(id).getContext("2d");
     var imgup = document.getElementById("optup"+id);
     var imgdown = document.getElementById("optdown"+id);
     var divx= document.getElementById('div'+id);
     var temp;
     //var fontsize=Math.trunc(hmiobj[n].FONTSIZE*1.4);
     var fontsize=Math.trunc(hmiobj[n].FONTSIZE*1.2);
     var i;
     var maxitem, offitem, height;
     
     if ((resY-hmiobj[n].TOP)>=(hmiobj[n].TOP)) hmiobj[n].SHOW=kBotttom;
     else hmiobj[n].SHOW=kTop;

     divx.style.zIndex=hmiobj[n].ZINDEX;
     //console.log('option click '+id);
     
     ctx.beginPath();
     ctx.fillStyle = hmiobj[n].COLOR;
     ctx.textAlign = "left";  // "center";

     setTimeout(function()
               {
                height=fontsize*hmiobj[n].TEXTOPTION.length;
                if (hmiobj[n].SHOW==kBotttom) temp=resY-hmiobj[n].TOP;
                else if (hmiobj[n].SHOW==kTop) temp=hmiobj[n].TOP+fontsize;
                if (height>temp) maxitem=Math.trunc(temp/fontsize);
                else maxitem=hmiobj[n].TEXTOPTION.length;
                hmiobj[n].MAXITEM=maxitem;
//                hmiobj[n].OFFSET=2;
                if (hmiobj[n].SELECTION)    
                     {
                      if (hmiobj[n].SHOW==kBotttom) divx.style.top=hmiobj[n].TOP+'px';
                      else divx.style.top=(hmiobj[n].TOP-fontsize*(maxitem-1))+'px';

                      document.getElementById(id).style.background=hmiobj[n].BACKGROUND;
                      document.getElementById(id).height=fontsize*maxitem;    //hmiobj[n].TEXTOPTION.length;
                      ctx.font=hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
                      for (i=0; i<maxitem; i++)
                         {
                          if ((hmiobj[n].OFFSET+i)==hmiobj[n].SELECTIDX) ctx.fillStyle = hmiobj[n].COLSEL;
                          else ctx.fillStyle = hmiobj[n].BACKGROUND;
                          ctx.fillRect(0, i*fontsize, hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE, fontsize);
                          ctx.fillStyle = hmiobj[n].COLOR;
                          ctx.fillText(hmiobj[n].TEXTOPTION[i+hmiobj[n].OFFSET], 5, (fontsize*(1+i))-(fontsize*0.3));
                        }
                       if (hmiobj[n].CLICKUP) imgup.src='image/arrowupclick.png';
                       else imgup.src='image/arrowup.png';
                       if (hmiobj[n].CLICKDOWN) imgdown.src='image/arrowdownclick.png';
                       else imgdown.src='image/arrowdown.png';

                       ctx.fillStyle = "#A0A0A0";
                       ctx.fillRect(hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE, hmiobj[n].SCROLLSIZE, hmiobj[n].SCROLLSIZE, (maxitem*fontsize)-hmiobj[n].SCROLLSIZE*2);
                       ctx.drawImage(imgup,   hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE, 0, hmiobj[n].SCROLLSIZE, hmiobj[n].SCROLLSIZE);
                       ctx.drawImage(imgdown, hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE, maxitem*fontsize-hmiobj[n].SCROLLSIZE, hmiobj[n].SCROLLSIZE, hmiobj[n].SCROLLSIZE);
                      }
                  else
                      {
                       divx.style.top=hmiobj[n].TOP+'px';
                       divx.style.zIndex=0;
                       document.getElementById(id).style.background="transparent";
                       document.getElementById(id).height=fontsize;
                       ctx.clearRect(0, 0, hmiobj[n].WIDHT, fontsize);
                       ctx.fillStyle = hmiobj[n].COLSEL;
                       ctx.fillRect(0, 0, hmiobj[n].WIDHT, fontsize);
                       ctx.fillStyle = hmiobj[n].COLOR;
                       ctx.font=hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
                       //console.log(hmiobj[n].SELECTIDX, hmiobj[n].TEXTOPTION.length);
                       if (hmiobj[n].TEXTOPTION[hmiobj[n].SELECTIDX]==null) ctx.fillText(' ', 5, fontsize*0.7);
                       else ctx.fillText(hmiobj[n].TEXTOPTION[hmiobj[n].SELECTIDX], 5, fontsize*0.7);
                       hmiobj[n].EDITED=true;
                      }
                },timeout); 
     ctx.stroke();
    }


function PressOption(id)
    {
     var temp;
     var n=GetID(id), m;
     //var fontsize=1.382*hmiobj[n].FONTSIZE;       //1.2*hmiobj[n].FONTSIZE;
     var fontsize=1.2*hmiobj[n].FONTSIZE;

     hmiobj[n].ZINDEX=99;
     focusid=id;
     if (hmiobj[n].SELECTION)
         {
          if (hmiobj[n].SHOW==kBotttom)
               {
                //console.log(Math.round(hmiobj[n].TOP), Math.round(hmiobj[n].TOP+(fontsize*hmiobj[n].MAXITEM)), hmiobj[n].MAXITEM);
                if (((MouseX>=hmiobj[n].LEFT)&&(MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY>=hmiobj[n].TOP)&&(MouseY<=(hmiobj[n].TOP+(fontsize*hmiobj[n].MAXITEM))))
                     {
                      //console.log('here..');
                      hmiobj[n].CHANGED=true;
                      hmiobj[n].SELECTION=false;
                      temp=MouseY-hmiobj[n].TOP;
                      //console.log('Diff:'+temp,'  fontsize:'+fontsize);
                      temp=Math.trunc(temp/(fontsize));
                      //console.log('Result:'+temp);
                      hmiobj[n].SELECTIDX=temp+hmiobj[n].OFFSET;
                      hmiobj[n].SELECTIDX_=hmiobj[n].SELECTIDX;
                      //console.log(hmiobj[n].ID, hmiobj[n].VTYPE, hmiobj[n].VTABLE, hmiobj[n].VID, hmiobj[n].VFIELD);
                      if (hmiobj[n].VTYPE==kVarDBASE)
                           {
                            WRDBASESEQ_ID=hmiobj[n].ID;
                            WRDBASESEQstate=kWRDBASESEQSTART;
                           }
                      else if (hmiobj[n].VTYPE==kVarCACHE)
                            {
                             //WRMemcacheID=hmiobj[n].ID;
                             BuffWRCACHE.push({ID:hmiobj[n].VFIELD});
                             console.log('write CACHE1', hmiobj[n].VFIELD);
                            }
                     }
                if (((MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT))&&(MouseX>=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY>=hmiobj[n].TOP)&&(MouseY<=(hmiobj[n].TOP+hmiobj[n].SCROLLSIZE)))
                     {
                      hmiobj[n].CLICKUP=true;
                      hmiobj[n].REFRESH=true;
                     }
                if (((MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT))&&(MouseX>=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY>=(hmiobj[n].TOP+fontsize*hmiobj[n].MAXITEM-hmiobj[n].SCROLLSIZE))&&(MouseY<=(hmiobj[n].TOP+fontsize*hmiobj[n].MAXITEM)))
                     {
                      hmiobj[n].CLICKDOWN=true;
                      hmiobj[n].REFRESH=true;
                     }                     
               }
          else if (hmiobj[n].SHOW==kTop)
               {
                if (((MouseX>=hmiobj[n].LEFT)&&(MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY<=(hmiobj[n].TOP+fontsize))&&(MouseY>=(hmiobj[n].TOP-(fontsize*(hmiobj[n].MAXITEM-1)))))
                     {
                      hmiobj[n].CHANGED=true;  
                      hmiobj[n].SELECTION=false;
                      temp=hmiobj[n].TOP-(fontsize*(hmiobj[n].MAXITEM-1));
                      temp=MouseY-temp;
                      temp=Math.trunc(temp/(fontsize));
                      hmiobj[n].SELECTIDX=temp+hmiobj[n].OFFSET;
                      hmiobj[n].SELECTIDX_=hmiobj[n].SELECTIDX;
                      //console.log(hmiobj[n].ID, hmiobj[n].VTYPE, hmiobj[n].VTABLE, hmiobj[n].VID, hmiobj[n].VFIELD);
                      if (hmiobj[n].VTYPE==kVarDBASE)
                           {
                            WRDBASESEQ_ID=hmiobj[n].ID;
                            WRDBASESEQstate=kWRDBASESEQSTART;
                           }
                      else if (hmiobj[n].VTYPE==kVarCACHE)
                            {
                             //WRMemcacheID=hmiobj[n].ID;
                             BuffWRCACHE.push({ID:hmiobj[n].VFIELD});
                             console.log('write CACHE2', hmiobj[n].VFIELD);
                            }
                     }
                if (((MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT))&&(MouseX>=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY>=hmiobj[n].TOP-fontsize*(hmiobj[n].MAXITEM-1))&&(MouseY<=hmiobj[n].TOP+hmiobj[n].SCROLLSIZE-fontsize*(hmiobj[n].MAXITEM-1)))
                     {
                      hmiobj[n].CLICKUP=true;
                      hmiobj[n].REFRESH=true;
                     }
                if (((MouseX<=(hmiobj[n].LEFT+hmiobj[n].WIDHT))&&(MouseX>=(hmiobj[n].LEFT+hmiobj[n].WIDHT-hmiobj[n].SCROLLSIZE)))&&
                    (MouseY>=(hmiobj[n].TOP+fontsize-hmiobj[n].SCROLLSIZE))&&(MouseY<=(hmiobj[n].TOP+fontsize)))
                     {
                      hmiobj[n].CLICKDOWN=true;
                      hmiobj[n].REFRESH=true;
                     }                     
               }
         }
     else
         {   
          hmiobj[n].SELECTION=true;
         }
     DrawOption(id, 100);
    }


 function ReleaseOption(id)
   {
     var n;
     var temp;

     n=GetID(id);
     if (hmiobj[n].SELECTION)
         {
          if (hmiobj[n].CLICKUP)
             {
              hmiobj[n].CLICKUP=false;
              hmiobj[n].REFRESH=true;
              if (hmiobj[n].OFFSET) hmiobj[n].OFFSET--; 
             }
          if (hmiobj[n].CLICKDOWN)
             {
              hmiobj[n].CLICKDOWN=false;
              hmiobj[n].REFRESH=true;
              if (hmiobj[n].OFFSET<(hmiobj[n].TEXTOPTION.length-hmiobj[n].MAXITEM)) hmiobj[n].OFFSET++;
             }
         }
   }

//*****************************************************************************************************//
//                                             Progress Bar                                            //
//*****************************************************************************************************//
function CreateProgressBar(id, left, top, width, height, fonttype, fontSize, color, background, min, max, round)
{
 hmiobj.push({ OBJECT:'progressbar', ID:id, FONTSIZE:resY*fontSize/100, FONTTYPE:fonttype, TOP:Math.round(resY*top/100), LEFT:Math.round(resX*left/100),
               HEIGHT:Math.round(resY*height/100), WIDHT:Math.round(resX*width/100), COLOR:color, BACKGROUND:background,
               REFRESH:false, VAL:90, MIN:min, MAX:max, UPDATE:true, LOWVAL:0, HIGHVAL:0, LOWCOLOR:"red", HIGHCOLOR:"red", ROUND:round,
               });    
 var n=GetID(id);
 var i, k, m;//, temp;
  
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 //vdiv.setAttribute("class", "class"+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;   //300;  //hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;  //300; //hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");

 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.top=0;
 vinput.left=0;
 vinput.width=hmiobj[n].WIDHT;  //+hmiobj[n].BORDER;  //hmiobj[n].DIAMETER+(thick);   //300;//hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;      //+hmiobj[n].BORDER;    //hmiobj[n].DIAMETER+(thick);  //300;//hmiobj[n].HEIGHT;
 //vinput.style.border=border+border+bordercolor;
 vinput.style.background="transparent";//background;

 var vinput1 = document.createElement('canvas');
 vinput1.setAttribute("id", id+"_");
 vdiv.appendChild(vinput1);
 vinput1.style.position='absolute';
 vinput1.top=0;
 vinput1.left=0;
 vinput1.width=hmiobj[n].WIDHT;  //+hmiobj[n].BORDER;  //hmiobj[n].DIAMETER+(thick);   //300;//hmiobj[n].WIDHT;
 vinput1.height=hmiobj[n].HEIGHT;      //+hmiobj[n].BORDER;    //hmiobj[n].DIAMETER+(thick);  //300;//hmiobj[n].HEIGHT;
 //vinput1.style.border=border+border+bordercolor;
 vinput1.style.background="transparent"; //background;
 DrawProgressBar(id);
}


function DrawProgressBar(id)
{
 var n=GetID(id);
 var temp;
 var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
 //var ctx_ = document.getElementById(id+"_").getContext("2d");     //c.getContext("2d");
 //console.log(hmiobj[n].LEFT, hmiobj[n].TOP, hmiobj[n].DIAMETER);
//***************************************************************************************************// Fill Background
 ctx.beginPath();
 ctx.strokeStyle ="transparent";
 ctx.fillStyle = hmiobj[n].BACKGROUND;
 if (hmiobj[n].ROUND==false) ctx.fillRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
 else ctx.roundRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT,10);
 ctx.fill();
 ctx.stroke();
//***************************************************************************************************// Fill Value
 ctx.beginPath();
 ctx.strokeStyle ="transparent";
 if (hmiobj[n].VAL>=hmiobj[n].MAX) temp=hmiobj[n].MAX;
 else if (hmiobj[n].VAL<=hmiobj[n].MIN) temp=hmiobj[n].MIN;
 else temp=hmiobj[n].VAL;
 temp-=hmiobj[n].MIN;
 temp/=hmiobj[n].MAX-hmiobj[n].MIN;
 temp*=hmiobj[n].HEIGHT;
 ctx.fillStyle = hmiobj[n].COLOR;
 if (hmiobj[n].ROUND==false) ctx.fillRect(0, hmiobj[n].HEIGHT-temp, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
 else ctx.roundRect(0, hmiobj[n].HEIGHT-temp, hmiobj[n].WIDHT, hmiobj[n].HEIGHT, 10);
 ctx.fill();
 ctx.stroke();
}



//*****************************************************************************************************//
//                                           Calendar                                                  //
//*****************************************************************************************************//
const kFontScale=1.5;
const kFontComp=0.4;
const weekname = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
const monthname = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DECEMBER"];
const kUpPosX=300;
const kUpPosY=5;
const kDownPosY=10;


function CreateCalendar(id, left, top, width, height, fontSize, text, fonttype, color, background, colsel, border, position)
{
 const d = new Date();

 hmiobj.push({ OBJECT:'calendar', ID:id, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               DATETIME:'now',
               FONTSIZE:fontSize*resY/100, FONTTYPE:fonttype,
               COLOR:color, BACKGROUND:background, COLSEL:colsel,
               SELECTION:false, REFRESH:false, SHOW:kTop, CLICKUP:false, CLICKDOWN:false, CLICKCROSS:false, FIRST:false, SELECTIDX:0,
               ZINDEX:1, YEAR:d.getFullYear(), MONTH:d.getMonth(), DAY:d.getDate(), DATE:0, HOUR:0, MIN:0, SEC:0, SELYEAR:d.getFullYear(), SELMONTH:d.getMonth(), SELDAY:d.getDate(), TEXT:text, HIDDEN:false,
               });

 var n=GetID(id);
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;  //"absolute";
 vdiv.style.left=hmiobj[n].LEFT+'px';
 vdiv.style.top=hmiobj[n].TOP+'px';
 vdiv.style.width=hmiobj[n].WIDHT;
 vdiv.style.height=hmiobj[n].HEIGHT;
 vdiv.style.textAlign = "left";
 vdiv.classList.add("class"+id+"left");
 
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id);
 vdiv.appendChild(vinput);
 vinput.style.position=position;    //'absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=hmiobj[n].WIDHT;
 vinput.height=hmiobj[n].HEIGHT;    //hmiobj[n].FONTSIZE;  //   fontSize;  //textoption.length*(fontSize*resY)/100;//height;  
 vinput.style="border:0px solid";
 vinput.style.background=background;    //"transparent";
 vinput.style.border=border+'black';
 vinput.setAttribute("onmousedown", "PressCalendar(this.id)");
 vinput.setAttribute("onmouseup", "UnPressCalendar(this.id)");
 
 var vinputimgup = document.createElement('img');
 document.body.appendChild(vinputimgup);
 vinputimgup.setAttribute("id", "optup"+id);
 vinputimgup.src='image/arrowup.png';
 vinputimgup.style.display='none';   //       'none';//'block';    //block
 vinputimgup.style.position=position;   //'absolute';
 var vinputimgdown = document.createElement('img');
 document.body.appendChild(vinputimgdown); 
 vinputimgdown.setAttribute("id", "optdown"+id);
 vinputimgdown.src='image/arrowdown.png';
 vinputimgdown.style.display='none';   //       'none';//'block';    //block
 vinputimgdown.style.position='absolute';
 var vinputimgcross = document.createElement('img');
 document.body.appendChild(vinputimgcross); 
 vinputimgcross.setAttribute("id", "optcross"+id);
 vinputimgcross.src='image/arrowdown.png';
 vinputimgcross.style.display='none';   //       'none';//'block';    //block
 vinputimgcross.style.position=position;    //'absolute';
 hmiobj[n].TEXT=hmiobj[n].DAY+'/'+parseInt(hmiobj[n].MONTH+1)+'/'+hmiobj[n].YEAR;
 DrawCalendar(id, 500);
}


function DrawCalendar(id, timeout)
 {
  var n=GetID(id);
  var ctx = document.getElementById(id).getContext("2d");
  var imgup = document.getElementById("optup"+id);
  var imgdown = document.getElementById("optdown"+id);
  var imgcross = document.getElementById("optcross"+id);
  var divx= document.getElementById('div'+id);
  var temp;
  var days=[];
  var months=[];
  var years=[];
  var firstdate;
  //var fontsize=Math.trunc(hmiobj[n].FONTSIZE*1.4);
  var fontsize=Math.trunc(hmiobj[n].FONTSIZE*kFontScale);
  var i, j;
  var maxitem, offitem, height, width;   
  if ((resY-hmiobj[n].TOP)>=(hmiobj[n].TOP)) hmiobj[n].SHOW=kBotttom;
  else hmiobj[n].SHOW=kTop;

  if (hmiobj[n].CLICKUP) imgup.src='image/arrow_up_click.png';
  else imgup.src='image/arrow_up.png';
  if (hmiobj[n].CLICKDOWN) imgdown.src='image/arrow_down_click.png';
  else imgdown.src='image/arrow_down.png';
  if (hmiobj[n].CLICKCROSS) imgcross.src='image/cross_click.png';
  else imgcross.src='image/cross.png';

  divx.style.zIndex=hmiobj[n].ZINDEX;
  //console.log('fontsize: '+fontsize);
  for (i=0; i<35; i++) days[i]="";

  setTimeout(function()
    {
     if (hmiobj[n].SELECTION)    
         {
          ctx.beginPath();
          width=weekname.length*(fontsize*3);
          height=8.5*fontsize;
          const kOffDayCalendar=fontsize*2;
          document.getElementById(id).height=height;   //fontsize*maxitem;    //hmiobj[n].TEXTOPTION.length;
          document.getElementById(id).width=width;
          ctx.fillStyle = "white";
          ctx.clearRect(0, 0, width, height);
          ctx.fillRect(0, 0, width, height);
          ctx.stroke();

          ctx.beginPath();
          ctx.font = hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
          ctx.textAlign = "center";
          ctx.fillStyle  = "black";    //hmiobj[n].PARAM[i].COLOR;
          for (i=0; i<7; i++) ctx.fillText(weekname[i], fontsize*1.5+i*width/weekname.length, kOffDayCalendar);
          var day=0;

          var daypermonth;
          var daypermonthn1;

          //console.log(hmiobj[n].DAY, hmiobj[n].MONTH, hmiobj[n].YEAR, hmiobj[n].DATE);

          if (CheckLunar(hmiobj[n].YEAR)) daypermonth=kTblMonthLunar[hmiobj[n].MONTH];
          else daypermonth=kTblMonth[hmiobj[n].MONTH];
          if (hmiobj[n].MONTH>=1)
              {
               if (CheckLunar(hmiobj[n].YEAR)) daypermonthn1=kTblMonthLunar[hmiobj[n].MONTH-1];
               else daypermonthn1=kTblMonth[hmiobj[n].MONTH-1];
              }
          else daypermonthn1=kTblMonth[11];

          firstdate=GetDateS(1, hmiobj[n].MONTH+1, hmiobj[n].YEAR);
          //console.log('firstdate: '+firstdate);
          
          j=daypermonthn1-firstdate+1;
          //console.log(hmiobj[n].firstdate, daypermonthn1);
          for (i=0; i<firstdate; i++)
              {
               if (hmiobj[n].MONTH>=1)
                  {
                   months[i]=hmiobj[n].MONTH-1;
                   days[i]=j;
                   years[i]=hmiobj[n].YEAR;
                 }
               else
                 {
                  days[i]=j;
                  months[i]=11;
                  years[i]=hmiobj[n].YEAR-1;
                 }
               j++;
              }
          j=1;
          //console.log("idx: "+i);
          for (i=firstdate; i<=42; i++)
             {
              if (j>daypermonth) break;
              days[i]=j++;
              months[i]=hmiobj[n].MONTH;
              years[i]=hmiobj[n].YEAR;
              if (days[i]==hmiobj[n].DAY)
                {
                 //console.log("Day: "+i+"  "+days[i]);
                 if (hmiobj[n].FIRST==false)
                    {
                     hmiobj[n].SELECTIDX=i;
                     hmiobj[n].FIRST=true;
                    }
                }
             }
          j=1;
          for (i=i; i<42; i++)
             {
              days[i]=j++;
              if (hmiobj[n].MONTH<11)
                 {
                  months[i]=hmiobj[n].MONTH+1;
                  years[i]=hmiobj[n].YEAR;
                 }
              else
                 {
                  months[i]=0;
                  years[i]=hmiobj[n].YEAR+1;
                 }
             }

         for (i=0; i<6; i++)
             {
              for (j=0; j<7; j++)
                  {
                   ctx.fillStyle  = "black";
                   if (months[j+i*7]==hmiobj[n].MONTH) ctx.fillStyle  = "black";
                   else ctx.fillStyle  = "gray"; 
                   if (hmiobj[n].SELECTIDX==(i*7)+j)
                      {
                       ctx.fillStyle="red";
                       hmiobj[n].SELYEAR=years[(i*7)+j];
                       hmiobj[n].SELMONTH=months[(i*7)+j];
                       hmiobj[n].SELDAY=days[(i*7)+j];
                       hmiobj[n].TEXT=hmiobj[n].SELDAY+'/'+parseInt(hmiobj[n].SELMONTH+1)+'/'+hmiobj[n].SELYEAR;
                      }
                   ctx.fillText(days[j+i*7], fontsize*1.5+j*width/weekname.length, kOffDayCalendar+fontsize+(i*fontsize));
                  }
              }
         ctx.stroke();

         ctx.beginPath();
         const kDownPosX=kUpPosX+fontsize+5;
         ctx.drawImage(imgup,   width-kUpPosX, fontsize/2, fontsize/2, fontsize/2);
         ctx.drawImage(imgdown, width-kDownPosX, fontsize/2, fontsize/2, fontsize/2);
         ctx.drawImage(imgcross, width-fontsize/2-3, 3, fontsize/2, fontsize/2);
         ctx.stroke();

         ctx.beginPath();
         ctx.fillStyle  = "black";
         ctx.fillText(monthname[hmiobj[n].MONTH]+' '+hmiobj[n].YEAR, width/6, fontsize);
         ctx.stroke();
        }
     else
         {
          document.getElementById(id).style.background="transparent";
          document.getElementById(id).height=hmiobj[n].HEIGHT;  //*fontsize*0.5;
          document.getElementById(id).width=hmiobj[n].WIDHT;                
          ctx.beginPath();
          ctx.fillStyle = hmiobj[n].BACKGROUND;
          divx.style.top=hmiobj[n].TOP+'px';
          divx.style.zIndex=0;
          fontsize=hmiobj[n].FONTSIZE;
          height=hmiobj[n].HEIGHT;
          var temp=(height/(fontsize*1.5));
          var CentreTextPos=((height/temp)+0.7*fontsize)/2;

          if (hmiobj[n].HIDDEN)
             {
              ctx.clearRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].WIDHT);
              ctx.stroke();
             }
          else
             {
              ctx.clearRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].WIDHT);
              //ctx.fillStyle = hmiobj[n].COLSEL;
              ctx.fillRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].WIDHT);
              ctx.stroke();
              ctx.beginPath();
              ctx.fillStyle = hmiobj[n].COLOR;
              ctx.textAlign = "center";
              ctx.font=hmiobj[n].FONTSIZE+'px '+hmiobj[n].FONTTYPE;
              ctx.fillText(hmiobj[n].TEXT, hmiobj[n].WIDHT/2, CentreTextPos);
              //ctx.fillText('ABCD', hmiobj[n].WIDHT/2, CentreTextPos);
              ctx.stroke();
            }
         }
      },timeout); 
}



function PressCalendar(id)
{
 var n=GetID(id);
 var fontsize=Math.trunc(hmiobj[n].FONTSIZE*kFontScale);
 var width=weekname.length*(fontsize*3);
 const kOffDayCalendar=fontsize*2;
 const kOffDayPos=kOffDayCalendar+fontsize*kFontComp;

 hmiobj[n].ZINDEX=99;
 focusid=id;
 if (hmiobj[n].SELECTION)
     {
      var relX=MouseX-hmiobj[n].LEFT;
      var relY=MouseY-hmiobj[n].TOP;
      //console.log(relX, relY);
      if ((relX>=0)&&(relX<=width)&&
          (relY>=kOffDayPos)&&(relY<=(kOffDayPos+8*fontsize)))
            {
             //console.log('in Area !!!');
             var x=Math.floor(relX/(width/weekname.length));
             var y=Math.floor((relY-kOffDayPos)/fontsize);
             //console.log(x,y);
             hmiobj[n].SELECTIDX=y*7+x;
            }
      const kDownPosX=kUpPosX+fontsize+5;
      if ((relX>=width-kUpPosX)&&(relX<=(width-kUpPosX+fontsize/2))&&(relY>=fontsize/2)&&(relY<=fontsize))
         {
          hmiobj[n].CLICKUP=true; 
          hmiobj[n].MONTH++;
          if (hmiobj[n].MONTH>=12)
             {
              hmiobj[n].MONTH=0;
              hmiobj[n].YEAR++;
              if (hmiobj[n].YEAR>=2137) hmiobj[n].YEAR=2137;
             }
          hmiobj[n].DATE=GetDateS(1,hmiobj[n].MONTH+1,hmiobj[n].YEAR);
          //console.log(hmiobj[n].DATE);
         }
      if ((relX>=width-kDownPosX)&&(relX<=(width-kDownPosX+fontsize/2))&&(relY>=fontsize/2)&&(relY<=fontsize))
         {
          hmiobj[n].CLICKDOWN=true; 
          hmiobj[n].MONTH--;
          if (hmiobj[n].MONTH<0)
             {
              hmiobj[n].MONTH=11;
              hmiobj[n].YEAR--;
              if (hmiobj[n].YEAR<=2000) hmiobj[n].YEAR=2000;
             }
          hmiobj[n].DATE=GetDateS(1,hmiobj[n].MONTH+1,hmiobj[n].YEAR);
         }
      if ((relX>=width-fontsize/2)&&(relX<=width)&&(relY>=0)&&(relY<=fontsize/2))
         {
          hmiobj[n].CLICKCROSS=true;
          hmiobj[n].SELECTION=false;
         }         
     }
 else
     {
      hmiobj[n].SELECTION=true;
      const d = new Date();
      hmiobj[n].YEAR=d.getFullYear();
      hmiobj[n].MONTH=d.getMonth();
      hmiobj[n].DAY=d.getDate();
      hmiobj[n].DATE=GetDateS(hmiobj[n].DAY, hmiobj[n].MONTH+1, hmiobj[n].YEAR);
      hmiobj[n].FIRST=false;
     }
 DrawCalendar(id, 100);
}


function UnPressCalendar(id)
{
 var n=GetID(id);
 if (n>=0)
    {
     hmiobj[n].CLICKUP=false;
     hmiobj[n].CLICKDOWN=false;
     hmiobj[n].CLICKCROSS=false;
     hmiobj[n].REFRESH=true;
    }

}

/************************************************************************************************************/
/*                                            Draw Rect                                                     */
/************************************************************************************************************/
function CreateRect(id, left, top, width, height, position, color, round)
{
hmiobj.push({ OBJECT:'rect', ID:id, TOP:resY*top/100, LEFT:resX*left/100, WIDHT:resX*width/100, HEIGHT:resY*height/100,
               COLOR:color, ROUND:round,
               }); 
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position=position;   //"absolute";
 vdiv.style.left=resX*left/100+'px';
 vdiv.style.top=resY*top/100+'px';
 vdiv.style.width=resX*width/100;
 vdiv.style.height=resY*height/100;
 vdiv.style.textAlign = "center";
 vdiv.style.zIndex=0;
 vdiv.classList.add("class"+id+"center");
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=resX*width/100;    
 vinput.height=resY*height/100;
 //vinput.style.border-radius="25px";
 //border-radius: 25px;
 //vinput.style="border:0px solid";
 vinput.style.background="transparent";
 DrawRect(id);  
}


function DrawRect(id)
{
 var n=GetID(id);
 var ctx = document.getElementById(id).getContext("2d");
 
 ctx.beginPath();
 //ctx.lineWidth=0;
 ctx.strokeStyle ="transparent";
 ctx.fillStyle = hmiobj[n].COLOR;
 if (hmiobj[n].ROUND) ctx.roundRect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT, hmiobj[n].ROUND);
 else ctx.rect(0, 0, hmiobj[n].WIDHT, hmiobj[n].HEIGHT);
 ctx.fill();
 ctx.stroke();
}

/************************************************************************************************************/
/*                                            Draw Circle                                                   */
/************************************************************************************************************/
function DrawCircle(id, left, top, diameter, color)
{
 var vdiv=document.createElement('div');
 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=resX*left/100+'px';
 vdiv.style.top=resY*top/100+'px';
 vdiv.style.width=resX*diameter/100;
 vdiv.style.height=resY*diameter/100;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=resX*diameter/100;    
 vinput.height=resY*diameter/100;
 //vinput.style.border-radius="25px";
 //border-radius: 25px;
 //vinput.style="border:0px solid";
 vinput.style.background="transparent";

 

 var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
 ctx.beginPath();
 //ctx.lineWidth=0;
 ctx.strokeStyle ="transparent";
 ctx.fillStyle = color;   //hmiobj[n].SEGY[i].TEXTCOLOR;
 ctx.arc(0.5*resX*diameter/100, 0.5*resY*diameter/100, 0.5*resY*diameter/100, 0, 2 * Math.PI);
 //ctx.arc(hmiobj[n].DIAMETER*0.5, (ctx.lineWidth+hmiobj[n].DIAMETER*0.5), (hmiobj[n].DIAMETER*0.5), radStart, radEnd, false);
 ctx.fill();
 ctx.stroke();
}


/************************************************************************************************************/
/*                                            Draw Image                                                    */
/************************************************************************************************************/
function DrawImage(id, left, top, width, height, filename) {
    var vdiv = document.createElement('div');
    vdiv.setAttribute("id", 'div'+id);
    document.body.appendChild(vdiv);
    vdiv.classList.add("class"+id);
    vdiv.style.position = "absolute";
    vdiv.style.left = resX*left/100+'px';
    vdiv.style.top = resY*top/100+'px';
    vdiv.style.width = resX*width/100 + 'px';
    vdiv.style.height = resY*height/100 + 'px';
    vdiv.style.textAlign = "center";
    vdiv.classList.add("class"+id+"center");
    
    var vcanvas = document.createElement('canvas');
    vcanvas.setAttribute("id", id); 
    vdiv.appendChild(vcanvas);
    vcanvas.style.position = 'absolute';
    vcanvas.style.top = 0;
    vcanvas.style.left = 0;
    vcanvas.width = resX*width/100;    
    vcanvas.height = resY*height/100;
    vcanvas.style.border = "0px solid";
    vcanvas.style.background = "transparent";
    
    var ctx = vcanvas.getContext("2d");
    
    // Create image in memory
    var img = new Image();
    img.src = filename;
    img.onload = function() {
        ctx.clearRect(0, 0, vcanvas.width, vcanvas.height); // optional
        ctx.drawImage(img, 0, 0, vcanvas.width, vcanvas.height);
        ctx.stroke();
    };
}

/*
function DrawImage(id, left, top, width, height, filename)
{
 var vdiv=document.createElement('div');
 var source=filename;

 vdiv.setAttribute("id", 'div'+id);
 document.body.appendChild(vdiv);
 vdiv.classList.add("class"+id);
 vdiv.style.position="absolute";
 vdiv.style.left=resX*left/100+'px';
 vdiv.style.top=resY*top/100+'px';
 vdiv.style.width=resX*width/100;
 vdiv.style.height=resY*height/100;
 vdiv.style.textAlign = "center";
 vdiv.classList.add("class"+id+"center");
     
 var vinput = document.createElement('canvas');
 vinput.setAttribute("id", id); 
 vdiv.appendChild(vinput);
 vinput.style.position='absolute';
 vinput.style.top=0;
 vinput.style.left=0;
 vinput.width=resX*width/100;    
 vinput.height=resY*height/100;
 //vinput.style.border-radius="25px";
 //border-radius: 25px;
 vinput.style="border:0px solid";
 vinput.style.background="transparent";

 var vinputimg = document.createElement('img');        
 document.body.appendChild(vinputimg); 
 vinputimg.setAttribute("id", "img"+id);
 vinputimg.src=filename;
 vinputimg.style.display='none';   //       'none';//'block';    //block
 vinputimg.style.position='absolute';


 var ctx = document.getElementById(id).getContext("2d");     //c.getContext("2d");
 var img = document.getElementById("img"+id);

 console.log(resX*width/100, resY*height/100);
 ctx.beginPath();
 console.log(source); 
 img.src=source;
 setTimeout(function()
       {
        ctx.drawImage(img, 0, 0, resX*width/100, resY*height/100);
        },500);
 ctx.stroke();
}

*/

//*****************************************************************************************************//
//                                              Load File                                              //
//*****************************************************************************************************//
function readTextFile(file)
{
    var allText;
    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", file, false);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
               allText = rawFile.responseText;                
            }
        }
    }
    rawFile.send(null);
 return(allText);   
}



//**********************************************************************************************************//
//                                          Mouse                                                           //
//**********************************************************************************************************//
onmousemove = function(e)
   {
    var e = window.event;
    var n;

     MouseX=e.clientX+document.documentElement.scrollLeft;
     MouseY=e.clientY+document.documentElement.scrollTop;
     if (MouseDown)
        {
         if (focusid)
            {
             n=GetID(focusid);
             if (n>=0)
                 {
                  if (hmiobj[n].OBJECT=='table')
                     {
                      if (hmiobj[n].SCROLLPRESS)
                         {
                          //console.log("here move... :"+focusid);
                          PressTable(focusid);
                         }
                     }
                 }
             }
        }
     //console.log(Math.round(MouseX),',',Math.round(MouseY), ' Window:',resX,',',resY);
   }

onmousedown = function(e)
    {
     var e = window.event;
     MouseDown=true;
     //console.log('press mouse', focusid);

    }


onmouseup = function(e)
    {
     var e = window.event;
     MouseDown=false;
     var n=GetID(focusid);
     if (n>=0)
        {
         if (hmiobj[n].OBJECT=='table')
            {
             hmiobj[n].SCROLLPRESS=false;   
            }   
        }
//     console.log('release mouse'); 
    }



//**********************************************************************************************************//
//                                          Keyboard                                                        //
//**********************************************************************************************************//
document.addEventListener('keydown', function(event) {
KeyBoardEdgePress=true;
KeyBoardPress=true;
KeyChar=event.key;
KeyChar_=KeyChar;
KeyCode=event.keyCode;


if (focusid)
    {
     if (KeyChar=='Backspace') 
        {
         if (KeyboardBuff.length) KeyboardBuff=KeyboardBuff.slice(0, KeyboardBuff.length-1);
        } 
    if ((KeyChar=='Shift')||(KeyChar=='CapsLock')||(KeyChar=='Tab')||(KeyChar=='Alt')||
        (KeyChar=='ArrowUp')||(KeyChar=='ArrowDown')||(KeyChar=='ArrowLeft')||(KeyChar=='ArrowRight')||
        (KeyChar=='Home')||(KeyChar=='End')||(KeyChar=='Insert')||(KeyChar=='PageUp')||(KeyChar=='PageDown')||(KeyChar=='Delete')||
        (KeyChar=='NumLock')||
        (KeyChar=='F1')||(KeyChar=='F2')||(KeyChar=='F3')||(KeyChar=='F4')||(KeyChar=='F5')||(KeyChar=='F6')||
        (KeyChar=='F7')||(KeyChar=='F8')||(KeyChar=='F9')||(KeyChar=='F10')||(KeyChar=='F11')||(KeyChar=='F12')||
        (KeyChar=='Enter')||(KeyChar=='Escape')||(KeyChar=='Control')||(KeyChar=='Backspace')
        ) KeyChar_='';
     n=GetID(focusid);
     if (n>=0)
         {
          if (hmiobj[n].OBJECT=='labellocal')
             {
              if ((hmiobj[n].TYPE=="CLOCK")||(hmiobj[n].TYPE=="CLOCK_SEC")||(hmiobj[n].TYPE=="NUM"))
                 {
                  if ((KeyChar<'0')||(KeyChar>'9')) KeyChar_='';
                 }
             }
         }
     KeyboardBuff+=KeyChar_;
    }
if (focusid)
     {
      var n=GetID(focusid);
      if (n>=0)
         {
          if (hmiobj[n].OBJECT=='labellocal')
             {
              if (hmiobj[n].TYPE=="CLOCK") KeyboardBuff=KeyboardBuff.slice(0,4);
              else if (hmiobj[n].TYPE=="CLOCK_SEC") KeyboardBuff=KeyboardBuff.slice(0,6);
              hmiobj[n].TEXT=KeyboardBuff;
              hmiobj[n].REFRESH=true;  
             }
         }
      if ((KeyChar=='Enter')||(KeyChar=='Escape'))
          {  
           if (hmiobj[n].OBJECT=='labellocal')
               {
                //console.log(hmiobj[n].TEXT, hmiobj[n].TEXT.length);
                UpdateLocalLabel(focusid);
                if (hmiobj[n].VTYPE==kVarCACHE)
                    {
                     SetValVarWRObj(focusid, hmiobj[n].TEXT);
                    }
                else if (hmiobj[n]>VTYPE==kVarLOCAL)
                    {
                     localStorage.setItem(focusid, hmiobj[n].TEXT);
                    }
               }
           focusid=null;               
          }
     }
else
    {
     KeyboardBuff='';
    }
});


function UpdateLocalLabel(id)
{
 var n=GetID(id);
 var stat=false;
 if (hmiobj[n].TYPE=='CLOCK')
    {
     var str=hmiobj[n].TEXT[0]+hmiobj[n].TEXT[1];
     var str1=hmiobj[n].TEXT[2]+hmiobj[n].TEXT[3];
     if (parseInt(str)>=24) stat=true;
     if (parseInt(str1)>=60) stat=true;
     if ((hmiobj[n].TEXT.length<4)&&(hmiobj[n].TEXT.length)) stat=true;
     if (stat) hmiobj[n].TEXT=hmiobj[n].TEXTLAST;                   // if any error reload last value
     else hmiobj[n].TEXT=hmiobj[n].TEXTPROC;
     hmiobj[n].REFRESH=true;                         
    }
  else if (hmiobj[n].TYPE=='CLOCK_SEC')
    {
     var str=hmiobj[n].TEXT[0]+hmiobj[n].TEXT[1];
     var str1=hmiobj[n].TEXT[2]+hmiobj[n].TEXT[3];
     var str2=hmiobj[n].TEXT[4]+hmiobj[n].TEXT[5];
     if (parseInt(str)>=24) stat=true;
     if (parseInt(str1)>=60) stat=true;
     if (parseInt(str2)>=60) stat=true;
//   console.log(hmiobj[n].TEXT, str, str1, str2);
     if ((hmiobj[n].TEXT.length<6)&&(hmiobj[n].TEXT.length)) stat=true;
     if (stat) hmiobj[n].TEXT=hmiobj[n].TEXTLAST;                   // if any error reload last value
     else hmiobj[n].TEXT=hmiobj[n].TEXTPROC;
     hmiobj[n].REFRESH=true;
    }
 hmiobj[n].EDITED_=true;
}


document.addEventListener('keyup', function(event) {
   //console.log(event.keyCode);
   // KeyB=event.keyCode;
   // console.log('keyup ...');
    if (KeyBoardPress==true)
        {
         KeyBoardPress=false;
         KeyBoardEdgeRelease=true;
        }
    else
        {
         KeyBoardEdgeRelease=false;
        }
});


function UpdateLabel(id, text)
{
 var n;

 n=GetID(id);
 if (n>=0)
    {
     hmiobj[n].TEXT=text;
     hmiobj[n].REFRESH=true;
    }
}
