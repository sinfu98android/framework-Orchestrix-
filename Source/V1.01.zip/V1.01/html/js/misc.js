const kStartYear=2000;
const kOffDate=6;
const kTblMonth=[31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const kTblMonthLunar=[31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const kTblDate=['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const ktagSubmit=1000000;
const kIDLE=0;
const kError=-1;

let retval;
let retvalarray=new Array();
//let key;
let id;
let param;
let respone;
let refreshHMI=0;
let idxbutton=0
let memcacheStat;
let sending=false;
let tagReq=null;
var taqsubmit=parseInt(Math.random()*ktagSubmit);
var curstate=kIDLE;
var callbackstate=kIDLE;
var statedb=kIDLE;
var timeoutdb=0;
var timoutestate=0;
var dateStart, dateEnd;

//let varRDMobj = [];


function ReloadWindow()
{
 if (curstate)
     {
      if (tick1S) timoutestate++;
      if (timoutestate>=15)
         {
          timoutestate=0;
          console.log("reload window");
          window.location.reload();
         }
     }
 else timoutestate=0;   
}


function tagProcess()
{
 taqsubmit=parseInt(Math.random()*ktagSubmit);
}


/*
function GetTimestamp()
{
 var timestamp=parseInt(Date.now());
// console.log(timestamp);
 return(timestamp) ;
}
*/


function GetDatetime()
{
 const d = new Date();
 var year  = d.getFullYear();
 var month = d.getMonth()+1;
 var date = d.getDate();
 var hour  = d.getHours();
 var minute = d.getMinutes();
 var second = d.getSeconds();
 return(year+','+month+','+date+','+hour+','+minute+','+second);
}


function GetDatetimeTagFile()
{
 const d = new Date();
 var year  = d.getFullYear();
 var month = zerolead(d.getMonth()+1,2);
 var date = zerolead(d.getDate(),2);
 var hour  = zerolead(d.getHours(),2);
 var minute = zerolead(d.getMinutes(),2);
 var second = zerolead(d.getSeconds(),2);
 return(year+month+date+hour+minute+second);
}


function GetDatetimeBuff()
{
 const d = new Date();
 var tdatetime={year:d.getFullYear(), month:d.getMonth()+1, day:d.getDate(), hour:d.getHours(), min:d.getMinutes(), sec:d.getSeconds(), weekday:d.getDay()};
 return(tdatetime);
}


function GetDatetimeInt()
{
 const d = new Date();
 var tdatetime = {year:d.getFullYear(), month:d.getMonth()+1, day:d.getDate(), hour:d.getHours(), min:d.getMinutes(), sec:d.getSeconds(), date:0};
 var temp=ConvDatetimetoInt(tdatetime);
 return(temp);
}

function zerolead(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}


function WaitDelay(n)
   {
    var starttime=GetTimeStamp();
    var endtime;
    while(1)
         {
          endtime=GetTimeStamp();
          if ((endtime-starttime)>=n) break;
         }
   }


function GetTimeStamp()
    {
     return(new Date().getTime());
    }


function CheckLunar(year)
{
  if ((year % 400)==0) return(true);
  if ((year % 100)==0) return(false);
  if ((year % 4)==0) return(true);
  return(false);
}

function GetYear(val)
{
 var tdatetime = {year:0, month:0, date:0, hour:0, min:0, sec:0, day:0};
 var temp;

 val=parseInt(val/60);
 val=parseInt(val/60);
 val=parseInt(val/24);
 tdatetime.day=kTblDate[(kOffDate+val) % 7];
 //console.log(kTblDate[tdatetime.day]);
 tdatetime.year=kStartYear;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=366;
     else temp=365;
     if (val<temp) break;
     else
        {
         tdatetime.year++;
         val-=temp;
        }
    }
 return(tdatetime.year);
}


function GetMonth(value)
{
 var tdatetime = {year:0, month:0, date:0, hour:0, min:0, sec:0, day:0};
 var temp;

 var val=value;
 val=parseInt(val/60);
 val=parseInt(val/60);
 val=parseInt(val/24);
 tdatetime.year=kStartYear;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=366;
     else temp=365;
     if (val<temp) break;
     else
        {
         tdatetime.year++;
         val-=temp;
        }
    }
 tdatetime.month=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=kTblMonthLunar[tdatetime.month];
     else temp=kTblMonth[tdatetime.month];
     if (val<temp) break;
     else
        {
         val-=temp;
         tdatetime.month++;
        }
    }
 tdatetime.month++;
 return(tdatetime.month);
}


function GetDay(value)
{
 var tdatetime = {year:0, month:0, day:0, hour:0, min:0, sec:0, date:0};
 var temp;

 var val=value;
 tdatetime.sec=val % 60;
 val=parseInt(val/60);
 tdatetime.min=val % 60;
 val=parseInt(val/60);
 tdatetime.hour=val % 24;
 val=parseInt(val/24);
 tdatetime.date=kTblDate[(kOffDate+val) % 7];
 //console.log(kTblDate[tdatetime.day]);
 tdatetime.year=kStartYear;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=366;
     else temp=365;
     if (val<temp) break;
     else
        {
         tdatetime.year++;
         val-=temp;
        }
    }
 tdatetime.month=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=kTblMonthLunar[tdatetime.month];
     else temp=kTblMonth[tdatetime.month];
     if (val<temp) break;
     else
        {
         val-=temp;
         tdatetime.month++;
        }
    }
 //tdatetime.day=val;
 return(val+1);
}


function GetDate(val)
{
 var tdatetime = {year:0, month:0, day:0, hour:0, min:0, sec:0, date:0};
 var temp;

 val/=86400;
 tdatetime.date=kTblDate[(kOffDate+val) % 7];   
 return(tdatetime.date);
}


function GetDateS(day, month, year)
{
 var temp=0;
 var i;

 day--;
 month--;
 for (i=kStartYear; i<year; i++)
    {
     if (CheckLunar(i)) temp+=366;
     else temp+=365;
    }
 for (i=0; i<month; i++)
     {
      if (CheckLunar(year)) temp+=kTblMonthLunar[i];
      else temp+=kTblMonth[i];
     }
 temp+=day;
 return(((kOffDate+temp) % 7));
}


function ConvDatetimetoInt(tdatetime)
{
 var i;
 var temp;

 tdatetime.month--;
 tdatetime.day--;
 //console.log(tdatetime.year, tdatetime.month, tdatetime.day, tdatetime.hour, tdatetime.min);
 temp=tdatetime.day;
 for (i=kStartYear; i<tdatetime.year; i++)
     {
      if (CheckLunar(i)) temp+=366;
      else temp+=365;
     }
 //console.log(temp);
 for (i=0; i<tdatetime.month; i++)
     {
      if (CheckLunar(tdatetime.year)) temp+=kTblMonthLunar[i];
      else temp+=kTblMonth[i];
     }
 temp*=86400;
// if (tdatetime.hour!=null)
    {
     temp+=(tdatetime.hour*3600);
     temp+=(tdatetime.min*60);
     temp+=tdatetime.sec;
   }
 return(temp);
}


function ConvDatetimetoText(value)
{
 var tdatetime = {year:0, month:0, day:0, hour:0, min:0, sec:0, date:0};
 var temp;
 var i;

 var val=value;
 tdatetime.sec=val % 60;
 val=parseInt(val/60);
 tdatetime.min=val % 60;
 val=parseInt(val/60);
 tdatetime.hour=val % 24;
 val=parseInt(val/24);
 tdatetime.date=kTblDate[(kOffDate+val) % 7];
 //console.log(kTblDate[tdatetime.day]);
 tdatetime.year=kStartYear;
 var i=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=366;
     else temp=365;
     if (val<temp) break;
     else
        {
         tdatetime.year++;
         val-=temp;
        }
     i++;
     if (i>=150) return(null);
    }
 tdatetime.month=0;
 i=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=kTblMonthLunar[tdatetime.month];
     else temp=kTblMonth[tdatetime.month];
     if (val<temp) break;
     else
        {
         val-=temp;
         tdatetime.month++;
        }
     if (i>=150) return(null);
    }
 tdatetime.month++;
 tdatetime.day=val+1;
 if (tdatetime.day<10) tdatetime.day='0'+tdatetime.day;
 if (tdatetime.month<10) tdatetime.month='0'+tdatetime.month;
 if (tdatetime.hour<10) tdatetime.hour='0'+tdatetime.hour;
 if (tdatetime.min<10) tdatetime.min='0'+tdatetime.min;
 if (tdatetime.sec<10) tdatetime.sec='0'+tdatetime.sec;
 //return(tdatetime.date+" "+tdatetime.day+'/'+tdatetime.month+'/'+tdatetime.year+' '+tdatetime.hour+':'+tdatetime.min+':'+tdatetime.sec);
 //console.log("sec:"+tdatetime.sec);
 return(tdatetime.day+'/'+tdatetime.month+'/'+tdatetime.year+' '+tdatetime.hour+':'+tdatetime.min+':'+tdatetime.sec)   
}


function ConvDateText(value)
{
 var tdatetime = {year:0, month:0, day:0, hour:0, min:0, sec:0, date:0};
 var temp;
 var i;

 var val=value;
 tdatetime.sec=val % 60;
 val=parseInt(val/60);
 tdatetime.min=val % 60;
 val=parseInt(val/60);
 tdatetime.hour=val % 24;
 val=parseInt(val/24);
 tdatetime.date=kTblDate[(kOffDate+val) % 7];
 //console.log(kTblDate[tdatetime.day]);
 tdatetime.year=kStartYear;
 var i=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=366;
     else temp=365;
     if (val<temp) break;
     else
        {
         tdatetime.year++;
         val-=temp;
        }
     i++;
     if (i>=150) return(null);
    }
 tdatetime.month=0;
 i=0;
 while(1)
    {
     if (CheckLunar(tdatetime.year)) temp=kTblMonthLunar[tdatetime.month];
     else temp=kTblMonth[tdatetime.month];
     if (val<temp) break;
     else
        {
         val-=temp;
         tdatetime.month++;
        }
     if (i>=150) return(null);
    }
 tdatetime.month++;
 tdatetime.day=val+1;
 if (tdatetime.day<10) tdatetime.day='0'+tdatetime.day;
 if (tdatetime.month<10) tdatetime.month='0'+tdatetime.month;
 if (tdatetime.hour<10) tdatetime.hour='0'+tdatetime.hour;
 if (tdatetime.min<10) tdatetime.min='0'+tdatetime.min;
 if (tdatetime.sec<10) tdatetime.sec='0'+tdatetime.sec;
 //return(tdatetime.date+" "+tdatetime.day+'/'+tdatetime.month+'/'+tdatetime.year+' '+tdatetime.hour+':'+tdatetime.min+':'+tdatetime.sec);
 return(tdatetime.day+'/'+tdatetime.month+'/'+tdatetime.year)   
}


function ConvTimetoInt(time)
{
 var i;

 if (time.length==5)
    {
     if (time[2]!=':') return(kError);
     time=time.slice(2,1);
     for (i=0; i<time.length; i++) {if ((time[i]<'0')||(time[i]>'9')) return(kError);}     
     console.log(time);
    }
 else if (time.length==8)
    {
     if ((time[2]!=':')&&(time[5]!=':')) return(kError);
     time=time.slice(0,2)+time.slice(3,5)+time.slice(6,8);
     for (i=0; i<time.length; i++) {if ((time[i]<'0')||(time[i]>'9')) return(kError);}
     var hour=parseInt(time[0]+time[1]);
     var min=parseInt(time[2]+time[3]);
     var sec=parseInt(time[4]+time[5]);
     return(hour*3600+min*60+sec);
    }
 return(kError);
}



function ConvDateTextToInt(str)
{
 var temp=0;

 var buff=str.split("-");
 //var tdatetime={year:buff[0], month:hmiobj[n].SELMONTH+1, day:1, hour:0, min:0, sec:0, date:0};
 var tdatetime={year:buff[0], month:buff[1], day:buff[2], hour:0, min:0, sec:0, date:0};
 temp=ConvDatetimetoInt(tdatetime);
 return(temp);
}


function ConvTimeTextToInt(str)
{
 var temp=0;

 var buff=str.split(":");
 //var tdatetime={year:buff[0], month:hmiobj[n].SELMONTH+1, day:1, hour:0, min:0, sec:0, date:0};
 temp=parseInt(buff[0])*3600;
 temp+=parseInt(buff[1])*60;
 temp+=parseInt(buff[2]);
 return(temp);
}


function openfile(filename)
   {
    var urlreq = new XMLHttpRequest();

    urlreq.open("POST",'file.php',true);
    urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
    urlreq.send('openfile='+filename);
    urlreq.onload = function()
                  {
                   retval=this.responseText;
                  }
    return(retval);
   }


function savefile(filename, content)
   {
    var urlreq = new XMLHttpRequest();

    urlreq.open("POST",'file.php',true);
    urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
    console.log('savefile='+filename+'&content='+content);
    urlreq.send('savefile='+filename+'&content='+content);
    urlreq.onload = function()
                  {
                   retval=this.responseText;
                  }
    return(retval);
   }


function getpost(link, name, value)
	{
	 var urlreq = new XMLHttpRequest();

	 urlreq.open("POST",link,true);
	 urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
     //urlreq.timeout=5000;
	 urlreq.send(name+'='+value);
	 urlreq.onload = function()
	 					{
	 					 retval=this.responseText;
	 					}
	 return(retval);	 					
	}


function getpostX(link, names, values)
	{
	 var n;
	 var urlreq = new XMLHttpRequest();
	 var string='';

     for (n=0; n<names.length; n++)
        {
          string+=names[n];
          string+='='
          string+=values[n];
          if (n<(names.length-1)) string+='&';
        }
     if (tagReq==null)
         {
          //console.log(link+' '+string);
          tagReq=link;
          urlreq.timeout=5000;
          urlreq.open("POST",link,true);
          urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');         
          urlreq.send(string);
        }
     urlreq.onload = function()
                       {
                        tagReq=null;
                        retvalarray=this.responseText.split(",");
                        //console.log(this.responseText);
                       }
     return(retvalarray);     
	}



function getpostXTOut(link, names, values, timeout)
    {
     var n;
     var urlreq = new XMLHttpRequest();
     var string='';

     for (n=0; n<names.length; n++)
        {
          string+=names[n];
          string+='='
          string+=values[n];
          if (n<(names.length-1)) string+='&';
        }
     if (tagReq==null)
         {
          //console.log(link+' '+string);
          tagReq=link;
          tagreqTOut=0;
          urlreq.timeout=timeout;
          urlreq.open("POST",link,true);
          urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');         
          urlreq.send(string);
        }
     else
        {
         tagreqTOut++;
         if (tagreqTOut>=100)
            {
             tagReq=null;
            }
        }
     //console.log('tag req: '+tagreqTOut);
     urlreq.onload = function()
                       {
                        tagReq=null;
                        tagreqTOut=0;
                        retvalarray=this.responseText.split(",");
                       }
     return(retvalarray);     
    }


function post(link, name, value)
	{
	 var urlreq = new XMLHttpRequest();
	 urlreq.open("POST",link,true);
	 urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
     //urlreq.timeout=2000;
	 urlreq.send(name+'='+value);
	}


function postX(link, names, values)
	{
	 var n;
	 var urlreq = new XMLHttpRequest();
	 var string;

	 urlreq.open("POST",link,true);
	 urlreq.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
     //urlreq.timeout=2000;
	 string='';
	 for (n=0; n<names.length; n++)
	 	{
 	 	  string+=names[n];
 	 	  string+='='
 	 	  string+=values[n];
	 	  if (n<(names.length-1)) string+='&';
	 	}
	 urlreq.send(string);	 
	}


function submitlink(link)
    {
     var form = document.createElement("form");

     form.type="hidden";

     form.method = "POST";
     form.action = link;

     document.body.appendChild(form);
     form.submit();
    }


function submit(link, name, value)
    {
     var form = document.createElement("form");
     var element1 = document.createElement("input");
     
     element1.type="hidden";
     form.type="hidden";

     form.method = "POST";
     form.action = link;

     element1.value=value;
     element1.name=name;
     form.appendChild(element1);  


     document.body.appendChild(form);
     form.submit();
    }


function submit2(link, name1, value1,  name2, value2)
    {
     var form = document.createElement("form");
     var element1 = document.createElement("input");
     var element2 = document.createElement("input");
     
     element1.type="hidden";
     element2.type="hidden";
     form.type="hidden";

     form.method = "POST";
     form.action = link;

     element1.value=value1;
     element1.name=name1;
     form.appendChild(element1);  

     element2.value=value2;
     element2.name=name2;
     form.appendChild(element2);

     document.body.appendChild(form);
     form.submit();
    }


function CreateTextFile()
    {
      var str;

          str="val1; val2;\r\n";
          str+="123; 321;\r\n";
          str+="456; 654;\r\n";
          str+="789; 987;\r\n";

         var blob = new Blob([str], {
            type: "csv/plain;charset=utf-8",
         });
         saveAs(blob, "download.csv");
    }


function SaveCSV(filename, txt)
    {
         var blob = new Blob([txt], {
            type: "csv/plain;charset=utf-8",
         });
         saveAs(blob, filename);
    }


function SaveXLS(filename, sheetname, buff)
{
 let recordNames = Object.keys(buff[0]);
 
 console.log(recordNames, recordNames.length);

 const dynamicData = [];
 const cols = recordNames.length;
 const rows = buff.length;
 
 for (let i = 0; i <=rows; i++)
   {
    const row = [];  
    for (let j = 0; j < cols; j++)
         {
          if (i==0) row.push(recordNames[j]);     // Write Header            
          else
            {
//           console.log(buff[i][recordNames[j]]);
             row.push(buff[i-1][recordNames[j]]);
            }
         }
    dynamicData.push(row);
   }
// console.log(dynamicData);

 const workbook = XLSX.utils.book_new();
 var worksheet = XLSX.utils.aoa_to_sheet(dynamicData);

 // Apply bold style to the headers
    const boldStyle = { font: { bold: true } };
    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let C = range.s.c; C <= range.e.c; ++C) {
      const cell = worksheet[XLSX.utils.encode_cell({ r: 0, c: C })];
      if (cell) {
        cell.s = boldStyle;
      }
    }

 XLSX.utils.book_append_sheet(workbook, worksheet, sheetname);
 XLSX.writeFile(workbook, filename); 
}

/*
function SaveXLS(filename, sheetname, buff)
{
 let recordNames = Object.keys(buff[0]);
 
 console.log(recordNames, recordNames.length);

 const dynamicData = [];
 const cols = recordNames.length;
 const rows = buff.length;
 
 for (let i = 0; i <=rows; i++)
   {
    const rowdat = [];  
    for (let j = 0; j < cols; j++)
         {
          if (i==0) rowdat.push(recordNames[j]);     // Write Header            
          else
            {
//           console.log(buff[i][recordNames[j]]);
             rowdat.push(buff[i-1][recordNames[j]]);
            }
         }
    dynamicData.push(rowdat);
   }
// console.log(dynamicData);

const workbook = new XLSX.Workbook();
const worksheet = workbook.addWorksheet(sheetname);   

dynamicData.forEach((row, index) => {
      const rowData = worksheet.addRow(row);
      if (index === 0) {
        // Apply bold style to the headers
        rowData.eachCell((cell) => {
          cell.font = { bold: true };
        });
      }
    });

    // Export the workbook to a file
    workbook.xlsx.writeBuffer().then((dynamicData) => {
      const blob = new Blob([dynamicData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'table_with_bold_headers.xlsx';
      a.click();
      window.URL.revokeObjectURL(url);
    }).catch((error) => {
      console.error('Error saving file:', error);
    });
}
*/

/*

let bufferArray = [
  { name: 'Element1', value: 10 },
  { name: 'Element2', value: 20 },
  { name: 'Element3', value: 30 }
];

// Extract the property names from the first record
let recordNames = Object.keys(bufferArray[0]);

console.log(recordNames); // Output: ["name", "value"]
*/

/*
function dbProcess(subroutine)
{
 if (statedb==kIDLE) statedb=kSTART;
 else if (statedb==kSTART)
    {
     tagProcess();
     statedb=kPROCESS;
     timeoutdb=0;
    }
 else if (statedb==kPROCESS)
    {
     if (subroutine())
         {
          statedb=kIDLE;
          return(true)
         }
     else
         {
          timeoutdb++;
          if (timeoutdb>=100) statedb=kSTART;
         }
    }
 return(false);
}



function dbProcessParam(subroutine, param)
{
 if (statedb==kIDLE) statedb=kSTART;
 else if (statedb==kSTART)
    {
     tagProcess();
     statedb=kPROCESS;
     timeoutdb=0;
    }
 else if (statedb==kPROCESS)
    {
     if (subroutine(param))
         {
          statedb=kIDLE;
          return(true)
         }
     else
         {
          timeoutdb++;
          if (timeoutdb>=100) statedb=kSTART;
         }
    }
 return(false);
}
*/

function dbProcessParam3(subroutine, param1, param2, param3, param4, param5)
{
 var stat=false;

 if (statedb==kIDLE) statedb=kSTART;
 else if (statedb==kSTART)
    {
     tagProcess();
     statedb=kPROCESS;
     timeoutdb=0;
    }
 else if (statedb==kPROCESS)
    {
     if ((param2==null)&&(param3==null)&&(param4==null)&&(param5==null))
        {
         if (subroutine(param1)) stat=true;
        }
     else if ((param3==null)&&(param4==null)&&(param5==null))
        {
         if (subroutine(param1, param2)) stat=true;
        }
     else if ((param4==null)&&(param5==null))
        {
         if (subroutine(param1, param2, param3)) stat=true;
        }
     else if (param5==null)
        {
          if (subroutine(param1, param2, param3, param4)) stat=true;
        }
     else if (subroutine(param1, param2, param3, param4, param5)) stat=true;

     if (stat)   
         {
          statedb=kIDLE;
          return(true)
         }
     else
         {
          timeoutdb++;
          if (timeoutdb>=400) statedb=kSTART;
         }
    }
 return(false);
}


/*
const kOffSetYear=2000;
const kTblMonthLunar= 31,29,31,30,31,30,31,31,30,31,30,31;
const kTblMonth[]=[31,28,31,30,31,30,31,31,30,31,30,31];


function DatetimetoStr(value)
{
 var sec, min, hour, day, month, year;
 var temp;

 sec=value % 60;
 value=value/60;
 min=value % 60;
 value=value/60;
 hour=value % 24;
 value=value/24;

 year=kOffSetYear;
 while(1)
    {
     if (CheckLunar(year)) temp=366;
     else temp=365;
     if (value<temp) break;
     else
        {
         year++;
         value-=temp;
        }
    }
 month=0;
 while(1)
    {
     if (CheckLunar(year)) temp=kTblMonthLunar[month];
     else temp=kTblMonth[month];
     if (value<temp) break;
     else
        {
         value-=temp;
         month++;
        }
    }
 month++;
 day=value+1;
 if (month<10) month='0'+month;
 if (hour<10) hour='0'+hour;
 if (min<10) min='0'+min;
 if (sec<10) sec='0'+sec;
 return(year+'/'+month+'/'+day+' '+hour+':'+min+':'+sec);
}
*/
