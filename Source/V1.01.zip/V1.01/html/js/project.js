
const kMainILDE=0;
const kMaxDev=256;
const kMaxPlayer=12;

var firstInit=false;
var devlist=[];
var devtime=[];
var ticklast;
var timeout=0;
let debug=false;
let tick=0;
let macaddr=null;
let ipaddr=null;
let latitude=null;
let longitude=null;
let altitude=null;
let speed=null;
let gpstime=null;
let ticktcp=null;
let cputemp=0;
let cpuload=0;
let cpumem=0;
let webtick;
let comcyc;
let cpucyc;
let digitalin=0;
let digitalout=0;
let adc0;
let adc1;
let adc2;
let adc3;
let adc4;
let adc5;

let input0;
let input1;
let output0;
let output1;
let scale0;
let scale1;
let scale2;

let iddev=null;
let localServer=false;


const isLocalNetwork = (
  ['localhost', '127.0.0.1', '', '::1'].includes(window.location.hostname) ||
  window.location.hostname.startsWith('192.168.') ||
  window.location.hostname.startsWith('10.') ||
  window.location.hostname.endsWith('.local')
);



function InitProject(devid)
{
 var n;

 if (devid!=null)
    {
     iddev=devid;
     console.log("iddev:"+iddev);
    }

 if (firstInit==false)
    {
     for (n=0; n<kMaxDev; n++) CreateVarRDObj('devlist'+n, 0, 0 , false);
     for (n=0; n<kMaxDev; n++) CreateVarRDObj('devtime'+n, 0, 0 , false); 
     firstInit=true;
     localServer=isLocalNetwork;
     if (localServer) CycleReadCache=3;
     else CycleReadCache=10;
     if (localServer) console.log("Server Local !!!", CycleReadCache);
     else console.log("Server Internet !!!", CycleReadCache);
    }
 CreateVarRDObj('timestamp', null, false);
 if (iddev!=null)
    {
     CreateVarRDObj('macaddr@'+iddev, null, false);
     CreateVarRDObj('ipaddr@'+iddev, null, false);
     CreateVarRDObj('latitude@'+iddev, null, false);
     CreateVarRDObj('longitude@'+iddev, null, false);
     CreateVarRDObj('altitude@'+iddev, null, false);
     CreateVarRDObj('speed@'+iddev, null, false);
     CreateVarRDObj('gpstime@'+iddev, null, false);
     CreateVarRDObj('cputemp@'+iddev, null, false);
     CreateVarRDObj('cpumem@'+iddev, null, false);
     CreateVarRDObj('cpuload@'+iddev, null, false);
     CreateVarRDObj('comcyc@'+iddev, null, false);
     CreateVarRDObj('cpucyc@'+iddev, null, false);
     CreateVarRDObj('digitalin@'+iddev, null, false);
     CreateVarRDObj('digitalout@'+iddev, null, false);
     CreateVarRDObj('adc0@'+iddev, null, false);
     CreateVarRDObj('adc1@'+iddev, null, false);
     CreateVarRDObj('adc2@'+iddev, null, false);
     CreateVarRDObj('adc3@'+iddev, null, false);
     CreateVarRDObj('adc4@'+iddev, null, false);
     CreateVarRDObj('adc5@'+iddev, null, false);
   }
}


function VarProject()
{
 var n;
 var temp;

 if (firstStart<kBOOT_READ_CACHE) return;
 if (firstStart==kBOOT_READ_CACHE) firstStart=kBOOT_RDY;
 if (tickCACHE)
     {
      //console.log("here1....", iddev);      
      macaddr=GetValVarRDObj('macaddr@'+iddev);
      ipaddr=GetValVarRDObj('ipaddr@'+iddev);
      latitude=GetValVarRDObj('latitude@'+iddev);
      longitude=GetValVarRDObj('longitude@'+iddev);
      altitude=GetValVarRDObj('altitude@'+iddev);
      speed=GetValVarRDObj('speed@'+iddev);
      gpstime=GetValVarRDObj('gpstime@'+iddev);
      tick=GetValVarRDObj('tick@'+iddev);
      webtick=GetValVarRDObj('webtick');
      cputemp=GetValVarRDObj('cputemp@'+iddev);
      cpuload=GetValVarRDObj('cpuload@'+iddev);
      cpumem=GetValVarRDObj('cpumem@'+iddev);
      digitalin=GetValVarRDObj('digitalin@'+iddev);
      digitalout=GetValVarRDObj('digitalout@'+iddev);
      comcyc=GetValVarRDObj('comcyc@'+iddev);
      cpucyc=GetValVarRDObj('cpucyc@'+iddev);
      adc0=GetValVarRDObj('adc0@'+iddev);
      adc1=GetValVarRDObj('adc1@'+iddev);
      adc2=GetValVarRDObj('adc2@'+iddev);
      adc3=GetValVarRDObj('adc3@'+iddev);
      adc4=GetValVarRDObj('adc4@'+iddev);
      adc5=GetValVarRDObj('adc5@'+iddev);
      if (tickCACHEInit==false)
         {
          tickCACHEInit=true;
         }         
//      console.log('macaddr: '+macaddr);
     }
 if (tick1S)
    {
      //console.log(input0, input1, output0, output1, scale0, scale1, scale2);
      devlist=[];
      for (n=0; n<kMaxDev; n++)
          {
           var temp=GetValVarRDObj('devlist'+n);
           //console.log('devlist'+n);
           var tmtemp=GetValVarRDObj('devtime'+n);
           if ((temp)&&(tmtemp)) devlist.push({MAC:temp, TIME:tmtemp});
          }
      if (iddev==null)
          {
           if (devlist) InitProject(devlist[0].MAC);
           console.log(devlist); //, GetTimestamp(),timestamp);
          }
    }
}



function GetTimestamp()
{
 return(GetValVarRDObj('timestamp'));
}