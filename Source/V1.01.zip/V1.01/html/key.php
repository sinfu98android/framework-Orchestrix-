<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>
<body style="background-color:gray;">
        <!-- <input type="file" id="excel_file"  style="display:none"/>  -->
<!--        <input type='file' accept='text/plain' onchange='openFile(event)'>   -->

</body>
</html>

<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>


<script type="text/javascript">

const kGetID=0;

const kCharTextPtr='|';

let Capslock=false;
let keyCode=null;
let keyboard='';
let keyboardType;
let keyboardID;
let keyboardval=0;
let statekey=0;
let keyid=0;
let type;
let vtype;
let field;
let server;
let dbase;
let user;
let pass;
let table;
let quitkeyboard=false;
let temp, cnt;
//let WRCACHEKEYID, WRCACHEKEYVAL;
let entertimeout=0;
let posting='';


window.onload = function () {
      Init();
      setTimeout(function()
            {
              if (keyboardType=='NUM') SetNumericKeyboard();
              else if (keyboardType=='TXT') SetTXTKeyboard();
              else if (keyboardType=='PWD') SetTXTKeyboard();
            }
        ,500);
   }

setInterval(Process, kTimeBase);    


function Init()
   {
    var OffX, OffY;
    var color;

    InitHMI();
    keySizeX=7.65; //(window.innerWidth-6)/13;
    keySizeY=16; //(window.innerHeight-4)/6;
    OffX=0.25;
    OffY=19;    //keySizeY;
    colorpress='image/green_on.png';
    colorrelease='image/green_off.png';

    type=urlParams.get('type');
    keyboard=urlParams.get('val');
    keyid=urlParams.get('vid');
    vtype=urlParams.get('vtype');
    field=urlParams.get('vfield');
    table=urlParams.get('vtable');
    server=urlParams.get('vserver');
    dbase=urlParams.get('vdbase');
    user=urlParams.get('vuser');
    pass=urlParams.get('vpassword');

    //console.log(type, keyboard, keyid, vtype, table, field, server, dbase, user, pass);
    if (type)
        {
         keyboardType=type;
        }
    CreateLabelNew('lstatus', 1, 0, 50, 4,   3, "Arial", "wait..", "white", "transparent",2,"px", null, "TXT", "left", kVarNONE, null, null, null, 'absolute');        
    CreateLabelNew('lstatus2', 50, 0, 49, 4,   3, "Arial", "", "white", "transparent",2,"px", null, "TXT", "left", kVarNONE, null, null, null, 'absolute');
    if (type=="PWD") CreateLabelNew(field, 0.5, 4, 98.5, 13, 12.5,"Arial", keyboard, "blue", "white",3,"px solid black", null, "PWD", "left", kVarNONE, table, keyid, field, 'absolute');
    else CreateLabelNew(field, 0.5, 4, 98.5, 13, 12.5,"Arial", keyboard+kCharTextPtr, "blue", "white",3,"px solid black", null, "TXT", "left", kVarNONE, table, keyid, field, 'absolute');
    
    CreateButtonNew("key1", OffX+(keySizeX*0), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "1", "1", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key2", OffX+(keySizeX*1), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "2", "2", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key3", OffX+(keySizeX*2), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "3", "3", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("key4", OffX+(keySizeX*3), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "4", "4", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key5", OffX+(keySizeX*4), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "5", "5", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key6", OffX+(keySizeX*5), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "6", "6", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key7", OffX+(keySizeX*6), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "7", "7", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("key8", OffX+(keySizeX*7), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "8", "8", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key9", OffX+(keySizeX*8), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "9", "9", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key0", OffX+(keySizeX*9), OffY, keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "0", "0", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("kBack", OffX+(keySizeX*10), OffY, keySizeX*3, keySizeY,
                    colorpress, colorrelease,
                    "BackSpace", "BackSpace", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');

    CreateButtonNew("k`", OffX+(keySizeX*0), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "`", "`", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyQ", OffX+(keySizeX*1), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "Q", "Q", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyW", OffX+(keySizeX*2), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "W", "W", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyE", OffX+(keySizeX*3), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "E", "E", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyR", OffX+(keySizeX*4), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "R", "R", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyT", OffX+(keySizeX*5), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "T", "T", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyY", OffX+(keySizeX*6), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "Y", "Y", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyU", OffX+(keySizeX*7), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "U", "U", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyI", OffX+(keySizeX*8), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "I", "I", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyO", OffX+(keySizeX*9), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "O", "O", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyP", OffX+(keySizeX*10), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "P", "P", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key[", OffX+(keySizeX*11), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "[", "[", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key]", OffX+(keySizeX*12), OffY+(keySizeY*1), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "]", "]", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');

    CreateButtonNew("kEsc", OffX+(keySizeX*0), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "Esc", "Esc", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyA", OffX+(keySizeX*1), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "A", "A", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyS", OffX+(keySizeX*2), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "S", "S", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyD", OffX+(keySizeX*3), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "D", "D", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyF", OffX+(keySizeX*4), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "F", "F", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyG", OffX+(keySizeX*5), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "G", "G", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyH", OffX+(keySizeX*6), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "H", "H", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyJ", OffX+(keySizeX*7), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "J", "J", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyK", OffX+(keySizeX*8), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "K", "K", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyL", OffX+(keySizeX*9), OffY+(keySizeY*2), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "L", "L", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyEnt", OffX+(keySizeX*10), OffY+(keySizeY*2), keySizeX*3, keySizeY,
                    colorpress, colorrelease,
                    "ENT", "ENT", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');


    CreateButtonNew("kCaps", OffX+(keySizeX*0), OffY+(keySizeY*3), keySizeX*2, keySizeY,
                    colorpress, colorrelease,
                    "Caps", "Caps", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyZ", OffX+(keySizeX*2), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "Z", "Z", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyX", OffX+(keySizeX*3), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "X", "X", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyC", OffX+(keySizeX*4), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "C", "C", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyV", OffX+(keySizeX*5), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "V", "V", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyB", OffX+(keySizeX*6), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "B", "B", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keyN", OffX+(keySizeX*7), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "N", "N", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("keyM", OffX+(keySizeX*8), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "M", "M", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key,", OffX+(keySizeX*9), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    ",", ",", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key.", OffX+(keySizeX*10), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    ".", ".", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key/", OffX+(keySizeX*11), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "/", "/", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key\\", OffX+(keySizeX*12), OffY+(keySizeY*3), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "\\", "\\", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');

    CreateButtonNew("kClr", OffX+(keySizeX*0), OffY+(keySizeY*4), keySizeX*2, keySizeY,
                    colorpress, colorrelease,
                    "Clear", "Clear", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("keySpace", OffX+(keySizeX*2), OffY+(keySizeY*4), keySizeX*8, keySizeY,
                    colorpress, colorrelease,
                    "Space", "Space", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key+", OffX+(keySizeX*10), OffY+(keySizeY*4), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "+", "+", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   CreateButtonNew("key-", OffX+(keySizeX*11), OffY+(keySizeY*4), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "-", "-", 5,"Arial", 
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
    CreateButtonNew("key*", OffX+(keySizeX*12), OffY+(keySizeY*4), keySizeX, keySizeY,
                    colorpress, colorrelease,
                    "*", "*", 5,"Arial",
                    "PressButton(this.id)",  "ReleaseButton(this.id)",
                    "red", "white", null, 'absolute');
   }

 
function SetNumericKeyboard()
   {
    var n;
   
    for (n=0; n<hmiobj.length; n++)
      {
       if (hmiobj[n].OBJECT=='button')
         {
          hmiobj[n].ENABLE=false;
         }
      }
    for (n=0; n<hmiobj.length; n++)
      {
       if (hmiobj[n].OBJECT=='button')
         {
          if (hmiobj[n].ID=='key1') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key2') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key3') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key4') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key5') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key6') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key7') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key8') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key9') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key0') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='key.') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='kEsc') hmiobj[n].ENABLE=true;
          if (hmiobj[n].ID=='keyEnt') hmiobj[n].ENABLE=true; 
          if (hmiobj[n].ID=='kBack') hmiobj[n].ENABLE=true; 
          if (hmiobj[n].ID=='kClr') hmiobj[n].ENABLE=true; 
          hmiobj[n].REFRESH=true;
         }
      }
   }


function SetTXTKeyboard()
   {
    var n;
   
    for (n=0; n<hmiobj.length; n++)
      {
       if (hmiobj[n].OBJECT=='button')
         {
          hmiobj[n].ENABLE=true;
          hmiobj[n].REFRESH=true;
         }
      }       
   }


function SetMemcacheKey()
    {
     var buff=new Array();
     var names=[];
     var values=[];
     var total;
     var tagid;
     var n, m;
     var i=0;
     var j=0;


     if (WRCACHEKEYstate==kWRCACHEKEYSTART)
        {
         WRCACHEKEYstate=kWRCACHEKEYRUN;
         posting='posting...'
         entertimeout=0;
         CacheRDY=false;
         console.log('POSTING...');
        }
     else if (WRCACHEKEYstate==kWRCACHEKEYRUN)
        {
         //UpdateLabel('lstatus2', 'Posting....');
         console.log('ENTERING 1');
         i=0;
         j=0;
         buff=[];
         tagid='wr'+WRCACHEKEYID;
         names[i]='tag';            values[i++]=tagid;         
         names[i]='wrmulti';        values[i++]='1';
         names[i]='id'+j;           values[i++]=WRCACHEKEYID;         names[i]='val'+j++;         values[i++]=WRCACHEKEYVAL;    
         names[i]='id'+j;           values[i++]=WRCACHEKEYID+'_';     names[i]='val'+j++;         values[i++]=WRCACHEKEYVAL; 
         names[i]='total';          values[i++]=j;
         buff=getpostXTOut('memcache.php', names, values, 250);
         if (buff[0]==values[0])
             {
              quitkeyboard=true;
              WRCACHEKEYstate=kWRCACHEKEYIDLE;
              posting='posting success'
//              console.log('ENTERING 2');
              UpdateLabel('lstatus2', 'Success!!!');
              //submit(document.referrer, '', '');
              CacheRDY=true;
             }
         else
             {
//              console.log('timeout: '+entertimeout);
              entertimeout++;
              if (entertimeout>=kTimeOutServer)
                 {
                  message="Server No Respone !!!";
                  posting='posting failed!!!'
                  WRCACHEKEYstate=kWRCACHEKEYIDLE;
                  CacheRDY=true;
                 }
            }
        } 
    }




function SetDBASEKey()
{
  var names=[];
  var values=[];
  var buff=new Array();
  var i, j, n, m;
  var TotField=0;
  var value;

  if (WRDBASEKEYstate==kWRDBASEKEYSTART)
     {
      WRDBASEKEYstate=kWRDBASEKEYRUN;
     } 
  else if (WRDBASEKEYstate==kWRDBASEKEYRUN)
      {   
          buff=[];
          i=0;
          j=0;
          names[i]='tag';          values[i++]='setdata';
          names[i]='tablex';       values[i++]=table;
          names[i]='serverx';      values[i++]=server;
          names[i]='dbasex';       values[i++]=dbase;
          names[i]='userx';        values[i++]=user;  
          names[i]='passx';        values[i++]=pass;  
          names[i]='updatex';      values[i++]='1';
          names[i]='cond';         values[i++]='id';
          names[i]='vcond';        values[i++]=keyid;
          names[i]='field'+j;      values[i++]=field;       names[i]='val'+j++;       values[i++]='\''+WRCACHEKEYVAL+'\'';          
          names[i]='total';        values[i++]=j;
          TotField=parseInt(j);
          //console.log('save', server, table, dbase, user, pass, field,WRCACHEKEYVAL);
          buff=getpostX('mysqlproc.php', names, values);
          if (buff[0]==values[0])
               {
                //console.log('save', server, table, dbase, user, pass, field,WRCACHEKEYVAL);
                WRDBASEKEYstate=kWRDBASEKEYIDLE;
                quitkeyboard=true;
               } 
       }
}
 
 var testing=0;

 function main()
      {
       var m, n=0;
       var refresh=false;

       if (tick1S) updatestatus();
//       HMIServices();
//       SystemTick();
       if (KeyBoardEdgePress)
            {
//             UpdateLabel('lstatus2', KeyChar);
             if (KeyChar=='Backspace')            // BackSpace
                {
                 keyboard=keyboard.slice(0, keyboard.length-1);
                }
             else if (KeyChar=='Escape')
                {
                 submit(document.referrer, '', '');
                }
             else if (KeyChar=='Shift');
             else if (KeyChar=='CapsLock');
             else if (KeyChar=='Tab');
             else if (KeyChar=='Alt');
             else if (KeyChar=='ArrowUp');
             else if (KeyChar=='ArrowDown');
             else if (KeyChar=='ArrowLeft');
             else if (KeyChar=='ArrowRight');
             else if (KeyChar=='Insert');
             else if (KeyChar=='PageUp');
             else if (KeyChar=='PageDown');
             else if (KeyChar=='NumLock');
             else if (KeyChar=='Home');
             else if (KeyChar=='End');
             else if (KeyChar=='F1');
             else if (KeyChar=='F2');
             else if (KeyChar=='F3');
             else if (KeyChar=='F4');
             else if (KeyChar=='F5');
             else if (KeyChar=='F6');
             else if (KeyChar=='F7');
             else if (KeyChar=='F8');
             else if (KeyChar=='F9');
             else if (KeyChar=='F10');
             else if (KeyChar=='F11');
             else if (KeyChar=='F12');
             else if (KeyChar=='Control');
             else if (KeyChar=='Delete')
                {
                 keyboard='';
                 refresh=true;
                }
             else if (KeyChar=='Enter')
                {
                 //UpdateLabel('lstatus2', 'ENTER....');
                 m=GetID(field);
                 if (vtype==kVarDBASE)
                     {
                      //hmiobj[m].TEXT=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                      WRDBASEKEYstate=kWRDBASEKEYSTART;
                      WRCACHEKEYID=hmiobj[m].ID;
                      WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                     }
                 else if (vtype==kVarCACHE)
                     {
                      //hmiobj[m].TEXT=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                      WRCACHEKEYstate=kWRCACHEKEYSTART;
                      WRCACHEKEYID=hmiobj[m].ID;
                      WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                      //BuffWRCACHE.push({ID:hmiobj[m].ID, VALUE:hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1)});
                      //console.log(BuffWRCACHE);
                     }
                 else if (vtype==kVarLOCAL)
                     {
                      //hmiobj[m].TEXT=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                      //WRCACHEKEYstate=kWRCACHEKEYSTART;
                      if (type=="PWD") localStorage.setItem(hmiobj[m].ID,hmiobj[m].TEXT);
                      else localStorage.setItem(hmiobj[m].ID,hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1));
                      quitkeyboard=true;
                      //WRCACHEKEYID=hmiobj[m].ID;
                      //WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                      //BuffWRCACHE.push({ID:hmiobj[m].ID, VALUE:hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1)});
                      //console.log(BuffWRCACHE);
                     }                
                }
             else keyboard+=KeyChar;
             refresh=true;
            }
       for (n=0; n<hmiobj.length; n++)
            {
             if (hmiobj[n].OBJECT=='button')
                  {
                   if (hmiobj[n].EDGEPRESS)
                        {
                         //UpdateLabel('lstatus2', testing++);
                         console.log('keypress', hmiobj[n].ID);
                         if (hmiobj[n].ID=='kClr')
                              {
                               keyboard='';
                               refresh=true;
                              }
                         else if (hmiobj[n].ID=='keySpace')
                              {
                               keyboard+=' ';
                               refresh=true;
                              }
                         else if (hmiobj[n].ID=='kEsc')
                              {
                                submit(document.referrer, '', '');
                              }
                         else if (hmiobj[n].ID=='kCaps')
                              {
                               if (Capslock) Capslock=false; 
                               else Capslock=true;                                
                              }       
                         else if (hmiobj[n].ID=='keyEnt')
                              {
                               m=GetID(field);
                               if (vtype==kVarDBASE)
                                    {
                                     if (WRDBASEKEYstate==kWRCACHEKEYIDLE)
                                        {
                                         //hmiobj[m].TEXT=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                                         WRDBASEKEYstate=kWRDBASEKEYSTART;
                                         WRCACHEKEYID=hmiobj[m].ID;
                                         WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                                        }
                                   }
                               else if (vtype==kVarCACHE)
                                    {
                                      if (WRCACHEKEYstate==kIDLE)
                                         {
                                          WRCACHEKEYstate=kWRCACHEKEYSTART;
                                          WRCACHEKEYID=hmiobj[m].ID;
                                          WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                                          }
                                     //hmiobj[m].TEXT=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                                     //WRCACHEKEYstate=kWRCACHEKEYSTART;
                                     //WRCACHEKEYID=hmiobj[m].ID;
                                     //WRCACHEKEYVAL=hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1);
                                    }
                               else if (vtype==kVarLOCAL)
                                    {
                                     quitkeyboard=true;
                                     if (type=="PWD") localStorage.setItem(hmiobj[m].ID,hmiobj[m].TEXT);
                                     else localStorage.setItem(hmiobj[m].ID,hmiobj[m].TEXT.slice(0, hmiobj[m].TEXT.length-1));
                                    }                                    
                               refresh=true;
                              }
                         else if (hmiobj[n].ID=='kBack')
                              {
                               if (keyboard.length)
                                 {
                                  keyboard=keyboard.slice(0, keyboard.length-1);
                                  refresh=true;
                                 }                                 
                              }                              
                         else
                              {
                               keyCode=hmiobj[n].TEXTRELEASE;
                               keyboard+=keyCode;
                               refresh=true;
                              }
                        }
                  }
            }
       if (refresh)
            {
             n=GetID(field);
             if (type=="PWD") hmiobj[n].TEXT=keyboard;
             else hmiobj[n].TEXT=keyboard+kCharTextPtr;
             hmiobj[n].REFRESH=true;
//             console.log(keyboard);             
             refresh=false;
            }

       SetMemcacheKey();
       SetDBASEKey();

       if (quitkeyboard)
            {
             quitkeyboard=false;
             submit(document.referrer, '', '');
            }

       if (KeyPress("kCaps"))
            {
             if (Capslock)
                  {
                   n=GetID('keyA');
                   hmiobj[n].TEXTRELEASE='a';
                   hmiobj[n].TEXTPRESS='a';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyB');
                   hmiobj[n].TEXTRELEASE='b';
                   hmiobj[n].TEXTPRESS='b';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyC');
                   hmiobj[n].TEXTRELEASE='c';
                   hmiobj[n].TEXTPRESS='c';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyD');
                   hmiobj[n].TEXTRELEASE='d';
                   hmiobj[n].TEXTPRESS='d';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyE');
                   hmiobj[n].TEXTRELEASE='e';
                   hmiobj[n].TEXTPRESS='e';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyF');
                   hmiobj[n].TEXTRELEASE='f';
                   hmiobj[n].TEXTPRESS='f';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyG');
                   hmiobj[n].TEXTRELEASE='g';
                   hmiobj[n].TEXTPRESS='g';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyH');
                   hmiobj[n].TEXTRELEASE='h';
                   hmiobj[n].TEXTPRESS='h';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyI');
                   hmiobj[n].TEXTRELEASE='i';
                   hmiobj[n].TEXTPRESS='i';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyJ');
                   hmiobj[n].TEXTRELEASE='j';
                   hmiobj[n].TEXTPRESS='j';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyK');
                   hmiobj[n].TEXTRELEASE='k';
                   hmiobj[n].TEXTPRESS='k';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyL');
                   hmiobj[n].TEXTRELEASE='l';
                   hmiobj[n].TEXTPRESS='l';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyM');
                   hmiobj[n].TEXTRELEASE='m';
                   hmiobj[n].TEXTPRESS='m';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyN');
                   hmiobj[n].TEXTRELEASE='n';
                   hmiobj[n].TEXTPRESS='n';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyO');
                   hmiobj[n].TEXTRELEASE='o';
                   hmiobj[n].TEXTPRESS='o';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyP');
                   hmiobj[n].TEXTRELEASE='p';
                   hmiobj[n].TEXTPRESS='p';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyQ');
                   hmiobj[n].TEXTRELEASE='q';
                   hmiobj[n].TEXTPRESS='q';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyR');
                   hmiobj[n].TEXTRELEASE='r';
                   hmiobj[n].TEXTPRESS='r';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyS');
                   hmiobj[n].TEXTRELEASE='s';
                   hmiobj[n].TEXTPRESS='s';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyT');
                   hmiobj[n].TEXTRELEASE='t';
                   hmiobj[n].TEXTPRESS='t';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyU');
                   hmiobj[n].TEXTRELEASE='u';
                   hmiobj[n].TEXTPRESS='u';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyV');
                   hmiobj[n].TEXTRELEASE='v';
                   hmiobj[n].TEXTPRESS='v';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyW');
                   hmiobj[n].TEXTRELEASE='w';
                   hmiobj[n].TEXTPRESS='w';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyX');
                   hmiobj[n].TEXTRELEASE='x';
                   hmiobj[n].TEXTPRESS='x';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyY');
                   hmiobj[n].TEXTRELEASE='y';
                   hmiobj[n].TEXTPRESS='y';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyZ');
                   hmiobj[n].TEXTRELEASE='z';
                   hmiobj[n].TEXTPRESS='z';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key-');
                   hmiobj[n].TEXTRELEASE='_';
                   hmiobj[n].TEXTPRESS='_';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key[');
                   hmiobj[n].TEXTRELEASE='{';
                   hmiobj[n].TEXTPRESS='{';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key]');
                   hmiobj[n].TEXTRELEASE='}';
                   hmiobj[n].TEXTPRESS='}';
                   hmiobj[n].REFRESH=true;
                   n=GetID('k`');
                   hmiobj[n].TEXTRELEASE='~';
                   hmiobj[n].TEXTPRESS='~';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key+');
                   hmiobj[n].TEXTRELEASE='=';
                   hmiobj[n].TEXTPRESS='=';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key,');
                   hmiobj[n].TEXTRELEASE=':';
                   hmiobj[n].TEXTPRESS=':';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key.');
                   hmiobj[n].TEXTRELEASE=';';
                   hmiobj[n].TEXTPRESS=';';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyX');
                   hmiobj[n].TEXTRELEASE='x';
                   hmiobj[n].TEXTPRESS='x';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyY');
                   hmiobj[n].TEXTRELEASE='y';
                   hmiobj[n].TEXTPRESS='y';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyZ');
                   hmiobj[n].TEXTRELEASE='z';
                   hmiobj[n].TEXTPRESS='z';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key-');
                   hmiobj[n].TEXTRELEASE='_';
                   hmiobj[n].TEXTPRESS='_';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key[');
                   hmiobj[n].TEXTRELEASE='(';
                   hmiobj[n].TEXTPRESS='(';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key]');
                   hmiobj[n].TEXTRELEASE=')';
                   hmiobj[n].TEXTPRESS=')';
                   hmiobj[n].REFRESH=true;
                   n=GetID('k`');
                   hmiobj[n].TEXTRELEASE='~';
                   hmiobj[n].TEXTPRESS='~';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key+');
                   hmiobj[n].TEXTRELEASE='=';
                   hmiobj[n].TEXTPRESS='=';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key,');
                   hmiobj[n].TEXTRELEASE=':';
                   hmiobj[n].TEXTPRESS=':';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key.');
                   hmiobj[n].TEXTRELEASE=';';
                   hmiobj[n].TEXTPRESS=';';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key1');
                   hmiobj[n].TEXTRELEASE='!';
                   hmiobj[n].TEXTPRESS='!';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key2');
                   hmiobj[n].TEXTRELEASE='@';
                   hmiobj[n].TEXTPRESS='@';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key3');
                   hmiobj[n].TEXTRELEASE='#';
                   hmiobj[n].TEXTPRESS='#';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key4');
                   hmiobj[n].TEXTRELEASE='$';
                   hmiobj[n].TEXTPRESS='$';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key5');
                   hmiobj[n].TEXTRELEASE='%';
                   hmiobj[n].TEXTPRESS='%';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key6');
                   hmiobj[n].TEXTRELEASE='^';
                   hmiobj[n].TEXTPRESS='^';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key7');
                   hmiobj[n].TEXTRELEASE='&';
                   hmiobj[n].TEXTPRESS='&';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key8');
                   hmiobj[n].TEXTRELEASE='*';
                   hmiobj[n].TEXTPRESS='*';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key9');
                   hmiobj[n].TEXTRELEASE='(';
                   hmiobj[n].TEXTPRESS='(';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key0');
                   hmiobj[n].TEXTRELEASE=')';
                   hmiobj[n].TEXTPRESS=')';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key/');
                   hmiobj[n].TEXTRELEASE='?';
                   hmiobj[n].TEXTPRESS='?';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key\\');
                   hmiobj[n].TEXTRELEASE='|';
                   hmiobj[n].TEXTPRESS='|';
                   hmiobj[n].REFRESH=true;                   
                  } 
             else
                  {
                   n=GetID('keyA');
                   hmiobj[n].TEXTRELEASE='A';
                   hmiobj[n].TEXTPRESS='A';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyB');
                   hmiobj[n].TEXTRELEASE='B';
                   hmiobj[n].TEXTPRESS='B';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyC');
                   hmiobj[n].TEXTRELEASE='C';
                   hmiobj[n].TEXTPRESS='C';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyD');
                   hmiobj[n].TEXTRELEASE='D';
                   hmiobj[n].TEXTPRESS='D';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyE');
                   hmiobj[n].TEXTRELEASE='E';
                   hmiobj[n].TEXTPRESS='E';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyF');
                   hmiobj[n].TEXTRELEASE='F';
                   hmiobj[n].TEXTPRESS='F';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyG');
                   hmiobj[n].TEXTRELEASE='G';
                   hmiobj[n].TEXTPRESS='G';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyH');
                   hmiobj[n].TEXTRELEASE='H';
                   hmiobj[n].TEXTPRESS='H';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyI');
                   hmiobj[n].TEXTRELEASE='I';
                   hmiobj[n].TEXTPRESS='I';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyJ');
                   hmiobj[n].TEXTRELEASE='J';
                   hmiobj[n].TEXTPRESS='J';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyK');
                   hmiobj[n].TEXTRELEASE='K';
                   hmiobj[n].TEXTPRESS='K';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyL');
                   hmiobj[n].TEXTRELEASE='L';
                   hmiobj[n].TEXTPRESS='L';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyM');
                   hmiobj[n].TEXTRELEASE='M';
                   hmiobj[n].TEXTPRESS='M';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyN');
                   hmiobj[n].TEXTRELEASE='N';
                   hmiobj[n].TEXTPRESS='N';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyO');
                   hmiobj[n].TEXTRELEASE='O';
                   hmiobj[n].TEXTPRESS='O';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyP');
                   hmiobj[n].TEXTRELEASE='P';
                   hmiobj[n].TEXTPRESS='P';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyQ');
                   hmiobj[n].TEXTRELEASE='Q';
                   hmiobj[n].TEXTPRESS='Q';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyR');
                   hmiobj[n].TEXTRELEASE='R';
                   hmiobj[n].TEXTPRESS='R';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyS');
                   hmiobj[n].TEXTRELEASE='S';
                   hmiobj[n].TEXTPRESS='S';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyT');
                   hmiobj[n].TEXTRELEASE='T';
                   hmiobj[n].TEXTPRESS='T';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyU');
                   hmiobj[n].TEXTRELEASE='U';
                   hmiobj[n].TEXTPRESS='U';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyV');
                   hmiobj[n].TEXTRELEASE='V';
                   hmiobj[n].TEXTPRESS='V';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyW');
                   hmiobj[n].TEXTRELEASE='W';
                   hmiobj[n].TEXTPRESS='W';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyX');
                   hmiobj[n].TEXTRELEASE='X';
                   hmiobj[n].TEXTPRESS='X';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyY');
                   hmiobj[n].TEXTRELEASE='Y';
                   hmiobj[n].TEXTPRESS='Y';
                   hmiobj[n].REFRESH=true;
                   n=GetID('keyZ');
                   hmiobj[n].TEXTRELEASE='Z';
                   hmiobj[n].TEXTPRESS='Z';
                   hmiobj[n].REFRESH=true; 
                   n=GetID('key-');
                   hmiobj[n].TEXTRELEASE='-';
                   hmiobj[n].TEXTPRESS='-';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key[');
                   hmiobj[n].TEXTRELEASE='[';
                   hmiobj[n].TEXTPRESS='[';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key]');
                   hmiobj[n].TEXTRELEASE=']';
                   hmiobj[n].TEXTPRESS=']';
                   hmiobj[n].REFRESH=true;
                   n=GetID('k`');
                   hmiobj[n].TEXTRELEASE='`';
                   hmiobj[n].TEXTPRESS='`';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key+');
                   hmiobj[n].TEXTRELEASE='+';
                   hmiobj[n].TEXTPRESS='+';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key,');
                   hmiobj[n].TEXTRELEASE=',';
                   hmiobj[n].TEXTPRESS=',';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key.');
                   hmiobj[n].TEXTRELEASE='.';
                   hmiobj[n].TEXTPRESS='.';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key1');
                   hmiobj[n].TEXTRELEASE='1';
                   hmiobj[n].TEXTPRESS='1';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key2');
                   hmiobj[n].TEXTRELEASE='2';
                   hmiobj[n].TEXTPRESS='2';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key3');
                   hmiobj[n].TEXTRELEASE='3';
                   hmiobj[n].TEXTPRESS='3';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key4');
                   hmiobj[n].TEXTRELEASE='4';
                   hmiobj[n].TEXTPRESS='4';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key5');
                   hmiobj[n].TEXTRELEASE='5';
                   hmiobj[n].TEXTPRESS='5';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key6');
                   hmiobj[n].TEXTRELEASE='6';
                   hmiobj[n].TEXTPRESS='6';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key7');
                   hmiobj[n].TEXTRELEASE='7';
                   hmiobj[n].TEXTPRESS='7';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key8');
                   hmiobj[n].TEXTRELEASE='8';
                   hmiobj[n].TEXTPRESS='8';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key9');
                   hmiobj[n].TEXTRELEASE='9';
                   hmiobj[n].TEXTPRESS='9';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key0');
                   hmiobj[n].TEXTRELEASE='0';
                   hmiobj[n].TEXTPRESS='0';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key/');
                   hmiobj[n].TEXTRELEASE='/';
                   hmiobj[n].TEXTPRESS='/';
                   hmiobj[n].REFRESH=true;
                   n=GetID('key\\');
                   hmiobj[n].TEXTRELEASE='\\';
                   hmiobj[n].TEXTPRESS='\\';
                   hmiobj[n].REFRESH=true;
                  }
            }
      }

function updatestatus()
{
 n=GetID('lstatus');
 if (n>=0)
    {
     if (connection) hmiobj[n].TEXT='Connected '+parseInt(timeConnection/3600)+':'+zerolead(parseInt(timeConnection/60),2)+':'+zerolead(parseInt(timeConnection % 60),2)+' '+posting;
     else  hmiobj[n].TEXT='Lost !!! '+parseInt(timeConnection/3600)+':'+zerolead(parseInt(timeConnection/60),2)+':'+zerolead(parseInt(timeConnection % 60),2)+' '+posting;
//     hmiobj[n].TEXT+=' timeout '+entertimeout;
//     hmiobj[n].TEXT+=' State:'+WRCACHEKEYstate;
     hmiobj[n].REFRESH=true;
    }    
}

</script>