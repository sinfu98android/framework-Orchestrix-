<?php 
  const kIdleState=0;
  const kFillingState=1;
  const kDischargeState=2;

  //$serverdest='127.0.0.1';
    //'127.0.0.1';

  //$servercache="192.168.0.60";        ///"192.168.0.60";
  $username='remote';
  $password='remote';
  //$dbname='db_loging';
  //$tabledest='plc_logging';
  //$tablesrc='LC5CH_083A8DD3FE8E';
  //$state=kIdleState;
  $filename="/var/www/html/program/logging.txt";
  
 include "server.php";
 include "rtc.php";

    
 GetDatetime();
 echo nl2br($datetime.' '.$datetimes."\n");
 //******************* Open file Logging.txt *************************//
 $file = fopen($filename,"r");
 $bufffile=fread($file, filesize($filename));
 $filesize=filesize($filename);
 fclose($file);
 echo nl2br($bufffile."\n");
 $totalfile=0;
 $parsefile=[];
 $listtable=[];
 for ($i=0; $i<$filesize; $i++)
    {
     if ($bufffile[$i] == "\n")
        {
         if (filesize($parsefile[$totalfile])>0) $totalfile++;
        }
     else if ($bufffile[$i] == "\r");
     else
        {
         $parsefile[$totalfile].=$bufffile[$i];
         if ($i>=($filesize-1))
            {  
             if (filesize($parsefile[$totalfile])>0) $totalfile++;
            }
        }
    }
 echo nl2br('  Total File:'.$totalfile."\n");
 for ($i=0; $i<$totalfile; $i++) echo nl2br($parsefile[$i]."\n");


 for ($k=0; $k<$totalfile; $k++)
    {
     $bufffile=[];
     $filesize=filesize($parsefile[$k]);
     $file = fopen($parsefile[$k],"r");
     $bufffile=fread($file, $filesize);
     fclose($file);
     //echo nl2br($bufffile."\n");

     $server=null;
     $servercache=null;
     $dbname=null;
     $table=null;
     $bufffield=[];
     $totfield=0;
     $stat=false;
     $temp=ParsingParam($bufffile, "[server]");
     if ($temp)
        {
         $server=$temp;
         $temp=ParsingParam($bufffile, "[cache]");
         if ($temp)
            {
             $servercache=$temp;
             $temp=ParsingParam($bufffile, "[dbase]");
             if ($temp)
                {
                 $dbname=$temp;
                 $temp=ParsingParam($bufffile, "[table]");
                 if ($temp)
                    {
                     $table=$temp;
                     for ($i=0; $i<100; $i++)
                        {
                         $temp=ParsingParam($bufffile, "[field".$i."]");
                         if ($temp)
                            {
                             $stat=true;            
                             $bufffield[$totfield++]=$temp;
                            }
                         else break;                     
                        }
                    }             
                }
            }
        }
        
     if ($stat)
        {        
         echo nl2br($servercache.",".$server.",".$dbname.",".$table."\n");
         //for ($i=0; $i<$totfield; $i++) echo nl2br($bufffield[$i]."\n");
         for ($i=0; $i<$totfield; $i++)
            {
             $tot=Split(",", $bufffield[$i]);
             if ($tot==3)
                {
                  $dbasefield[$i]=$split0;
                  $cachefield[$i]=$split1;
                  $typefield[$i]=$split2;
                  echo nl2br($dbasefield[$i].",".$cachefield[$i].",".$typefield[$i]."\n");
                }         
            }

         echo nl2br($server.",".$username.",".$password.",".$dbname.",".$table.",".$dbasefield.",".$typefield.",".$totfield."\n");
//****************** Check Table Analytic Existing, Create when not exist ************************//        
         CheckDatabase($server, $username, $password, $dbname);
         CheckTableDB($server, $username, $password, $dbname, $table, $dbasefield, $typefield, $totfield);
//*********************** Get Cache Memory *********************************************************//
         try
            {
             $memcached = new Memcached();
             $memcached->addServer($servercache, 11211);
             //$memcached->addServer('127.0.0.1', 11211);

         $valcachefield=[];
             for ($i=0; $i<$totfield; $i++)
                 {
                  $valcachefield[$i]=$memcached->get($cachefield[$i]);
                  echo nl2br($cachefield[$i].", ".$valcachefield[$i]."\n");
                 }
            }
        catch (exception $e)
            {
             echo $e->getMessage();
            }
//**************************** Save to Database ********************************************//        
         $value=[];
         $value[0]="'".$datetimes."'";
         $value[1]=$datetime;
         for ($i=0; $i<$totfield; $i++)
            {
             $value[2+$i]=$valcachefield[$i];
            }
         SaveToDataBase($server, $username, $password, $dbname, $table, $value);
         usleep(100000);
        }
    }
//************************************** END *************************************************//




 function ParsingParam($buff, $key)
 {
   $temp=null;
   $length=strlen($buff);
   $i=strpos($buff, $key);
   if ($i===false) return(null);
   else
   //if ($i)
       {
        $temp='';
        $stat=false;        
        while(1)
           {
            if ($stat)
               {
                if ($buff[$i]=="[") break;
                else if ($buff[$i]=="\n");
                else if ($buff[$i]=="\r");
                else if ($buff[$i]=="\t");
                else if ($buff[$i]==" ");
                else
                    {
                     $temp.=$buff[$i];
                    }
               }
            if ($buff[$i]=="\n") $stat=true;               
            $i++;
            if ($i>=$length) break;
           }
       }
   return($temp);
 }


function CheckDatabase($servername, $username, $password, $dbname)
 {
 $stat=true;
 try {
      $conn = new PDO("mysql:host=$servername", $username, $password);
   // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "CREATE DATABASE ".$dbname;
  // use exec() because no results are returned
      $conn->exec($sql);
      }

  catch(PDOException $e)
      {
       $messg=$e->getMessage();
       //echo $sql . "<br>" . $e->getMessage();
       //if ($messg)
       echo nl2br($messg."\n");
       $conn = null;
       $stat=false;
      }
   if ($stat) 
      {
       //$conn = null;
       echo nl2br("Database created successfully\n");
       usleep(100000);
//       exit(0);
      }
 }


 function CheckTableDB($servername, $username, $password, $dbname, $tblname, $dbfield, $dbparam, $totfield)
   {
    $i=0;
    $field[$i]="DATETIMES";        $param[$i++]="VarChar(20) NULL";
    $field[$i]="DATETIME";         $param[$i++]="bigint(11) NULL";
    for ($j=0; $j<$totfield; $j++)
        {
         $field[$i]=$dbfield[$j];
         $param[$i++]=$dbparam[$j];
        }
    $sql="SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = '".$dbname."' AND `table_name` = '".$tblname."' LIMIT 1";
    echo nl2br($sql."\n");

    $con = mysqli_connect($servername, $username, $password, $dbname);
    $result = $con->query($sql); 
    if ($result->num_rows==0)
        {
         echo nl2br("Creating Table ".$tblname."\n");
         $sql= "CREATE TABLE `" . $tblname. "`" . " (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, ";
         for ($j=0; $j<$i; $j++)
            {
             $sql.=$field[$j]." ".$param[$j];
             if ($j<($i-1)) $sql.=",";
            }
         $sql.=") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
         $result=$con->query($sql);
         echo nl2br("Creating Table ".$tblname."\n");
         sleep(100000);
        }
    $con->close();
  }


 function SaveToDataBase($servername, $username, $password, $dbname, $table, array $value)
 {
  $sql="INSERT INTO `".$table."` VALUES (0,";
  for ($i=0; $i<count($value); $i++)
     {
      $sql.=$value[$i];
      if ($i<(count($value)-1)) $sql.=',';
     }
  $sql.=")";
  echo nl2br($servername.','.$username.','.$password.','.$dbname.','.$sql."\n");
  $con = mysqli_connect($servername, $username, $password, $dbname);  
  $con->query($sql); 
  $con->close();
 }


function Split($char, $buff)
    {
     $cnt=0;
     $str="";
     //echo $buff."-".strlen($buff)."  ";
     for ($i=0; $i<strlen($buff); $i++)
        {
         if ($buff[$i]==$char)
            {
             if ($cnt==0) $GLOBALS['split0']=$str;
             else if ($cnt==1) $GLOBALS['split1']=$str;
             else if ($cnt==2) $GLOBALS['split2']=$str;
             else if ($cnt==3) $GLOBALS['split3']=$str;
             else if ($cnt==4) $GLOBALS['split4']=$str;
             else if ($cnt==5) $GLOBALS['split5']=$str;
             else if ($cnt==6) $GLOBALS['split6']=$str;
             else if ($cnt==7) $GLOBALS['split7']=$str;
             else if ($cnt==8) $GLOBALS['split8']=$str;
             else if ($cnt==9) $GLOBALS['split9']=$str;
             // echo nl2br($str."\r\n");
             $str="";
             $cnt++;
            }
         else
            {
             $str.=$buff[$i];
             if ($i>=strlen($buff)-1)
                {
                 if ($cnt==0) $GLOBALS['split0']=$str;
                 else if ($cnt==1) $GLOBALS['split1']=$str;
                 else if ($cnt==2) $GLOBALS['split2']=$str;
                 else if ($cnt==3) $GLOBALS['split3']=$str;
                 else if ($cnt==4) $GLOBALS['split4']=$str;
                 else if ($cnt==5) $GLOBALS['split5']=$str;
                 else if ($cnt==6) $GLOBALS['split6']=$str;
                 else if ($cnt==7) $GLOBALS['split7']=$str;
                 else if ($cnt==8) $GLOBALS['split8']=$str;
                 else if ($cnt==9) $GLOBALS['split9']=$str;
                 //echo nl2br($str."\r\n");
                 $str="";
                 $cnt++;
                }
            }
        }
     return($cnt);
    }
?>