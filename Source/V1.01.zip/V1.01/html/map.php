<!DOCTYPE html>
<html>
<head>
    <title>OpenStreetMap Example</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        #map { position:absolute; height: 99%; width: 99%; }
    </style>
</head>
<body>
    <div id="map"></div>
<script>

window.onload = function() {getLocation();};


let latitude=null;
let longitude=null;
let altitude=null;

var map = L.map('map').setView([-7.2902, 112.7273], 12); // Center map
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
attribution: '&copy; OpenStreetMap contributors'}).addTo(map);


function getLocation()
    {
     if (navigator.geolocation)
        {
         navigator.geolocation.getCurrentPosition(showPosition, showError);
         navigator.geolocation.getCurrentPosition((position) => {
         altitude = position.coords.altitude;
         console.log(`Altitude: ${altitude !== null ? altitude + " meters" : "Not available"}`);
});

        }
     else
        {
         //x.innerHTML = "Geolocation is not supported by this browser.";
        }
}


function showPosition(position) {
    latitude=position.coords.latitude;
    longitude=position.coords.longitude;
    //altitude=position.coords.altitude;
    console.log(latitude, longitude, altitude);
    if ((longitude)&&(latitude))
        {
         console.log("here..");

                // Array of locations
        var locations =[]; 
        locations = [
                    { lat: latitude, lng: longitude, name: "Gunung Anyar, East Java" },
                    //{ lat: -6.2088, lng: 106.8456, name: "Jakarta" },
                    //{ lat: -8.6705, lng: 115.2126, name: "Bali" }
                ];

                // Loop through locations and add markers
                locations.forEach(function(location) {
                    L.marker([location.lat, location.lng]).addTo(map)
                        .bindPopup(location.name);});

                var points=[];
                points = [
                    //[-6.2088, 106.8456], // Jakarta
                    [latitude,  longitude], // Gunung Anyar, East Java
                    //[-8.6705, 115.2126]  // Bali
                ];

                // Draw a polyline (connect points)
                var polyline = L.polyline(points, { color: 'red' }).addTo(map);

                // Fit map to polyline bounds
                map.fitBounds(polyline.getBounds());
        }

    //x.innerHTML = "Latitude: " + position.coords.latitude + "<br>Longitude: " + position.coords.longitude;
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            //x.innerHTML = "User denied the request for Geolocation.";
            break;
        case error.POSITION_UNAVAILABLE:
            //x.innerHTML = "Location information is unavailable.";
            break;
        case error.TIMEOUT:
            //x.innerHTML = "The request to get user location timed out.";
            break;
        case error.UNKNOWN_ERROR:
            //x.innerHTML = "An unknown error occurred.";
            break;
    }
}


</script>
</body>
</html>