<?php
 session_start();
 include "rtc.php";

 const kMaxMAC = 256;

 GetDatetime(); 
 try
     {

      $memcached = new Memcached();

       // Connect via UNIX socket
      // $memcache->addServer('/tmp/memcached.sock', 0);
      $memcached->addServer("127.0.0.1", 11211);
      if (isset($_POST['idw0']))
         {
          $tAddr=$_POST['idw0'];
          $offset = strpos($tAddr, "@");
          if ($offset!== false)
             {
              $macaddr = substr($tAddr, $offset+1);
              $memcached->set('timesync@'.$macaddr, $datetime);
              $stat=false;
              for ($i=0; $i<kMaxMAC; $i++)
                  {
                   $maclist=$memcached->get("devlist".$i);
                   if ($maclist==null) 
                        {
                         if ($stat==false) $memcached->set('devlist'.$i, $macaddr);
                         break;
                        }
                   if ($maclist==$macaddr)
                        {
                         $stat=true;
                         $memcached->set('devtime'.$i, $datetime);
                        }
                  }
             }          
        }

///********************************* This only for ScoreBoard ***************************//
/*
      $date = new DateTime();
      $timestamp=$date->format('Uv');
      $memcached->set('timestamp', $timestamp);
      $timestamp10mS=$timestamp/10;
      $timestamp1S=$timestamp/1000;
      for ($i=0; $i<kMaxMAC; $i++)
          {
           $maclist=$memcached->get("devlist".$i); 
           $timerplaystamp=$memcached->get("timerplaystamp@".$maclist);

           $timerplaystamp/=10;
           $diff=$timestamp10mS-$timerplaystamp;
           $timerplay=$memcached->get("timerplay@".$maclist);
           $runmst=$memcached->get("runmst@".$maclist);
           if ($timerplay>0)
              {
               $timerplay=$timerplay-$diff;
               if ($timerplay<0) $timerplay=0;
               if ($runmst) $memcached->set('timerplay@'.$maclist, $timerplay);
               $memcached->set('timerplaystamp@'.$maclist, $timestamp);
              }

           $timeout=$memcached->get("timeout@".$maclist);
           $timeoutstamp=$memcached->get("timeoutstamp@".$maclist);

           $timeoutstamp/=1000;
           $timeoutstamp=intval($timeoutstamp);
           $diff=$timestamp1S-$timeoutstamp;
           $diff=intval($diff);
           if (($timeout>0)&&($diff>=1))
              {
               $timeout=$timeout-$diff;
               if ($timeout<0) $timeout=0;
               $memcached->set('timeout@'.$maclist, $timeout);
               $memcached->set('timeoutstamp@'.$maclist, $timestamp); 

              }              
              
          }   
*/           
//***************************************************************************************//          

      if (isset($_POST['mem']))
            {
             print_r($memcached->getStats());
            }
      else if(isset($_POST['rd']))
          {
            if(isset($_POST['id']))
                {
                 $id=$_POST['id'];
                 $tag=$_POST['tag'];
                 echo $tag.",".$memcached->get($id);
                }
          }
        else if (isset($_POST['rdmulti']))
            {
             if (isset($_POST['total']))
                {
                    $out = '';
                    $total = $_POST['total'];
                    $tag = $_POST['tag'];

                    // collect all keys first
                    $keys = [];
                    for ($i = 0; $i < $total; $i++) {
                        $keys[] = $_POST['id'.$i];
                    }

                    // fetch all values in one batch
                    $values = $memcached->getMulti($keys);

                    // build output in the same order as original keys
                    for ($i = 0; $i < $total; $i++) {
                        $id = $_POST['id'.$i];
                        $out .= isset($values[$id]) ? $values[$id] : ''; // handle missing keys
                        if ($i < ($total - 1)) $out .= ',';
                    }
                    echo $tag . "," . $out;
                }
            }
       else if (isset($_POST['wr']))
          {
           if(isset($_POST['id'])&&isset($_POST['val']))
                {
                 $tag=$_POST['tag'];
                 $id=$_POST['id'];
                 $val=$_POST['val'];
                 $memcached->set($id, $val, 7200);
                 $val=$memcached->get($id);
                 echo $tag.','."ACK";
                }
          }            
        else if (isset($_POST['wrmulti']))
            {
             if (isset($_POST['total']))
                {
                    $total = $_POST['total'];
                    $tag = $_POST['tag'];

                    // collect all key => value pairs first
                    $items = [];
                    for ($i = 0; $i < $total; $i++) {
                        $id = $_POST['id'.$i];
                        $val = $_POST['val'.$i];
                        $items[$id] = $val;
                    }
                    // write all items in one batch
                    $memcached->setMulti($items, 7200);
                    echo $tag . ',ACK';
                }
            }
        else if (isset($_POST['rdwrmulti']))
            {
             if (isset($_POST['tag']))
                {
                    $tag = $_POST['tag'];

                    // ---------- Batch write ----------
                    $totalw = $_POST['totalw'];
                    $items = [];
                    for ($i = 0; $i < $totalw; $i++) {
                        $idw = $_POST['idw'.$i];
                        $valw = $_POST['valw'.$i];
                        $items[$idw] = $valw;
                    }

                    // Write all items in one batch
                    if (!empty($items)) {
                        $memcached->setMulti($items, 7200);
                    }

                    // ---------- Batch read ----------
                    $totalr = $_POST['totalr'];
                    $keys = [];
                    for ($i = 0; $i < $totalr; $i++) {
                        $keys[] = $_POST['idr'.$i];
                    }

                    // Fetch all values in one batch
                    $values = $memcached->getMulti($keys);

                    // Build output string in the original order
                    $out = '';
                    for ($i = 0; $i < $totalr; $i++) {
                        $idr = $_POST['idr'.$i];
                        $out .= isset($values[$idr]) ? $values[$idr] : ''; // handle missing keys
                        if ($i < ($totalr - 1)) $out .= ',';
                    }
                    echo $tag . "," . $out;                    
                }
            }
      }
 catch (exception $e)
    {
     echo $e->getMessage();
    }
?>