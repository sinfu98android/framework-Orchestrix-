<?php 
 session_start();

//************************* Select All from mysql limited row ******************************//
 if ((isset($_POST['table']))&&(isset($_POST['select'])))
      {
       include "db.php";

       //$con = mysqli_connect($servername, $username, $password,$dbname);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['table'];
       $total  = $_POST['total'];


       for ($i=0; $i<$total; $i++) $header[$i]=$_POST['id'.$i];
       if (isset($_POST['limit']))
            {
             $limit=$_POST['limit'];
             $sql = "SELECT * FROM ".$tbl."  ORDER BY `id` DESC LIMIT ".$limit;
            }
       else $sql = "SELECT * FROM ".$tbl;

       //echo $tag.','.$sql;
       
       $result = $con->query($sql);     
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc())
                  {
                   for ($i=0; $i<$total; $i++) $out.=$row[$header[$i]].',';
                   $countlim++;
                  }
             $out=$tag.','.$countlim.','.$out;
             echo $out;
            }
       else echo $tag.','.'0';  
       $con->close();
      }

//************************* Select field in specified id  ******************************//
 if ((isset($_POST['table']))&&(isset($_POST['selectid'])))
      {
       include "db.php";

       //$con = mysqli_connect($servername, $username, $password,$dbname);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['table'];
       $whereid= $_POST['selectid'];

       if (isset($_POST['total']))
          {
           $total  = $_POST['total'];
           for ($i=0; $i<$total; $i++) $header[$i]=$_POST['id'.$i];
          }
       else $header[0]=$_POST['id0'];
       $sql = "SELECT * FROM `".$tbl.'` WHERE id='.$whereid;
       $result = $con->query($sql);     
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc())
                  {
                   if (isset($_POST['total']))
                      {
                       for ($i=0; $i<$total; $i++) $out.=$row[$header[$i]].',';
                      }
                   else $out=$row[$header[0]];
                  }
             $out=$tag.','.$out;
             echo $out;
            }
       else echo $tag.','.'0';  
       $con->close();
      }


//******************* show table *********************
 if ((isset($_POST['table']))&&(isset($_POST['show'])))
      {
       include "db.php";

       //$con = mysqli_connect($servername, $username, $password);
       $count=0;
       $out='';
       $header = array();
       $tag = $_POST['tag'];
       $tbl = $_POST['table'];
       $sql = "SHOW COLUMNS FROM ".$tbl;
       $result = $con->query($sql);
       while($row = mysqli_fetch_array($result))
            {
             $header[$count]=$row['Field'];
             $count++;
            }
       for ($i=0; $i<$count; $i++) $out.=$header[$i].",";
       echo $out=$tag.','.$count.','.$out;
       $con->close();
      }

// ************** insert table ******************
//"INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";      
if ((isset($_POST['table']))&&(isset($_POST['insert'])))
      {
       include "db.php";
       //$con = mysqli_connect($servername, $username, $password);
       $count=0;
       $header = array();
       $tbl = $_POST['table'];
       $field=$_POST['tag'];
       $value=$_POST['val'];
       $sql = "INSERT INTO ".$tbl." (".$field.") VALUES (".$value.")";
       echo $sql;
       $result = $con->query($sql);
       $con->close();            
      }


//************** select count specified record condition ********************
 if ((isset($_POST['table']))&&(isset($_POST['count'])))
      {
       include "db.php";
       $con = mysqli_connect($servername, $username, $password);
       $count=0;
       $tbl = $_POST['table'];
       if (isset($_POST['cond'])&&isset($_POST['val']))
            {
             $cond= $_POST['cond'];
             $val=  $_POST['val'];
             $sql = "SELECT * FROM ".$tbl." WHERE ".$cond."=".$val;
            }
       else $sql = "SELECT * FROM ".$tbl;
       $result = $con->query($sql);
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc()) $count++;
            }
       echo $count;
       $con->close();
      }


//***************** update specified record ******************
// UPDATE daftar_dosen SET no_hp ='085298710065' WHERE nama_dosen='Sabrina Sari';
if ((isset($_POST['table']))&&(isset($_POST['update'])))
      {
       include "db.php";
       //$con = mysqli_connect($servername, $username, $password);

       $count=0;
       $header = array();
       $tag    =$_POST['tag'];       
       $tbl = $_POST['table'];
       $total=$_POST['total'];
       $cond=$_POST['cond'];
       $vcond=$_POST['vcond'];
       
       //echo $total;
       
       $sql = "UPDATE ".$tbl." SET ";
       for ($i=0; $i<$total; $i++)
          {
           $field=$_POST['field'.$i];
           $val=$_POST['val'.$i];
           $sql.=$field."=".$val;
           if ($i<($total-1)) $sql.=',';
          }
       $sql.=" WHERE ".$cond."=".$vcond;
       //echo $sql;
       $result = $con->query($sql);
       $con->close();            
       echo $tag;
      }
//******************** Delete Record ****************//
//DELETE FROM Customers WHERE CustomerName='Alfreds Futterkiste';
if ((isset($_POST['table']))&&(isset($_POST['delete'])))
      {
       include "db.php";
       $con = mysqli_connect($servername, $username, $password);

       $tbl = $_POST['table'];
       $cond=$_POST['cond'];
       $vcond=$_POST['vcond'];       
       $sql = "DELETE FROM ".$tbl;
       $sql.=" WHERE ".$cond."=".$vcond;
       echo $sql;
       $result = $con->query($sql);
       $con->close();            
       echo $result;       
      }

//************************** Get LAST Record ***********************//
if ((isset($_POST['table']))&&(isset($_POST['last']))&&(isset($_POST['total'])))      // table=1&last=1&total=N&id0=a&id1=b..&idN=x
      {
       include "db.php";

       $out='';
       $header = array();
       $countlim=0;

       $table=$_POST['table'];
       $total=$_POST['total'];
       for ($i=0; $i<$total; $i++) $header[$i]=$_POST['id'.$i];
       $con = mysqli_connect($servername, $username, $password, $dbname);
       $sql = "SELECT * FROM ".$table."  ORDER BY `id` DESC LIMIT 1";
       $result = $con->query($sql);     
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc())
                  {
                   for ($i=0; $i<$total; $i++) $out.=$row[$header[$i]].',';
                   $countlim++;
                  }
            }      
      $con->close();
      echo $out;
      }
//************************* Create Table New ***********************//
if ((isset($_POST['table']))&&(isset($_POST['create'])))
   {
    include "db.php";

          for ($n = 0; $n<100; $n++)
               {
                ${"tag$n"}=null;
                ${"val$n"}=null;
               }

          $table=$_POST['table'];
          for ($n = 0; $n<100; $n++) if(isset($_POST['tag'.$n])) ${"tag$n"}=$_POST['tag'.$n];
          for ($n = 0; $n<100; $n++) if(isset($_POST['val'.$n])) ${"val$n"}=$_POST['val'.$n];

         $con = mysqli_connect($servername, $username, $password, $dbname);
          $sql="SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = '".$dbname."' AND `table_name` = '".$table."' LIMIT 1;";
         $result=$con->query($sql);
                 //echo nl2br("tbl user ".$result->num_rows."\n");
         if ($result->num_rows==0)
               {
               $sql= "CREATE TABLE `" . $table. "`" . " (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY";
                for ($n = 0; $n<100; $n++)
                    {    
                     if ((${"tag$n"}==null)||(${"val$n"}==null)) break;
                     $sql.=',';
                     $sql.=${"tag$n"}.' '.${"val$n"};
                    }
                $sql.=") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
                //echo nl2br($sql."\n");
                $result=$con->query($sql);
                $con->close();
                echo "SUCCESS";
               }
         else echo "OK";
      }
//************************ Logging Data and Sync time ***********************//  // logging and sync time from external devices
if ((isset($_POST['table']))&&(isset($_POST['sync']))&&(isset($_POST['log'])))
      {
       include "db.php";

      for ($n = 0; $n<20; $n++)
            {
             ${"tag$n"}=null;
             ${"val$n"}=null;
            }
      $table=$_POST['table'];
      for ($n = 0; $n<20; $n++) if(isset($_POST['tag'.$n])) ${"tag$n"}=$_POST['tag'.$n];
      for ($n = 0; $n<20; $n++) if(isset($_POST['val'.$n])) ${"val$n"}=$_POST['val'.$n];

       $field=null;
       $value=null;
 
       for ($n = 0; $n<20; $n++)
         {  
          if ((${"tag$n"}==null)||(${"val$n"}==null)) break;
          if ($n>0)
             {
              $field.=',';
              $value.=',';
             }
          $field.=${"tag$n"};
          $value.=${"val$n"};
         }
      $con = mysqli_connect($servername, $username, $password, $dbname);
       $sql = "INSERT INTO ".$table." (".$field.") VALUES (".$value.")";
       //echo $sql;
       $result = $con->query($sql);
       $con->close();
       echo date("Y/m/d H:i:s");
      }
 //date_default_timezone_set("Asia/Jakarta");
 //echo $sql;

//************************* Create Table New in Custom Server & Database ***********************//
if ((isset($_POST['createcustom']))&&(isset($_POST['servername']))&&(isset($_POST['dbname']))&&(isset($_POST['table'])))
   {
    $servername=$_POST['servername'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $dbname=$_POST['dbname'];
    //$servername=gethostbyname($hostname);
    //echo $servername.', '.$hostname;
    //gethostbyname(string $hostname): string
    $con = mysqli_connect($servername, $username, $password);
    if (!$con)
        {
         die('Could not connect: ' . mysql_error());
        }
    else
        {
          $sql = "CREATE DATABASE IF NOT EXISTS ".$dbname;
          $result = $con->query($sql);
          if ($result)
            {
             $con->close();
             $con = mysqli_connect($servername, $username, $password, $dbname);
             $result = $con->query($sql);
    //         echo $result;
            }
          //echo nl2br("database ".$result."\n");
        }

      for ($n = 0; $n<100; $n++)
           {
            ${"tag$n"}=null;
            ${"val$n"}=null;
           }

      $table=$_POST['table'];
      for ($n = 0; $n<100; $n++) if(isset($_POST['tag'.$n])) ${"tag$n"}=$_POST['tag'.$n];
      for ($n = 0; $n<100; $n++) if(isset($_POST['val'.$n])) ${"val$n"}=$_POST['val'.$n];

     $con = mysqli_connect($servername, $username, $password, $dbname);
      $sql="SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = '".$dbname."' AND `table_name` = '".$table."' LIMIT 1;";
     $result=$con->query($sql);
     //echo nl2br("tbl user ".$result->num_rows."\n");
     if ($result->num_rows==0)
           {
           $sql= "CREATE TABLE `" . $table. "`" . " (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY";
            for ($n = 0; $n<100; $n++)
                {    
                 if ((${"tag$n"}==null)||(${"val$n"}==null)) break;
                 $sql.=',';
                 $sql.=${"tag$n"}.' '.${"val$n"};
                }
            $sql.=") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
            //echo nl2br($sql."\n");
            $result=$con->query($sql);
            $con->close();
            echo "CREATE NEW SUCCESS";
           }
     else echo "OK";
  }


//************************ Logging Data and Sync time to Custome Server and Database ***********************//  // logging and sync time from external devices
if ((isset($_POST['tablecustom']))&&(isset($_POST['log']))&&
    (isset($_POST['servername']))&&(isset($_POST['dbname'])))
      {
       $servername=$_POST['servername'];
       $username=$_POST['username'];
       $password=$_POST['password'];
       $dbname=$_POST['dbname'];

       $con = mysqli_connect($servername, $username, $password);
       if (!$con)
          {
           die('Could not connect: ' . mysql_error());
          }
       else
          {
           $sql = "CREATE DATABASE IF NOT EXISTS ".$dbname;
           $result = $con->query($sql);
           if ($result)
              {
               $con->close();
               $con = mysqli_connect($servername, $username, $password, $dbname);
               $result = $con->query($sql);
        //     echo $result;
               }
              //echo nl2br("database ".$result."\n");
          }


      for ($n = 0; $n<20; $n++)
            {
             ${"tag$n"}=null;
             ${"val$n"}=null;
            }
      $tablecustom=$_POST['tablecustom'];
      for ($n = 0; $n<20; $n++) if(isset($_POST['tag'.$n])) ${"tag$n"}=$_POST['tag'.$n];
      for ($n = 0; $n<20; $n++) if(isset($_POST['val'.$n])) ${"val$n"}=$_POST['val'.$n];

      $field=null;
      $value=null;
 
      for ($n = 0; $n<20; $n++)
         {  
          if ((${"tag$n"}==null)||(${"val$n"}==null)) break;
          if ($n>0)
             {
              $field.=',';
              $value.=',';
             }
          $field.=${"tag$n"};
          $value.=${"val$n"};
         }
      $con = mysqli_connect($servername, $username, $password, $dbname);
      $sql = "INSERT INTO ".$tablecustom." (".$field.") VALUES (".$value.")";
      echo $servername.', '.$username.', '.$password.', '.$dbname.', '.$sql;
      $result = $con->query($sql);
      //echo $result;
      $con->close();
      if (isset($_POST['sync'])) echo date("Y/m/d H:i:s");
      }
 //date_default_timezone_set("Asia/Jakarta");
 //echo $sql;


//********************************************************************************************************************************//
//************************************ Server Custom, dbase, table ramdom location server ****************************************//
//********************************************************************************************************************************//
//***************** update specified record ******************
// UPDATE daftar_dosen SET no_hp ='085298710065' WHERE nama_dosen='Sabrina Sari';
if ((isset($_POST['tablex']))&&(isset($_POST['updatex'])))
      {
       $serverx=$_POST['serverx'];
       $dbasex=$_POST['dbasex'];
       $userx=$_POST['userx'];
       $passx=$_POST['passx'];
       include "server.php";

       ConnectDatabase($serverx, $userx, $passx, $dbasex);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['tablex'];
       $total  =$_POST['total'];
       $cond   =$_POST['cond'];
       $vcond  =$_POST['vcond'];
       
       //echo $total;
       
       $sql = "UPDATE ".$tbl." SET ";
       for ($i=0; $i<$total; $i++)
          {
           $field=$_POST['field'.$i];
           $val=$_POST['val'.$i];
           $sql.=$field."=".$val;
           if ($i<($total-1)) $sql.=',';
          }
       if (isset($_POST['condcustom']))
          {
           $condcustom =$_POST['condcustom'];
           $sql.=" WHERE ".$condcustom;
          }
       else $sql.=" WHERE ".$cond."=".$vcond;

//       echo $tag.','.$sql;
//       exit();

       $con = mysqli_connect($serverx, $userx, $passx, $dbasex);
       $result = $con->query($sql);
       $con->close();            
       echo $tag;
      }


//************************* Select field custom server, dbase, table in specified id  ******************************//
 if ((isset($_POST['serverx']))&&(isset($_POST['selectid'])))
      {
       $serverx=$_POST['serverx'];
       $dbasex=$_POST['dbasex'];
       $userx=$_POST['userx'];
       $passx=$_POST['passx'];
       include "server.php";

       ConnectDatabase($serverx, $userx, $passx, $dbasex);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['tablex'];
       $whereid= $_POST['selectid'];
       if (isset($_POST['total']))
          {
           $total  = $_POST['total'];
           for ($i=0; $i<$total; $i++) $header[$i]=$_POST['id'.$i];
          }
       else $header[0]=$_POST['id0'];
       $sql = "SELECT * FROM `".$tbl.'` WHERE `id`='.$whereid;
       //echo $tag.','.$sql.','.$serverx.','.$dbasex.','.$tbl.','.$userx.','.$passx.',';
       $con = mysqli_connect($serverx, $userx, $passx, $dbasex);
       $result = $con->query($sql);     
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc())
                  {
                   if (isset($_POST['total']))
                      {
                       for ($i=0; $i<$total; $i++) $out.=$row[$header[$i]].',';
                      }
                   else $out=$row[$header[0]];
                  }       
             $out=$tag.','.$out;
             echo $out;
            }
       else echo $tag.','.' ';
       $con->close();
      }


//************************* Select field custom server, dbase, table in specified id  ******************************//
 if ((isset($_POST['serverx']))&&(isset($_POST['selamount'])))
      {
       $serverx=$_POST['serverx'];
       $dbasex=$_POST['dbasex'];
       $userx=$_POST['userx'];
       $passx=$_POST['passx'];
       include "server.php";

       ConnectDatabase($serverx, $userx, $passx, $dbasex);

       $out='';
       $count=0;
       $total=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['tablex'];
       $total = $_POST['total'];
       
       for ($i=0; $i<100; $i++) $header[$i]=null;
       $fieldcount=0;
       while(1)
            {
             if ($_POST['id'.$fieldcount])
                {
                 $header[$fieldcount]=$_POST['id'.$fieldcount];
                 $fieldcount++;
                }
             else break;
            }
       if ($fieldcount==0) $header[0]='id';
       if (isset($_POST['orderby'])) $orderby="`".$_POST['orderby']."`";
       else $orderby="`id`";

       if (isset($_POST['where']))
            {
             $cond   =$_POST['cond'];
             $vcond  =$_POST['vcond'];
             if (isset($_POST['asc']))
                {
                 if (isset($_POST['condcustom']))
                    {  
                     $condcustom =$_POST['condcustom'];
                     if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` WHERE '.$condcustom.' order by '.$orderby.' ASC LIMIT '.$total;
                     else  $sql = "SELECT * FROM `".$tbl.'` WHERE '.$condcustom.' order by '.$orderby.' ASC';
                    }
                 else
                    {
                     if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` WHERE '.$cond."=".$vcond.' order by '.$orderby.' ASC LIMIT '.$total;
                     else  $sql = "SELECT * FROM `".$tbl.'` WHERE '.$cond."=".$vcond.' order by '.$orderby.' ASC';
                    }
                }
             else
                {
                 if (isset($_POST['condcustom']))
                    {
                     $condcustom =$_POST['condcustom'];
                     if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` WHERE '.$condcustom.' order by '.$orderby.' DESC LIMIT '.$total;
                     else  $sql = "SELECT * FROM `".$tbl.'` WHERE '.$condcustom.' order by '.$orderby.' DESC';
                    }
                 else
                    {
                     if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` WHERE '.$cond."=".$vcond.' order by '.$orderby.' DESC LIMIT '.$total;
                     else  $sql = "SELECT * FROM `".$tbl.'` WHERE '.$cond."=".$vcond.' order by '.$orderby.' DESC';
                    }
                }
           }
       else 
            {
             //if (isset($_POST['asc'])) $sql = "SELECT * FROM `".$tbl.'` order by `id` ASC LIMIT '.$total;
             //else $sql = "SELECT * FROM `".$tbl.'` order by `id` DESC LIMIT '.$total;
             if (isset($_POST['asc']))
                {
                 if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` order by '.$orderby.' ASC LIMIT '.$total;
                 else $sql = "SELECT * FROM `".$tbl.'` order by '.$orderby.' ASC';
                }
             else
                {
                 if (isset($_POST['total'])) $sql = "SELECT * FROM `".$tbl.'` order by '.$orderby.' DESC LIMIT '.$total;
                 else $sql = "SELECT * FROM `".$tbl.'` order by '.$orderby.' DESC';
                }
            }
       //echo $tag.','.$sql.','.$serverx.','.$dbasex.','.$tbl.','.$userx.','.$passx.',';
       //echo $tag.','.$sql;
       //echo $tag.','.$header[0].','.$header[1].','.$header[2].','.$header[3].','.$header[4].','.$fieldcount;
       //exit();

       $total=0;
       $con = mysqli_connect($serverx, $userx, $passx, $dbasex);
       $result = $con->query($sql);     
       if ($result->num_rows > 0)
            {
             while($row = $result->fetch_assoc())
                  {
                   for ($i=0; $i<$fieldcount; $i++)
                       {
                        //if ($i<($fieldcount-1)) $out.=$row[$header[$i]].',';
                        //else  $out.=$row[$header[$i]];
                        $out.=$row[$header[$i]].',';
                       }
                   $total++;
                  }       
             //$out=$tag.','.$total.','.$out;
             echo $tag.','.$total.','.$out;
            }
       else echo $tag.','.'0';
       $con->close();       
      }


// ************** insert tablex ******************
//"INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";      
if ((isset($_POST['tablex']))&&(isset($_POST['insertx'])))
      {
       $serverx=$_POST['serverx'];
       $dbasex=$_POST['dbasex'];
       $userx=$_POST['userx'];
       $passx=$_POST['passx'];
       include "server.php";
       ConnectDatabase($serverx, $userx, $passx, $dbasex);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['tablex'];

       $count=0;
       $header = array();
       $field=$_POST['fieldx'];
       $value=$_POST['valx'];
       $sql = "INSERT INTO `".$tbl."` (".$field.") VALUES (".$value.")";
       //echo $tag.",".$sql;
       //exit();

       $con = mysqli_connect($serverx, $userx, $passx, $dbasex);
       $result = $con->query($sql);
       $con->close();
       echo $tag.','.$sql;
      }


//DELETE FROM Customers WHERE CustomerName='Alfreds Futterkiste';
if ((isset($_POST['tablex']))&&(isset($_POST['deletex'])))
      {
       $serverx=$_POST['serverx'];
       $dbasex=$_POST['dbasex'];
       $userx=$_POST['userx'];
       $passx=$_POST['passx'];
       include "server.php";
       ConnectDatabase($serverx, $userx, $passx, $dbasex);

       $out='';
       $count=0;
       $header = array();
       $limit=0;
       $countlim=0;
       $tag    =$_POST['tag'];
       $tbl    = $_POST['tablex'];
       $cond=$_POST['condx'];
       $vcond=$_POST['vcondx'];       
       $sql = "DELETE FROM ".$tbl;
       $sql.=" WHERE ".$cond."=".$vcond;
       $con = mysqli_connect($serverx, $userx, $passx, $dbasex);           
       $result = $con->query($sql);
       $con->close();            
       echo $tag.', SUCCESS, '.$result;
      }


// ************** Create Table ******************
 if ((isset($_POST['createdb']))&&(isset($_POST['serverx']))&&(isset($_POST['dbasex']))&&(isset($_POST['userx']))&&(isset($_POST['passx']))&&(isset($_POST['tablex']))&&(isset($_POST['total'])))
    {
     include "server.php";
     
     $tag=$_POST['tag'];
     $server = $_POST['serverx'];
     $username = $_POST['userx'];
     $password = $_POST['passx'];
     $dbname = $_POST['dbasex'];
     $table = $_POST['tablex'];
     $totfield= $_POST['total'];
     if ((isset($_POST['key']))) $key=$_POST['key'];
     if ((isset($_POST['keyparam']))) $keyparam=$_POST['keyparam'];

     for ($i=0; $i<$totfield; $i++)
         {
          $tbfield[$i]=$_POST['field'.$i];
          $typeparam[$i]=$_POST['param'.$i];     //"VarChar(30) NULL";
         }
     echo $tag.",";
//     exit();
     CheckDatabase($server, $username, $password, $dbname);


     if ((isset($_POST['key']))&&(isset($_POST['keyparam']))) CheckTableDBKey($server, $username, $password, $dbname, $table, $tbfield, $typeparam, $totfield, $key, $keyparam);
     else CheckTableDB($server, $username, $password, $dbname, $table, $tbfield, $typeparam, $totfield);
     exit();
    }





//*****************************************************************************************//
//                                      Common Function                                    //
//*****************************************************************************************//
 function ParsingParam($buff, $key)
 {
   $temp=null;
   $length=strlen($buff);
   $i=strpos($buff, $key);
   if ($i===false) return(null);
   else
   //if ($i)
       {
        $temp='';
        $stat=false;        
        while(1)
           {
            if ($stat)
               {
                if ($buff[$i]=="[") break;
                else if ($buff[$i]=="\n");
                else if ($buff[$i]=="\r");
                else if ($buff[$i]=="\t");
                else if ($buff[$i]==" ");
                else
                    {
                     $temp.=$buff[$i];
                    }
               }
            if ($buff[$i]=="\n") $stat=true;               
            $i++;
            if ($i>=$length) break;
           }
       }
   return($temp);
 }


function CheckDatabase($servername, $username, $password, $dbname)
 {
 $stat=true;
 try {
      $conn = new PDO("mysql:host=$servername", $username, $password);
   // set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "CREATE DATABASE ".$dbname;
  // use exec() because no results are returned
      $conn->exec($sql);
      }

  catch(PDOException $e)
      {
       $messg=$e->getMessage();
       //echo $sql . "<br>" . $e->getMessage();
       //if ($messg)
       //echo (','.$messg);
       $conn = null;
       $stat=false;
      }
   if ($stat) 
      {
       //$conn = null;
       //echo nl2br("Database created successfully\n");
       usleep(100000);
//       exit(0);
      }
 }


function CheckTableDB($servername, $username, $password, $dbname, $tblname, $tbfield, $tbparam, $totfield)
   {
    $i=0;
//    $field[$i]="DATETIMES";        $param[$i++]="VarChar(20) NULL";
//    $field[$i]="DATETIME";         $param[$i++]="bigint(11) NULL";
    for ($j=0; $j<$totfield; $j++)
        {
         $field[$i]=$tbfield[$j];
         $param[$i++]=$tbparam[$j];
        }
    $sql="SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = '".$dbname."' AND `table_name` = '".$tblname."' LIMIT 1";

    $con = mysqli_connect($servername, $username, $password, $dbname);
    $result = $con->query($sql); 
    if ($result->num_rows==0)
        {
         echo ","."NEW";
         $sql= "CREATE TABLE `" . $tblname. "`" . " (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, ";
         for ($j=0; $j<$i; $j++)
            {
             $sql.=$field[$j]." ".$param[$j];
             if ($j<($i-1)) $sql.=",";
            }
         $sql.=") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
         //echo ','.$sql;
         $result=$con->query($sql);
         //echo nl2br("Creating Table ".$tblname."\n");
         //echo nl2br($sql."\n");
         usleep(100000);
        }
    else
         {
          echo ",EXIST";
//          $countlim=0;
//          while($row = $result->fetch_assoc())
//                  {
//                   for ($i=0; $i<$total; $i++) $out.=$row[$header[$i]].',';
//                   $countlim++;
//                  }
//          echo ",".$countlim;
         }
    $con->close();
  }


function CheckTableDBKey($servername, $username, $password, $dbname, $tblname, $tbfield, $tbparam, $totfield, $key, $keyparam)
   {
    $i=0;
    for ($j=0; $j<$totfield; $j++)
        {
         $field[$i]=$tbfield[$j];
         $param[$i++]=$tbparam[$j];
        }
    $sql="SELECT * FROM `information_schema`.`tables` WHERE `table_schema` = '".$dbname."' AND `table_name` = '".$tblname."' LIMIT 1";

    $con = mysqli_connect($servername, $username, $password, $dbname);
    $result = $con->query($sql); 
    if ($result->num_rows==0)
        {
         echo ",NEW";
         if ($totfield)
            {
             $sql= "CREATE TABLE `".$tblname."`"." (`".$key."` ".$keyparam." NOT NULL PRIMARY KEY , ";
             for ($j=0; $j<$i; $j++)
                {
                 $sql.=$field[$j]." ".$param[$j];
                 if ($j<($i-1)) $sql.=",";
                }
            }
         else $sql= "CREATE TABLE `".$tblname."`"." (`".$key."` ".$keyparam." NOT NULL PRIMARY KEY ";
         $sql.=") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
         $result=$con->query($sql);
         //echo ",".$sql;
         usleep(100000);
        }
    else
         {
          echo ",EXIST";
         }
    $con->close();
  }
  

?>