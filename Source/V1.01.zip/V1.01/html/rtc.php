<?php 
 date_default_timezone_set("Asia/Bangkok");
 define("kTblMonthLunar", [31,29,31,30,31,30,31,31,30,31,30,31]);
 define("kTblMonth", [31,28,31,30,31,30,31,31,30,31,30,31]);
 const kOffSetYear=2000;
 const kOffDate=6;

 if (isset($_POST['datetime']))
 		{
		 $year=date("Y");
		 $month=date("m");
		 $day=date("d");
		 $hour=date("H");
		 $min=date("i");
		 $sec=date("s");
		 $datetime=ConvDatetimeToInt($year, $month, $day, $hour, $min, $sec);
		  echo nl2br($datetime.','.ConvDatetimetoText($datetime));
		 //echo nl2br($datetime);
		}


 if (isset($_POST['syncdatetime']))
 		{
 		 $tag=$_POST['tag'];
		 $year=date("Y");
		 $month=date("m");
		 $day=date("d");
		 $hour=date("H");
		 $min=date("i");
		 $sec=date("s");
		 $datetime=ConvDatetimeToInt($year, $month, $day, $hour, $min, $sec);
		  echo nl2br($tag.','.$datetime.','.ConvDatetimetoText($datetime));
		 //echo nl2br($datetime);
		}
 

 function GetDatetime()
 	{
 	 date_default_timezone_set("Asia/Bangkok");
	 $GLOBALS['year']=date("Y");
	 $GLOBALS['month']=date("m");
	 $GLOBALS['day']=date("d");
	 $GLOBALS['hour']=date("H");
	 $GLOBALS['min']=date("i");
	 $GLOBALS['sec']=date("s");
	 $GLOBALS['datetime']=ConvDatetimeToInt($GLOBALS['year'], $GLOBALS['month'], $GLOBALS['day'], $GLOBALS['hour'], $GLOBALS['min'], $GLOBALS['sec']);
	 $GLOBALS['datetimes']=$GLOBALS['year'].'/'.$GLOBALS['month'].'/'.$GLOBALS['day'].' '.$GLOBALS['hour'].':'.$GLOBALS['min'].':'.$GLOBALS['sec'];
	 //return(ConvDatetimeToInt($GLOBALS['year'], $GLOBALS['month'], $GLOBALS['day'], $GLOBALS['hour'], $GLOBALS['min'], $GLOBALS['sec']));
 	}

 function CheckLunar($year)
	{
      if (($year % 400)==0) return(true);
	  if (($year % 100)==0) return(false);
  	  if (($year % 4)==0) return(true);
  	  return(false);
	}


 function ConvDatetimeToInt($year, $month, $day, $hour, $min, $sec)
 	{
 	 $temp=$day-1;
 	 $temp1=kOffSetYear;
 	 //echo $year.'/'.$month.'/'.$day.' '.$hour.':'.$min.':'.$sec.' --> ';
 	 while(1)
 	 	{
 	 	 if ($temp1==$year) break;
 	 	 if (CheckLunar($temp1)) $temp+=366;
 	 	 else $temp+=365;
 	 	 $temp1=$temp1+1;
 	 	}
	  	 
 	 $temp1=1;
	 while(1)
	 	{
	 	 if ($temp1==$month) break;
	 	 $temp2=$temp1-1;
		 if (CheckLunar($year)) $temp+=kTblMonthLunar[$temp2];
		 else $temp+=kTblMonth[$temp2];	 	
		 $temp1++;
	 	}
	 $temp*=(24*3600);
	 $temp+=$hour*3600;
	 $temp+=$min*60;
	 $temp+=$sec;
	 return($temp);
 	}



function ConvDatetimetoText($value)
{
 $sec=$value % 60;
 $value=intval($value/60);
 $min=$value % 60;
 $value=intval($value/60);
 $hour=$value % 24;
 $value=intval($value/24);

 $year=kOffSetYear;
 while(1)
    {
     if (CheckLunar($year)) $temp=366;
     else $temp=365;
     if ($value<$temp) break;
     else
        {
         $year++;
         $value-=$temp;
        }
    }
 $month=0;
 while(1)
    {
     if (CheckLunar($year)) $temp=kTblMonthLunar[$month];
     else $temp=kTblMonth[$month];
     if ($value<$temp) break;
     else
        {
         $value-=$temp;
         $month++;
        }
    }
 $month++;
 $day=$value+1;
 if ($day<10) $day='0'.$day;
 if ($month<10) $month='0'.$month;
 if ($hour<10) $hour='0'.$hour;
 if ($min<10) $min='0'.$min;
 if ($sec<10) $sec='0'.$sec;
 return($year.'/'.$month.'/'.$day.' '.$hour.':'.$min.':'.$sec);
}


function GetDateWeek($value)
{
 $value=intval($value/86400);
 $value= (($value+kOffDate) % 7);
 return($value);
}

?>