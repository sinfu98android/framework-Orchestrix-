<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>

<style>
body {
  background-image: url('image/Logo.png');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
  background-color:#202020;
}
</style> 
</html>


<script src="js/misc.js"></script>
<script src="js/hmi.js"></script>
<script src="js/project.js"></script>
<script src="js/filesave.js"></script>
<script src="js/myfft.js"></script>
<script type="text/javascript">

const kMaxFormula=15;

const kOffsetX0=1;
const kOffsetY0=25;

const kOffsetX1=25;
const kOffsetY1=38;

const kOffsetX2=65;
const kOffsetY2=38;

const kOffsetX3=94;
const kOffsetY3=25;

let output_last=0;
let input_last=0;
let mainstate=kMainILDE;
let simInput=0;
let test;
var header=Array();
var user;
var first=false;
var elem = document.documentElement;
var startimeplay=0;
var startimeplay_=0;
var startimeout=0;
var startimeout_=0;

window.onload = function () 
       {
        Init();
        //document.documentElement.webkitRequestFullScreen();
       }
setInterval(Process, kTimeBase);



function Init()
{
 var n, i;

 InitHMI();
 //InitProject("00E02030A7D7");
 InitProject("00F1F3AE059D");
 if (resX>resY)
        {
         CreateLabelNew('lstatus', 0.5, 97.5, 99, 1.3, 1, "Arial", "null", "white", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lheader', 0, 1, 100, 6, 6, "Arial", "COURT 1", "blue", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateButtonNew("bt_back", 0.5, 0.5, 8, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "Back", "Back", 2,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", 'index.php', 'absolute');             
         CreateLabelNew('ltimeplayh', 40, 18, 20, 4, 3.5, "Arial black", "Time Play", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('ltimeplay', 37, 23, 26, 8, 7.5, "Arial black", "00:00.00", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateButtonNew("bt_startmr", 44, 32.5, 5, 8,
                        'image/green_on.png', 'image/green_off.png',
                        "Start", "Start", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_run", 50, 32.5, 5, 8,
                        'image/green_on.png', 'image/green_off.png',
                        "Pause", "Pause", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                  
         CreateButtonNew("bt_timeminus", 38, 33, 5, 7,
                        'image/gray_on.png', 'image/gray_off.png',
                        "-1 Min", "-1 Min", 2,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    
         CreateButtonNew("bt_timeplus", 56, 33, 5, 7,
                        'image/gray_on.png', 'image/gray_off.png',
                        "+1 Min", "+1 Min", 2,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    
         CreateButtonNew("bt_reset", 91.5, 0.5, 8, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "Reset", "Reset", 2,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    


         CreateLabelLocalNew('playera@'+iddev, 1, 10, 48, 5.5, 4.5, "Arial bold", "PLAYERA", "black", "white",2,"px", 'PressLabelLocal(this.id)', "TXT", "center", kVarCACHE, null, null, null, 'fixed');
         CreateLabelLocalNew('playerb@'+iddev,50, 10, 48, 5.5, 4.5, "Arial bold", "PLAYERB", "black", "white",2,"px", 'PressLabelLocal(this.id)', "TXT", "center", kVarCACHE, null, null, null, 'fixed');

         CreateLabelNew('lafaulth', kOffsetX1, 75, 10, 4, 3.5, "Arial black", "Foul", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lbfaulth', kOffsetX2, 75, 10, 4, 3.5, "Arial black", "Foul", "white", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('foula@'+iddev, kOffsetX1, 79, 10, 9, 8.5, "Arial black", "", "orange", "transparent",0,"px", null, "NUM", "center", kVarCACHE, null, null, null, 'absolute');
         CreateLabelNew('foulb@'+iddev, kOffsetX2, 79, 10, 9, 8.5, "Arial black", "", "orange", "transparent",0,"px", null, "NUM", "center", kVarCACHE, null, null, null, 'absolute');         
         CreateButtonNew("bt_afaultminus", kOffsetX1+1.5, 89, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "-", "-", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    
         CreateButtonNew("bt_afaultplus", kOffsetX1+5.5, 89, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "+", "+", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    
         CreateButtonNew("bt_bfaultminus", kOffsetX2+1.5, 89, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "-", "-", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    
         CreateButtonNew("bt_bfaultplus", kOffsetX2+5.5, 89, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "+", "+", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');    

         CreateLabelNew('lascoreh', kOffsetX1, 21, 10, 4, 3.5, "Arial black", "Score", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lbscoreh', kOffsetX2, 21, 10, 4, 3.5, "Arial black", "Score", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lscorea', kOffsetX1, 26, 10, 10, 9.5, "Arial black", "0", "blue", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lscoreb', kOffsetX2, 26, 10, 10, 9.5, "Arial black", "0", "blue", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateButtonNew("bt_ascoreminus1", kOffsetX1, kOffsetY1, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-1", "-1", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
         CreateButtonNew("bt_ascoreplus1", kOffsetX1+5.5, kOffsetY1, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+1", "+1", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_ascoreminus2", kOffsetX1, kOffsetY1+7.5, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-2", "-2", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                  
         CreateButtonNew("bt_ascoreplus2", kOffsetX1+5.5, kOffsetY1+7.5, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+2", "+2", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_ascoreminus3", kOffsetX1, kOffsetY1+15, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-3", "-3", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                  
         CreateButtonNew("bt_ascoreplus3", kOffsetX1+5.5, kOffsetY1+15, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+3", "+3", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_bscoreminus1", kOffsetX2, kOffsetY2, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-1", "-1", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
         CreateButtonNew("bt_bscoreplus1", kOffsetX2+5.5, kOffsetY2, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+1", "+1", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_bscoreminus2", kOffsetX2, kOffsetY2+7.5, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-2", "-2", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                  
         CreateButtonNew("bt_bscoreplus2", kOffsetX2+5.5, kOffsetY2+7.5, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+2", "+2", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         
         CreateButtonNew("bt_bscoreminus3", kOffsetX2, kOffsetY2+15, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "-3", "-3", 3,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');                  
         CreateButtonNew("bt_bscoreplus3", kOffsetX2+5.5, kOffsetY2+15, 5, 7,
                        'image/green_on.png', 'image/green_off.png',
                        "+3", "+3", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');         

         CreateLabelNew('lsession', 44.5, 42, 10, 3, 2.5, "Arial black", "Session:", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('ldirplaya', 40, 51, 5.5, 4, 3.5, "Arial black", "<<<<", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('ldirplayb', 53.5, 51, 5.5, 4, 3.5, "Arial black", ">>>>", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelLocalNew('session@'+iddev,47, 45, 5, 5, 4.5, "Arial black", "0", "black", "white",1,"px", 'PressLabelLocal(this.id)', "NUM", "center", kVarCACHE, null, null, null, 'fixed');
         CreateButtonNew("bt_dira", 40, 45, 5.5, 5,
                        'image/green_on.png', 'image/green_off.png',
                        "<<<", "<<<", 2,"Arial black", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');   
         CreateButtonNew("bt_dirb", 53.5, 45, 5.5, 5,
                        'image/green_on.png', 'image/green_off.png',
                        ">>>", ">>>", 2,"Arial black", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');   

         CreateLabelNew('ltimeout', 38.5, 58.5, 10, 3, 2.5, "Arial black", "Timeout:", "black", "transparent",0,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('timeout@'+iddev,  45, 57, 10, 6, 5.5, "Arial black", "00", "black", "transparent",0,"px", null, "NUM", "center", kVarCACHE, null, null, null, 'absolute');
         CreateButtonNew("bt_timeout", 54, 57, 5, 5.5,
                        'image/green_on.png', 'image/green_off.png',
                        "Start", "Start", 2,"Arial", 
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');   
         CreateLabelNew('lanumplayh', kOffsetX0+1, kOffsetY0-5, 5, 3, 2.5, "Arial black", "Num", "black", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lafaultplayh', kOffsetX0+6, kOffsetY0-5, 5, 3, 2.5, "Arial black", "Foul", "black", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lbnumplayh', kOffsetX3+0.5, kOffsetY3-5, 5, 3, 2.5, "Arial black", "Num", "black", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         CreateLabelNew('lbfaultplayh', kOffsetX3-5, kOffsetY3-5, 5, 3, 2.5, "Arial black", "Foul", "black", "transparent",0,"px", null, "NUM", "left", kVarNONE, null, null, null, 'absolute');
         for (n=0; n<12; n++)
              {            
               CreateLabelLocalNew('playan'+n+"@"+iddev,kOffsetX0, kOffsetY0+6*n, 5, 5, 4, "Arial bold", "00", "black", "white",2,"px", 'PressLabelLocal(this.id)', "NUM", "center", kVarCACHE, null, null, null, 'fixed');
               CreateButtonNew("bt_afaultminus"+n, kOffsetX0+10.5, kOffsetY0+6*n, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "-", "-", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute'); 
               CreateButtonNew("bt_afaultplus"+n, kOffsetX0+14.5, kOffsetY0+6*n, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "+", "+", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute'); 
               CreateLabelNew('afault'+n+'@'+iddev, kOffsetX0+5.5, kOffsetY0+6*n, 4.5, 5, 4.5, "Arial black", "0", "yellow", "gray",0,"px", null, "NUM", "center", kVarCACHE, null, null, null, 'absolute');

               CreateLabelLocalNew('playbn'+n+"@"+iddev,kOffsetX3, kOffsetY3+6*n, 5, 5, 4, "Arial bold", "00", "black", "white",2,"px", 'PressLabelLocal(this.id)', "NUM", "center", kVarCACHE, null, null, null, 'fixed');
               CreateButtonNew("bt_bfaultminus"+n, kOffsetX3-12.5, kOffsetY3+6*n, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "-", "-", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute'); 
               CreateButtonNew("bt_bfaultplus"+n, kOffsetX3-8.5, kOffsetY3+6*n, 3, 5.5,
                        'image/gray_on.png', 'image/gray_off.png',
                        "+", "+", 3,"Arial",
                        "PressButton(this.id)",  "ReleaseButton(this.id)",
                        "red", "white", null, 'absolute');
               CreateLabelNew('bfault'+n+'@'+iddev, kOffsetX3-5, kOffsetY3+6*n, 4.5, 5, 4.5, "Arial black", "0", "yellow", "gray",0,"px", null, "NUM", "center", kVarCACHE, null, null, null, 'absolute');
              }

        }
 else CreateLabelNew('lheader', 0, 2, 100, 4, 3, "Arial", "Please rotate...", "white", "transparent",2,"px", null, "NUM", "center", kVarNONE, null, null, null, 'absolute'); 
 //CreateVarRDObj('mainstate', null, false);
 //CreateVarRDObj('test', null, false);
 CreateVarRDObj('runmst@'+iddev);
}

function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }
}



function main()
{
 var n, i, temp;


 n=GetID("bt_ascoreplus1");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
         if (scorea==undefined) scorea=0;
         scorea++;
         if (scorea>1000) scorea=0;
         SetValVarWRObj('scorea@'+iddev, scorea);
         }
    }
 n=GetID("bt_ascoreminus1");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
         if (scorea==undefined) scorea=0;
         scorea--;
         if (scorea<0) scorea=0;
         SetValVarWRObj('scorea@'+iddev, scorea);
        }
    }
 n=GetID("bt_ascoreplus2");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
         if (scorea==undefined) scorea=0;
         scorea+=2;
         if (scorea>1000) scorea=0;
         SetValVarWRObj('scorea@'+iddev, scorea);
         }
    }
 n=GetID("bt_ascoreminus2");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
            {
             scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
             if (scorea==undefined) scorea=0;
             scorea-=2;
             if (scorea<0) scorea=0;
             SetValVarWRObj('scorea@'+iddev, scorea);
            }
    }    
 n=GetID("bt_ascoreplus3");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
         if (scorea==undefined) scorea=0;
         scorea+=3;
         if (scorea>1000) scorea=0;
         SetValVarWRObj('scorea@'+iddev, scorea);
         }
    }
 n=GetID("bt_ascoreminus3");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
            {
             scorea=parseInt(GetValVarRDObj('scorea@'+iddev));
             if (scorea==undefined) scorea=0;
             scorea-=3;
             if (scorea<0) scorea=0;
             SetValVarWRObj('scorea@'+iddev, scorea);
            }
    }    

 n=GetID("bt_bscoreplus1");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
//         scoreb=0;
         console.log("here", scoreb);
         if (scoreb==undefined) scoreb=0;
         scoreb++;
         if (scoreb>1000) scoreb=0;
         SetValVarWRObj('scoreb@'+iddev, scoreb);
         }
    }
 n=GetID("bt_bscoreminus1");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         console.log("here");
         scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
         if (scoreb==undefined) scoreb=0;
         scoreb--;
         if (scoreb<0) scoreb=0;
         SetValVarWRObj('scoreb@'+iddev, scoreb);
        }
    }
 n=GetID("bt_bscoreplus2");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
         if (scoreb==undefined) scoreb=0;
         scoreb+=2;
         if (scoreb>1000) scoreb=0;
         SetValVarWRObj('scoreb@'+iddev, scoreb);
         }
    }
 n=GetID("bt_bscoreminus2");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
            {
             scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
             if (scoreb==undefined) scoreb=0;
             scoreb-=2;
             if (scoreb<0) scoreb=0;
             SetValVarWRObj('scoreb@'+iddev, scoreb);
            }
    }    
 n=GetID("bt_bscoreplus3");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
        {
         scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
         if (scoreb==undefined) scoreb=0;
         scoreb+=3;
         if (scoreb>1000) scoreb=0;
         SetValVarWRObj('scoreb@'+iddev, scoreb);
         }
    }
 n=GetID("bt_bscoreminus3");
 if (n>=0)
    {
     if (hmiobj[n].EDGEPRESS)
            {
             scoreb=parseInt(GetValVarRDObj('scoreb@'+iddev));
             if (scoreb==undefined) scoreb=0;
             scoreb-=3;
             if (scoreb<0) scoreb=0;
             SetValVarWRObj('scoreb@'+iddev, scoreb);
            }
    }    

 for (i=0; i<kMaxPlayer; i++)
    {
      n=GetID("bt_afaultminus"+i);
      if (n>=0)
          {
           if (hmiobj[n].EDGEPRESS)
              {
               //console.log("here...:"+'afault'+i+'@'+iddev);
               faulta[i]=parseInt(GetValVarRDObj('afault'+i+'@'+iddev));
               if (faulta[i]);  else faulta[i]=0;
               console.log(faulta[i]);
               faulta[i]--;
               if (faulta[i]<0) faulta[i]=0;
               SetValVarWRObj('afault'+i+'@'+iddev, faulta[i]);
              }

          }
      n=GetID("bt_afaultplus"+i);
      if (n>=0)
          {
           if (hmiobj[n].EDGEPRESS)
              {
               //console.log("here1...");
               faulta[i]=parseInt(GetValVarRDObj('afault'+i+'@'+iddev));
               if (faulta[i]);  else faulta[i]=0;
               faulta[i]++;
               if (faulta[i]>=5) faulta[i]=5;
               SetValVarWRObj('afault'+i+'@'+iddev, faulta[i]);
              }
          }
      n=GetID("bt_bfaultminus"+i);
      if (n>=0)
          {
           if (hmiobj[n].EDGEPRESS)
              {
               //console.log("here...:"+'afault'+i+'@'+iddev);
               faultb[i]=parseInt(GetValVarRDObj('bfault'+i+'@'+iddev));
               if (faultb[i]);  else faultb[i]=0;
               //console.log(faultb[i]);
               faultb[i]--;
               if (faultb[i]<0) faultb[i]=0;
               SetValVarWRObj('bfault'+i+'@'+iddev, faultb[i]);
              }

          }
      n=GetID("bt_bfaultplus"+i);
      if (n>=0)
          {
           if (hmiobj[n].EDGEPRESS)
              {
               //console.log("here1...");
               faultb[i]=parseInt(GetValVarRDObj('bfault'+i+'@'+iddev));
               if (faultb[i]);  else faultb[i]=0;
               faultb[i]++;
               if (faultb[i]>=5) faultb[i]=5;
               SetValVarWRObj('bfault'+i+'@'+iddev, faultb[i]);
              }
          }                    
    }

 n=GetID('bt_startmr');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
         if (GetValVarRDObj('timerplay@'+iddev)==0)
            {
             SetValVarWRObj('timerplay@'+iddev, 60000);
             var temp=GetTimestamp();
             console.log(temp);
             SetValVarWRObj('timerplaystamp@'+iddev, temp);
             SetValVarWRObj('runmst@'+iddev, 1);
            }
        }
    }
 n=GetID('bt_run');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
         { 
           if (GetValVarRDObj('runmst@'+iddev)==0) SetValVarWRObj('runmst@'+iddev, 1);
           else SetValVarWRObj('runmst@'+iddev, 0);  
         }
    }
 n=GetID('bt_timeminus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
         {
          var temp=GetValVarRDObj('timerplay@'+iddev);
          temp=parseInt(temp);
          if (temp>6000)
             {
              temp-=6000;
              SetValVarWRObj('timerplay@'+iddev, temp);
             }
         }
    }
 n=GetID('bt_timeplus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
         {
          var temp=GetValVarRDObj('timerplay@'+iddev);
          temp=parseInt(temp);
          console.log(temp);
          temp+=6000;
          SetValVarWRObj('timerplay@'+iddev, temp);
         }
    }

 n=GetID('bt_timeout');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
         {
          //if (GetValVarRDObj('starttout@'+iddev)==0) if (startimeout_==0) startimeout=10;    //SetValVarWRObj('starttout@'+iddev, 1);
          if (GetValVarRDObj('timeout@'+iddev)==0)
             {
              SetValVarWRObj('timeout@'+iddev, 60);
              var temp=GetTimestamp();
              console.log(temp);
              SetValVarWRObj('timeoutstamp@'+iddev, temp);
             }
         }
    }

 n=GetID('bt_afaultminus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
         foula=parseInt(GetValVarRDObj('foula@'+iddev));
         foula--;
         if (foula<0) foula=0;
         SetValVarWRObj('foula@'+iddev, foula);
        }
    }
 n=GetID('bt_afaultplus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
         foula=parseInt(GetValVarRDObj('foula@'+iddev));
         foula++;
         if (foula>=100) foula=99;
         SetValVarWRObj('foula@'+iddev, foula);
        }
    }
 n=GetID('bt_bfaultminus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
         foulb=parseInt(GetValVarRDObj('foulb@'+iddev));
         foulb--;
         if (foulb<0) foulb=0;
         console.log("foulb-"+foulb);
         SetValVarWRObj('foulb@'+iddev, foulb);
        }
    }
 n=GetID('bt_bfaultplus');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
         foulb=parseInt(GetValVarRDObj('foulb@'+iddev));
         foulb++;
         console.log("foulb+"+foulb);
         if (foulb>=100) foulb=99;
         SetValVarWRObj('foulb@'+iddev, foulb);
        }
    }

 n=GetID('bt_dira');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE) SetValVarWRObj('dirplay@'+iddev, 0);
    }
 n=GetID('bt_dirb');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE) SetValVarWRObj('dirplay@'+iddev, 1);
    }
 n=GetID('bt_reset');
 if (n>=0)
    {
     if (hmiobj[n].EDGERELEASE)
        {
          SetValVarWRObj('foula@'+iddev, 0);
          SetValVarWRObj('foulb@'+iddev, 0);
          SetValVarWRObj('scorea@'+iddev, 0);
          SetValVarWRObj('scoreb@'+iddev, 0);
          SetValVarWRObj('timeout@'+iddev, 0);
          SetValVarWRObj('timerplay@'+iddev, 0);
        }
    }

 if (tick100mS)
    {
     n=GetID('lstatus');
     if (n>=0)
          {
           hmiobj[n].TEXT="MAC:"+macaddr+"  IP:"+ipaddr+"  CPUTick:"+tick+"  TCP Cycle:"+ticktcp+"  r:"+cachereadtime+"ms"+"  w:"+cachewritetime+"ms";
           //console.log(GetValVarRDObj('playera@'+iddev), GetValVarRDObj('playerb@'+iddev), focusid);
          }
     n=GetID('ltimeplay');
     if (n>=0)
        {
         var temp=parseInt(timerplay);
         hmiobj[n].TEXT=zerolead(parseInt((temp/6000)%60),2)+':'+zerolead(parseInt((temp/100)%60),2)+':'+zerolead(temp % 100, 2);    //temp/6000+':'+temp/100+':'+temp % 100;
        }
     n=GetID('lscorea');
     if (n>=0)
        {
         scorea=GetValVarRDObj('scorea@'+iddev);
         hmiobj[n].TEXT=scorea;
        }
     n=GetID('lscoreb');
     if (n>=0)
        {
         scoreb=GetValVarRDObj('scoreb@'+iddev);
         hmiobj[n].TEXT=scoreb;
        }

     if (GetValVarRDObj('dirplay@'+iddev)==0)
        {
         n=GetID('ldirplaya');
         if (n>=0) hmiobj[n].TEXT='<<<<';
         n=GetID('ldirplayb');
         if (n>=0) hmiobj[n].TEXT='';
        }
      else
         {
         n=GetID('ldirplaya');
         if (n>=0) hmiobj[n].TEXT='';
         n=GetID('ldirplayb');
         if (n>=0) hmiobj[n].TEXT='>>>>';
         }   
    }
 if (tick100mS)
    {
     if (startimeplay) startimeplay--;
     if (startimeplay_) startimeplay_--;
     if (startimeout) startimeout--;
     if (startimeout_) startimeout_--;
     if (startimeplay)
         {
          SetValVarWRObj('startmr@'+iddev, 1);
          SetValVarWRObj('runmst@'+iddev, 1);
         }
     if (startimeplay_) SetValVarWRObj('startmr@'+iddev, 0);
     if (startimeout) SetValVarWRObj('starttout@'+iddev, 1);
     if (startimeout_) SetValVarWRObj('starttout@'+iddev, 0);
    }
if (tick100mS)
      {
       n=GetID('ltimeplayh');
       if (n>0)
          {
           var temp=GetValVarRDObj('runmst@'+iddev);
           //console.log(temp);
           if (temp==1) hmiobj[n].TEXT='Time Play RUN';
           else 
               {
                //hmiobj[n].TEXT='Time Play PAUSE'; 
                if (cycle500mS) hmiobj[n].TEXT='Time Play PAUSE';
                else hmiobj[n].TEXT='';
               }
           hmiobj[n].REFRESH=true;
          }  
        //console.log(GetValVarRDObj('runmst@'+iddev));
      }
}



</script>