<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USB Serial Communication</title>
</head>
<body>
    <button id="connect">Connect to Serial</button>
    <button id="send">Send Data</button>
    <script>
        console.log("serial" in navigator ? "Supported!" : "Not supported.");
        //navigator.serial.getPorts().then(ports => console.log("Available ports:", ports));

        let port;

        document.getElementById("connect").addEventListener("click", async () => {
            if ("serial" in navigator) {
                try {
                    port = await navigator.serial.requestPort();
                    await port.open({ baudRate: 9600 });
                    console.log("Connected to serial port.");
                } catch (error) {
                    console.error("Error connecting to serial port:", error);
                }
            } else {
                console.error("Web Serial API not supported.");
            }
        });

        document.getElementById("send").addEventListener("click", async () => {
            if (port && port.writable) {
                const writer = port.writable.getWriter();
                const data = new TextEncoder().encode("Hello Device!");
                await writer.write(data);
                writer.releaseLock();
                console.log("Data sent.");
            } else {
                console.error("Serial port not connected.");
            }
        });
    </script>
</body>
</html>