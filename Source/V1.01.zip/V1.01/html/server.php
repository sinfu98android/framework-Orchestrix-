<?php 
function ConnectDatabase($servername, $username, $password, $dbname)
  {
   $con = mysqli_connect($servername, $username, $password);
   if (!$con)
       {
        die('Could not connect: ' . mysql_error());
       }
   else
       {
        $sql = "CREATE DATABASE IF NOT EXISTS ".$dbname;
        $result = $con->query($sql);
        if ($result)
           {
            $con->close();
           }
        }
  }

?>