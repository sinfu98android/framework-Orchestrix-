<?php
$mem = new Memcached();
$mem->addServer("/tmp/memcached.sock", 0);

if (!$mem->set("check", "socket_test")) {
    echo "Set failed: " . $mem->getResultMessage();
} else {
    echo "Set succeeded\n";
    echo "Get result: " . $mem->get("check") . "\n";
}
?>