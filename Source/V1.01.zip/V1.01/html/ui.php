<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>HMI UI Builder</title>
  <style>
    body { margin: 0; display: flex; height: 100vh; font-family: sans-serif; }
    #toolbox { width: 200px; background: #eee; padding: 10px; }
    #canvas { flex-grow: 1; position: relative; background: #fafafa; border-left: 1px solid #ccc; }
    .widget { position: absolute; border: 1px dashed #999; background: #fff; cursor: move; padding: 5px; }
    .tool { padding: 8px; margin: 5px 0; background: #ddd; cursor: grab; text-align: center; }
  </style>
</head>
<body>
  <div id="toolbox">
    <div class="tool" data-type="gauge">Gauge</div>
    <div class="tool" data-type="textbox">Textbox</div>
    <div class="tool" data-type="button">Button</div>
    <button onclick="saveLayout()">💾 Save</button>
    <input type="file" onchange="loadLayout(event)" />
  </div>
  <div id="canvas"></div>

  <script>
    let currentId = 0;
    const canvas = document.getElementById("canvas");
    const toolboxItems = document.querySelectorAll(".tool");

    toolboxItems.forEach(tool => {
      tool.addEventListener("click", () => {
        const widget = document.createElement("div");
        const type = tool.dataset.type;
        widget.className = "widget";
        widget.style.left = "50px";
        widget.style.top = "50px";
        widget.innerText = `${type} ${currentId}`;
        widget.dataset.id = `W${currentId}`;
        widget.dataset.type = type;
        widget.draggable = true;

        makeDraggable(widget);

        canvas.appendChild(widget);
        currentId++;
      });
    });

    function makeDraggable(el) {
      el.addEventListener("dragstart", e => {
        e.dataTransfer.setData("text/plain", null);
        e.dataTransfer.setDragImage(new Image(), 0, 0);
        el.startX = e.clientX - el.offsetLeft;
        el.startY = e.clientY - el.offsetTop;
      });

      canvas.addEventListener("dragover", e => e.preventDefault());
      canvas.addEventListener("drop", e => {
        const active = document.querySelector(".widget.dragging");
        if (active) {
          active.style.left = `${e.clientX - active.startX}px`;
          active.style.top = `${e.clientY - active.startY}px`;
          active.classList.remove("dragging");
        }
      });

      el.addEventListener("dragstart", () => el.classList.add("dragging"));
      el.addEventListener("dragend", () => el.classList.remove("dragging"));
    }

    function saveLayout() {
      const layout = Array.from(canvas.children).map(w => ({
        id: w.dataset.id,
        type: w.dataset.type,
        x: parseInt(w.style.left),
        y: parseInt(w.style.top)
      }));
      const blob = new Blob([JSON.stringify(layout, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "layout.json";
      a.click();
    }

    function loadLayout(event) {
      const file = event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => {
        const layout = JSON.parse(e.target.result);
        canvas.innerHTML = "";
        layout.forEach(w => {
          const el = document.createElement("div");
          el.className = "widget";
          el.style.left = `${w.x}px`;
          el.style.top = `${w.y}px`;
          el.innerText = `${w.type} ${w.id}`;
          el.dataset.id = w.id;
          el.dataset.type = w.type;
          makeDraggable(el);
          canvas.appendChild(el);
        });
      };
      reader.readAsText(file);
    }
  </script>
</body>
</html>
